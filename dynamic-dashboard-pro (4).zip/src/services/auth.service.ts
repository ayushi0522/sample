import { Injectable, signal, PLATFORM_ID, inject, computed } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private platformId = inject(PLATFORM_ID);
  // FIX: Explicitly type the injected Router to resolve type inference issues.
  private router: Router = inject(Router);
  
  private authToken = signal<string | null>(null);
  
  isAuthenticated = computed(() => this.authToken() !== null);

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      this.authToken.set(localStorage.getItem('authToken'));
    }
  }

  // FIX: Corrected typo in parameter name from 'passowrd' to 'password'.
  login(email: string, password: string): void {
    // Simulate API call and getting a token
    const fakeToken = `fake-jwt-token-for-${email}`;
    this.setToken(fakeToken);
    this.router.navigate(['/dashboard']);
  }

  loginWithGoogle(): void {
    const fakeToken = 'fake-google-jwt-token';
    this.setToken(fakeToken);
    this.router.navigate(['/dashboard']);
  }

  // FIX: Add missing loginWithOtp method to support OTP-based login flow.
  loginWithOtp(phone: string, otp: string): void {
    // Simulate API call and getting a token for OTP login
    const fakeToken = `fake-jwt-token-for-${phone}`;
    this.setToken(fakeToken);
    this.router.navigate(['/dashboard']);
  }

  logout(): void {
    this.clearToken();
    this.router.navigate(['/login']);
  }

  private setToken(token: string): void {
    this.authToken.set(token);
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('authToken', token);
    }
  }

  private clearToken(): void {
    this.authToken.set(null);
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('authToken');
    }
  }
}
