import { Component, ChangeDetectionStrategy, AfterViewInit, OnDestroy, ViewChild, ElementRef, inject, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThemeService, Theme } from '../../services/theme.service';

declare var Chart: any;

interface Device {
  id: string;
  name: string;
  status: 'Online' | 'Offline';
  battery: number;
  location: string;
  lastSeen: string;
}

@Component({
  selector: 'app-devices',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './devices.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DevicesComponent implements AfterViewInit, OnDestroy {
  @ViewChild('sensorCanvas') sensorCanvas!: ElementRef;
  private chart: any;
  private themeService = inject(ThemeService);

  devices: Device[] = [
    { id: 'iot-001', name: 'Field Sensor Alpha', status: 'Online', battery: 92, location: 'Zone A', lastSeen: '1 min ago' },
    { id: 'iot-002', name: 'Gateway Hub', status: 'Online', battery: 100, location: 'Control Room', lastSeen: '5 secs ago' },
    { id: 'iot-003', name: 'Pump Monitor', status: 'Offline', battery: 0, location: 'Reservoir B', lastSeen: '2 hours ago' },
    { id: 'iot-004', name: 'Field Sensor Bravo', status: 'Online', battery: 78, location: 'Zone B', lastSeen: '5 mins ago' },
    { id: 'iot-005', name: 'Environment Sensor', status: 'Online', battery: 85, location: 'Greenhouse 3', lastSeen: '10 mins ago' },
    { id: 'iot-006', name: 'Weather Station', status: 'Online', battery: 99, location: 'Rooftop', lastSeen: '30 secs ago' },
  ];

  constructor() {
    effect(() => {
      this.themeService.theme(); // depend on theme signal
      if (this.chart) {
        this.updateChartTheme();
      }
    });
  }

  ngAfterViewInit() {
    this.createChart();
  }

  ngOnDestroy() {
    this.chart?.destroy();
  }

  private getCssVariable(variable: string): string {
    return getComputedStyle(document.documentElement).getPropertyValue(variable).trim();
  }

  private updateChartTheme(): void {
    const gridColor = this.getCssVariable('--border-primary');
    const ticksColor = this.getCssVariable('--text-tertiary');
    const legendColor = this.getCssVariable('--text-secondary');

    if (this.chart.options.scales) {
      this.chart.options.scales.x.grid.color = gridColor;
      this.chart.options.scales.x.ticks.color = ticksColor;
      this.chart.options.scales.y.grid.color = gridColor;
      this.chart.options.scales.y.ticks.color = ticksColor;
    }
     if (this.chart.options.plugins.legend) {
        this.chart.options.plugins.legend.labels.color = legendColor;
    }
    this.chart.update();
  }

  private createChart(): void {
    if (this.chart) this.chart.destroy();
    if (!this.sensorCanvas) return;

    const ctx = this.sensorCanvas.nativeElement.getContext('2d');
    const gridColor = this.getCssVariable('--border-primary');
    const ticksColor = this.getCssVariable('--text-tertiary');
    const legendColor = this.getCssVariable('--text-secondary');

    this.chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'],
        datasets: [
          {
            label: 'Temperature (°C)',
            data: [22, 24, 25, 24, 23, 23, 22],
            borderColor: 'rgb(239, 68, 68)', // red-500
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            fill: true,
            tension: 0.4,
          },
          {
            label: 'Humidity (%)',
            data: [55, 52, 50, 51, 53, 54, 56],
            borderColor: this.getCssVariable('--accent-primary'),
            backgroundColor: this.getCssVariable('--accent-primary') + '1A', // ~10% opacity
            fill: true,
            tension: 0.4,
          },
          {
            label: 'Pressure (hPa)',
            data: [1012, 1011, 1010, 1011, 1012, 1013, 1012],
            borderColor: 'rgb(16, 185, 129)', // green-500
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            fill: true,
            tension: 0.4,
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: { grid: { color: gridColor }, ticks: { color: ticksColor } },
          y: { grid: { color: gridColor }, ticks: { color: ticksColor } }
        },
        plugins: {
          legend: {
            position: 'top',
            labels: {
                color: legendColor
            }
          }
        }
      }
    });
  }
}