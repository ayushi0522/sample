import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

type LoginView = 'password' | 'otp';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent {
  private readonly router: Router = inject(Router);
  private authService = inject(AuthService);

  activeView = signal<LoginView>('password');

  // Form Signals
  email = signal('demo@health.pro');
  password = signal('password');
  phone = signal('');
  otp = signal('');

  login(): void {
    if (this.activeView() === 'password') {
      this.authService.login(this.email(), this.password());
    } else {
      this.authService.loginWithOtp(this.phone(), this.otp());
    }
  }

  loginWithGoogle(): void {
    this.authService.loginWithGoogle();
  }

  sendOtp(): void {
    // Simulate sending OTP
    console.log(`Sending OTP to ${this.phone()}`);
    alert('OTP Sent! (Simulated)');
  }

  setView(view: LoginView): void {
    this.activeView.set(view);
  }
}