import { Component, ChangeDetectionStrategy, AfterViewInit, OnDestroy, inject, effect } from '@angular/core';
import { ThemeService, Theme } from '../../services/theme.service';

declare var L: any;

@Component({
  selector: 'app-map-widget',
  templateUrl: './map-widget.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MapWidgetComponent implements AfterViewInit, OnDestroy {
  private map: any;
  private tileLayer: any;
  private themeService = inject(ThemeService);

  constructor() {
      effect(() => {
          this.updateMapTheme(this.themeService.theme());
      });
  }

  ngAfterViewInit(): void {
    this.initMap();
  }

  ngOnDestroy(): void {
    if (this.map) {
      this.map.remove();
    }
  }

  private initMap(): void {
    this.map = L.map('map', {
      center: [20, 0],
      zoom: 2,
      zoomControl: false,
      attributionControl: false,
    });
    
    this.updateMapTheme(this.themeService.theme());

    // Dummy data for markers
    const locations = [
      { lat: 34.0522, lng: -118.2437, city: 'Los Angeles' },
      { lat: 40.7128, lng: -74.0060, city: 'New York' },
      { lat: 51.5074, lng: -0.1278, city: 'London' },
      { lat: 35.6895, lng: 139.6917, city: 'Tokyo' },
      { lat: -33.8688, lng: 151.2093, city: 'Sydney' },
      { lat: 19.0760, lng: 72.8777, city: 'Mumbai' }
    ];

    const customIcon = L.divIcon({
      className: 'custom-div-icon',
      html: `<div class="w-3 h-3 bg-[var(--accent-primary)] rounded-full ring-4 ring-[var(--accent-primary)]/30"></div>`,
      iconSize: [12, 12],
      iconAnchor: [6, 6]
    });

    locations.forEach(loc => {
      L.marker([loc.lat, loc.lng], { icon: customIcon })
        .addTo(this.map)
        .bindPopup(`<b>${loc.city}</b><br>Activity detected.`);
    });
  }
  
  private updateMapTheme(theme: Theme) {
      if (!this.map) return;

      if (this.tileLayer) {
          this.map.removeLayer(this.tileLayer);
      }
      
      const isDark = theme !== 'light';
      const tileUrl = isDark
        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
        : 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png';
      
      this.tileLayer = L.tileLayer(tileUrl, { maxZoom: 19 });
      this.tileLayer.addTo(this.map);
  }
}