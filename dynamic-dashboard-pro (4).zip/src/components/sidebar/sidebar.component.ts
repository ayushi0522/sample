import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';

interface MenuItem {
  name: string;
  iconName: 'overview' | 'devices' | 'tracking' | 'settings';
  link: string;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './sidebar.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SidebarComponent {
  isExpanded = signal(true);

  menuItems: MenuItem[] = [
    { name: 'Overview', iconName: 'overview', link: '/dashboard/overview' },
    { name: 'Devices', iconName: 'devices', link: '/dashboard/devices' },
    { name: 'Tracking', iconName: 'tracking', link: '/dashboard/tracking' },
    { name: 'Settings', iconName: 'settings', link: '/dashboard/settings' },
  ];

  toggleSidebar() {
    this.isExpanded.update(value => !value);
  }
}