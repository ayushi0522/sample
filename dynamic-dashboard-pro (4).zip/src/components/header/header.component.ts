import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThemeService, Theme } from '../../services/theme.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-header',
  imports: [CommonModule],
  templateUrl: './header.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderComponent {
  themeService = inject(ThemeService);
  authService = inject(AuthService);

  isProfileOpen = signal(false);
  isThemeMenuOpen = signal(false);

  setTheme(theme: Theme): void {
    this.themeService.setTheme(theme);
    this.isThemeMenuOpen.set(false);
  }

  toggleThemeMenu(): void {
    this.isThemeMenuOpen.update(v => !v);
  }

  toggleProfileMenu(): void {
    this.isProfileOpen.update(v => !v);
  }

  logout(): void {
    this.isProfileOpen.set(false);
    this.authService.logout();
  }
}