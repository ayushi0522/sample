import { Component, ChangeDetectionStrategy, AfterViewInit, OnDestroy, inject, effect, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
// FIX: Import Theme type from the service to resolve type mismatch.
import { ThemeService, Theme } from '../../services/theme.service';
import { DriverChatComponent } from './driver-chat.component';

declare var L: any;
// FIX: Removed local Theme type definition which was causing conflicts with the service's Theme type.
// type Theme = 'light' | 'dark';

@Component({
  selector: 'app-tracking',
  standalone: true,
  imports: [CommonModule, DriverChatComponent],
  templateUrl: './tracking.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TrackingComponent implements AfterViewInit, OnDestroy {
  private map: any;
  private tileLayer: any;
  private driverMarker: any;
  private themeService = inject(ThemeService);

  isChatOpen = signal(false);

  // Route coordinates
  private route: [number, number][] = [
    [34.0522, -118.2437], [34.1522, -118.2537], [34.2522, -118.3537],
    [34.3522, -118.4537], [34.4522, -118.5537], [34.5522, -118.6537],
    [34.6522, -118.7537], [35.1699, -117.1398], [36.1699, -115.1398]
  ];
  private driverCurrentPosition = this.route[3];

  constructor() {
    effect(() => {
      this.updateMapTheme(this.themeService.theme());
    });
  }

  ngAfterViewInit(): void {
    this.initMap();
  }

  ngOnDestroy(): void {
    if (this.map) {
      this.map.remove();
    }
  }

  recenterMap(): void {
    if (this.map && this.driverMarker) {
      this.map.setView(this.driverMarker.getLatLng(), 10, {
        animate: true,
        pan: { duration: 1 }
      });
    }
  }

  toggleChat(): void {
    this.isChatOpen.update(v => !v);
  }

  private initMap(): void {
    this.map = L.map('tracking-map', {
      zoomControl: false,
      attributionControl: false,
    });

    this.updateMapTheme(this.themeService.theme());

    const polyline = L.polyline(this.route, { color: '#0ea5e9', weight: 5 }).addTo(this.map);

    this.map.fitBounds(polyline.getBounds().pad(0.1));

    // Markers
    const startIcon = L.divIcon({
      className: 'custom-div-icon',
      html: `<div class="p-1 bg-white dark:bg-gray-800 rounded-full shadow-md"><div class="w-3 h-3 bg-emerald-500 rounded-full"></div></div>`,
      iconSize: [20, 20],
    });
    L.marker(this.route[0], { icon: startIcon }).addTo(this.map).bindPopup('<b>Warehouse</b><br>Origin');
    
    const endIcon = L.divIcon({
      className: 'custom-div-icon',
      html: `<div class="p-1 bg-white dark:bg-gray-800 rounded-full shadow-md"><div class="w-3 h-3 bg-red-500 rounded-full"></div></div>`,
      iconSize: [20, 20],
    });
    L.marker(this.route[this.route.length - 1], { icon: endIcon }).addTo(this.map).bindPopup('<b>Customer Site</b><br>Destination');
    
    const truckIcon = L.divIcon({
        className: 'custom-div-icon',
        html: `<div class="p-1.5 bg-white dark:bg-gray-800 rounded-full shadow-lg text-sky-500">
                 <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M8 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM15 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" /><path d="M3 4a1 1 0 00-1 1v10a1 1 0 001 1h1.05a2.5 2.5 0 014.9 0H10a1 1 0 001-1V5a1 1 0 00-1-1H3zM14 7a1 1 0 00-1 1v5a1 1 0 001 1h2.05a2.5 2.5 0 014.9 0H21a1 1 0 001-1v-5a1 1 0 00-1-1h-7z" /></svg>
               </div>`,
        iconSize: [32, 32],
    });
    this.driverMarker = L.marker(this.driverCurrentPosition, { icon: truckIcon }).addTo(this.map).bindPopup('<b>Driver: John P.</b><br>En route');

    // ETA on click
    polyline.on('click', (e: any) => {
        const totalDurationMinutes = 225; // 3h 45m
        const totalDistance = this.calculateTotalDistance(this.route);
        const clickedPoint = e.latlng;
        
        let minDistance = Infinity;
        let closestPointOnRoute: any = null;
        
        // Find the closest point on the polyline to the clicked point
        const layers = polyline.getLatLngs();
        for(let i=0; i<layers.length -1; i++){
          const p1 = this.map.latLngToLayerPoint(layers[i]);
          const p2 = this.map.latLngToLayerPoint(layers[i+1]);
          const mousePoint = this.map.latLngToLayerPoint(clickedPoint);
          const closest = L.LineUtil.closestPointOnSegment(mousePoint, p1, p2);
          const distance = closest.distanceTo(mousePoint);
          if(distance < minDistance){
            minDistance = distance;
            closestPointOnRoute = this.map.layerPointToLatLng(closest);
          }
        }
        
        const distanceToPoint = this.calculateDistanceToPoint(this.route, closestPointOnRoute);
        const percentage = distanceToPoint / totalDistance;
        const timeToPoint = new Date(Date.now() + (percentage * totalDurationMinutes * 60000));
        
        L.popup()
         .setLatLng(closestPointOnRoute)
         .setContent(`Estimated arrival: <b>${timeToPoint.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</b>`)
         .openOn(this.map);
    });
  }

  private calculateTotalDistance(route: [number, number][]): number {
    let total = 0;
    for (let i = 0; i < route.length - 1; i++) {
        total += L.latLng(route[i]).distanceTo(L.latLng(route[i+1]));
    }
    return total;
  }

  private calculateDistanceToPoint(route: [number, number][], point: any): number {
    let distance = 0;
    for (let i = 0; i < route.length - 1; i++) {
        const segmentStart = L.latLng(route[i]);
        const segmentEnd = L.latLng(route[i+1]);
        if(this.isBetween(segmentStart, segmentEnd, point)) {
            distance += segmentStart.distanceTo(point);
            return distance;
        }
        distance += segmentStart.distanceTo(segmentEnd);
    }
    return distance;
  }

  private isBetween(a: any, b: any, c: any) {
    const crossProduct = (c.lat - a.lat) * (b.lng - a.lng) - (c.lng - a.lng) * (b.lat - a.lat);
    if (Math.abs(crossProduct) > 0.1) return false;
    const dotProduct = (c.lng - a.lng) * (b.lng - a.lng) + (c.lat - a.lat)*(b.lat - a.lat);
    if (dotProduct < 0) return false;
    const squaredLengthBA = (b.lng - a.lng)*(b.lng - a.lng) + (b.lat - a.lat)*(b.lat - a.lat);
    if (dotProduct > squaredLengthBA) return false;
    return true;
  }

  private updateMapTheme(theme: Theme) {
    if (!this.map) return;
    if (this.tileLayer) this.map.removeLayer(this.tileLayer);
    // FIX: Treat 'neon-blue' as a dark theme for map tiles.
    const isDark = theme !== 'light';
    const tileUrl = isDark
      ? 'https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png'
      : 'https://{s}.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}{r}.png';
    this.tileLayer = L.tileLayer(tileUrl, { maxZoom: 19 });
    this.tileLayer.addTo(this.map);
  }
}
