import { Component, ChangeDetectionStrategy, inject, signal, effect, viewChild, ElementRef, untracked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService, ChatMessage } from '../../services/gemini.service';
import { RecognitionService } from '../../services/recognition.service';

@Component({
  selector: 'app-chat-widget',
  imports: [CommonModule, FormsModule],
  templateUrl: './chat-widget.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChatWidgetComponent {
  geminiService = inject(GeminiService);
  recognitionService = inject(RecognitionService);

  isOpen = signal(false);
  userInput = signal('');
  
  messages = signal<ChatMessage[]>([
    { role: 'model', parts: 'Hello! How can I help you analyze your data today?' }
  ]);
  
  chatContainer = viewChild<ElementRef>('chatContainer');

  constructor() {
    effect(() => {
        if(this.messages() && this.chatContainer()) {
            untracked(() => {
                setTimeout(() => this.scrollToBottom(), 0);
            });
        }
    });

    // Effect to update user input from speech recognition
    effect(() => {
        const transcribedText = this.recognitionService.transcribedText();
        if (transcribedText) {
            this.userInput.set(transcribedText);
        }
    });
  }

  toggleChat() {
    this.isOpen.update(open => !open);
  }

  async sendMessage() {
    const userMessage = this.userInput().trim();
    if (!userMessage || this.geminiService.thinking()) return;

    this.messages.update(msgs => [...msgs, { role: 'user', parts: userMessage }]);
    this.userInput.set('');
    
    // Add a placeholder for the model's response
    this.messages.update(msgs => [...msgs, { role: 'model', parts: '' }]);

    const stream = this.geminiService.sendMessage(userMessage);
    for await (const chunk of stream) {
        this.messages.update(msgs => {
            const lastMessage = msgs[msgs.length - 1];
            if (lastMessage && lastMessage.role === 'model') {
              lastMessage.parts += chunk;
            }
            return [...msgs];
        });
    }
  }

  toggleListening(): void {
    if (this.recognitionService.isListening()) {
      this.recognitionService.stop();
    } else {
      this.recognitionService.start();
    }
  }
  
  private scrollToBottom(): void {
    try {
      if (this.chatContainer()) {
        const element = this.chatContainer()!.nativeElement;
        element.scrollTop = element.scrollHeight;
      }
    } catch (err) {
      console.error('Could not scroll to bottom:', err);
    }
  }
}