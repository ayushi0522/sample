import { Component, ChangeDetectionStrategy, OnDestroy, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { interval, Subscription } from 'rxjs';

interface SensorReading {
  id: string;
  value: string;
  unit: string;
  status: 'normal' | 'warning' | 'critical';
  timestamp: Date;
}

@Component({
  selector: 'app-live-sensor-widget',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './live-sensor-widget.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LiveSensorWidgetComponent implements OnInit, OnDestroy {
  readings = signal<SensorReading[]>([]);
  private subscription: Subscription | undefined;

  ngOnInit(): void {
    // Initial data
    this.addReading();
    this.addReading();

    // Add new reading every 12 seconds
    this.subscription = interval(12000).subscribe(() => {
      this.addReading();
    });
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }

  private addReading(): void {
    const sensorTypes = [
      { id: 'TEMP-01', unit: '°C', min: 18, max: 30, warn: 28, crit: 35 },
      { id: 'HUM-02', unit: '%', min: 40, max: 60, warn: 58, crit: 65 },
      { id: 'PRES-01', unit: 'hPa', min: 1000, max: 1020, warn: 1018, crit: 990 },
    ];
    const type = sensorTypes[Math.floor(Math.random() * sensorTypes.length)];
    const value = Math.random() * (type.max - type.min) + type.min;
    
    let status: 'normal' | 'warning' | 'critical' = 'normal';
    if (value >= type.crit || value < type.min - 5) {
      status = 'critical';
    } else if (value >= type.warn || value < type.min) {
      status = 'warning';
    }

    const newReading: SensorReading = {
      id: type.id,
      value: value.toFixed(1),
      unit: type.unit,
      status,
      timestamp: new Date(),
    };
    
    this.readings.update(currentReadings => [newReading, ...currentReadings.slice(0, 4)]);
  }
}