import { Component, ChangeDetectionStrategy, AfterViewInit, ElementRef, ViewChild, OnDestroy, input, effect, inject } from '@angular/core';
import { ThemeService, Theme } from '../../services/theme.service';

declare var Chart: any;

@Component({
  selector: 'app-doughnut-chart',
  template: '<canvas #doughnutCanvas class="w-full h-80"></canvas>',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DoughnutChartComponent implements AfterViewInit, OnDestroy {
  data = input<number[]>();
  
  @ViewChild('doughnutCanvas') doughnutCanvas!: ElementRef;
  chart: any;
  themeService = inject(ThemeService);
  
  constructor() {
      effect(() => {
        const chartData = this.data();
        if (this.chart && chartData) {
            this.chart.data.datasets[0].data = chartData;
            this.chart.update('none');
        }
      });

      effect(() => {
        this.themeService.theme(); // depend on theme
        if (this.chart) {
          this.updateChartTheme();
        }
      });
  }

  ngOnDestroy() {
      this.chart?.destroy();
  }

  ngAfterViewInit() {
    this.createChart();
  }
  
  private getCssVariable(variable: string): string {
    return getComputedStyle(document.documentElement).getPropertyValue(variable).trim();
  }

  private updateChartTheme(): void {
    const legendColor = this.getCssVariable('--text-tertiary');
    const borderColor = this.getCssVariable('--bg-primary');
    
    if (this.chart.options.plugins.legend) {
        this.chart.options.plugins.legend.labels.color = legendColor;
    }
    if (this.chart.data.datasets[0]) {
        this.chart.data.datasets[0].borderColor = borderColor;
    }
    
    this.chart.update();
  }

  createChart() {
    if (this.chart) this.chart.destroy();
    if (!this.doughnutCanvas) return;

    const legendColor = this.getCssVariable('--text-tertiary');
    const borderColor = this.getCssVariable('--bg-primary');
    const accentPrimary = this.getCssVariable('--accent-primary');
    const accentSecondary = this.getCssVariable('--accent-secondary');
    
    // Create lighter/darker shades for the chart
    const color = (hex: string, lum: number) => {
        hex = String(hex).replace(/[^0-9a-f]/gi, '');
        if (hex.length < 6) {
            hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
        }
        lum = lum || 0;
        let rgb = "#", c, i;
        for (i = 0; i < 3; i++) {
            c = parseInt(hex.substr(i*2,2), 16);
            c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
            rgb += ("00"+c).substr(c.length);
        }
        return rgb;
    }

    this.chart = new Chart(this.doughnutCanvas.nativeElement, {
      type: 'doughnut',
      data: {
        labels: ['Organic', 'Direct', 'Referral', 'Social'],
        datasets: [{
          label: 'Traffic Source',
          data: this.data() ?? [],
          backgroundColor: [
            accentPrimary,
            accentSecondary,
            color(accentPrimary, 0.2),
            color(accentSecondary, 0.2),
          ],
          hoverOffset: 8,
          borderColor: borderColor,
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '70%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
                color: legendColor,
                usePointStyle: true,
                boxWidth: 8
            }
          }
        }
      }
    });
  }
}