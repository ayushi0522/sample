import { Component, ChangeDetectionStrategy, AfterViewInit, ElementRef, ViewChild, OnDestroy, input, effect, inject } from '@angular/core';
import { ThemeService, Theme } from '../../services/theme.service';

declare var Chart: any;

@Component({
  selector: 'app-bar-chart-3d',
  standalone: true,
  template: '<canvas #barCanvas class="w-full h-80"></canvas>',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BarChart3dComponent implements AfterViewInit, OnDestroy {
  data = input<number[]>();
  
  @ViewChild('barCanvas') barCanvas!: ElementRef;
  chart: any;
  themeService = inject(ThemeService);

  constructor() {
    effect(() => {
      const chartData = this.data();
      if (this.chart && chartData) {
        this.chart.data.datasets[0].data = chartData;
        this.chart.update('none');
      }
    });

    effect(() => {
      this.themeService.theme(); // depend on theme
      if (this.chart) {
        this.updateChartTheme();
      }
    });
  }

  ngAfterViewInit() {
    this.createChart();
  }
  
  ngOnDestroy() {
      this.chart?.destroy();
  }

  private getCssVariable(variable: string): string {
    return getComputedStyle(document.documentElement).getPropertyValue(variable).trim();
  }
  
  private updateChartTheme(): void {
    const gridColor = this.getCssVariable('--border-primary');
    const ticksColor = this.getCssVariable('--text-tertiary');
    const borderColor = this.getCssVariable('--border-secondary');

    if (this.chart.options.scales) {
        this.chart.options.scales.x.grid.color = gridColor;
        this.chart.options.scales.x.ticks.color = ticksColor;
        this.chart.options.scales.y.grid.color = gridColor;
        this.chart.options.scales.y.ticks.color = ticksColor;
    }
    if (this.chart.data.datasets[0]) {
        this.chart.data.datasets[0].borderColor = borderColor;
    }
    this.chart.update();
  }

  createChart() {
    if (this.chart) this.chart.destroy();
    if (!this.barCanvas) return;

    const ctx = this.barCanvas.nativeElement.getContext('2d');
    
    const gridColor = this.getCssVariable('--border-primary');
    const ticksColor = this.getCssVariable('--text-tertiary');
    const borderColor = this.getCssVariable('--border-secondary');
    const accentPrimary = this.getCssVariable('--accent-primary');
    const accentSecondary = this.getCssVariable('--accent-secondary');

    this.chart = new Chart(ctx, {
      type: 'bar3d',
      data: {
        labels: ['NA', 'EU', 'APAC', 'LATAM', 'MEA', 'IND', 'CN'],
        datasets: [{
          label: 'Sales ($k)',
          data: this.data() ?? [],
          backgroundColor: [
            accentPrimary + 'CC',
            accentSecondary + 'CC',
            accentPrimary + 'AA',
            accentSecondary + 'AA',
            accentPrimary + '88',
            accentSecondary + '88',
            accentPrimary + '66'
          ],
          borderColor: borderColor,
          borderWidth: 1,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: { enabled: true },
        },
        scales: {
          x: { grid: { color: gridColor }, ticks: { color: ticksColor } },
          y: { grid: { color: gridColor }, ticks: { color: ticksColor }, beginAtZero: true }
        },
        z: 15,
        angle: 45,
      }
    });
  }
}