import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ThemeService } from './services/theme.service';
import { AlertService } from './services/alert.service';
import { AlertComponent } from './components/shared/alert/alert.component';

@Component({
  selector: 'app-root',
  template: `
    <main class="h-screen w-screen bg-[var(--bg-secondary)] text-[var(--text-primary)] relative">
      <router-outlet></router-outlet>
      @if(alertService.alert(); as alert) {
        <app-alert [message]="alert.message" [type]="alert.type"></app-alert>
      }
    </main>
  `,
  imports: [RouterOutlet, CommonModule, AlertComponent],
})
export class AppComponent {
  // Initialize theme service to apply the theme on startup
  private themeService = inject(ThemeService); 
  alertService = inject(AlertService);
}