import { Component, ChangeDetectionStrategy, signal, inject, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThemeService } from '../../services/theme.service';
import { AlertService } from '../../services/alert.service';

type UploadStatus = 'idle' | 'uploading' | 'success' | 'error';

@Component({
  selector: 'app-file-upload',
  imports: [CommonModule],
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FileUploadComponent {
  status = signal<UploadStatus>('idle');
  progress = signal(0);
  fileName = signal('');
  fileSize = signal('');
  isDragOver = signal(false);

  fileUploaded = output<File>();
  
  themeService = inject(ThemeService);
  alertService = inject(AlertService);

  private formatBytes(bytes: number, decimals = 2): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.simulateUpload(input.files[0]);
    }
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragOver.set(true);
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragOver.set(false);
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragOver.set(false);
    if (event.dataTransfer?.files && event.dataTransfer.files.length > 0) {
      this.simulateUpload(event.dataTransfer.files[0]);
      event.dataTransfer.clearData();
    }
  }

  private simulateUpload(file: File): void {
    this.fileName.set(file.name);
    this.fileSize.set(this.formatBytes(file.size));
    this.status.set('uploading');
    this.progress.set(0);

    const interval = setInterval(() => {
      this.progress.update(p => {
        const newProgress = p + Math.random() * 10;
        if (newProgress >= 100) {
          clearInterval(interval);
          this.status.set('success');
          this.alertService.showAlert('File ready for analysis!', 'success');
          this.fileUploaded.emit(file);
          return 100;
        }
        return newProgress;
      });
    }, 200);
  }

  reset(): void {
    this.status.set('idle');
    this.progress.set(0);
    this.fileName.set('');
    this.fileSize.set('');
  }
}
