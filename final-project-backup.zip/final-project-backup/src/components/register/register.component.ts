import { Component, ChangeDetectionStrategy, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

type RegisterStep = 'account' | 'verifyEmail' | 'verifyMobile' | 'details' | 'success';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RegisterComponent {
  private readonly authService = inject(AuthService);
  // FIX: Explicitly type the injected Router to resolve type inference issues.
  private readonly router: Router = inject(Router);

  currentStep = signal<RegisterStep>('account');

  // Form Signals
  email = signal('');
  password = signal('');
  mobile = signal('');
  emailOtp = signal('');
  mobileOtp = signal('');
  address = signal('');

  nextStep(): void {
    switch (this.currentStep()) {
      case 'account':
        // Simulate sending email OTP
        this.currentStep.set('verifyEmail');
        break;
      case 'verifyEmail':
        // Simulate verifying email OTP and sending mobile OTP
        this.currentStep.set('verifyMobile');
        break;
      case 'verifyMobile':
        // Simulate verifying mobile OTP
        this.currentStep.set('details');
        break;
      case 'details':
        // Simulate final registration
        this.currentStep.set('success');
        // Auto-login after a delay
        setTimeout(() => {
            this.authService.login(this.email(), this.password());
        }, 2000);
        break;
    }
  }

  goToLogin(): void {
    this.router.navigate(['/login']);
  }
}
