import { Component, ChangeDetectionStrategy, AfterViewInit, ElementRef, ViewChild, OnDestroy, input, effect, inject } from '@angular/core';
import { ThemeService, Theme } from '../../services/theme.service';

declare var Chart: any;

@Component({
  selector: 'app-bar-chart',
  template: '<canvas #barCanvas class="w-full h-80"></canvas>',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BarChartComponent implements AfterViewInit, OnDestroy {
  data = input<number[]>();
  
  @ViewChild('barCanvas') barCanvas!: ElementRef;
  chart: any;
  themeService = inject(ThemeService);

  constructor() {
    effect(() => {
      const chartData = this.data();
      if (this.chart && chartData) {
        this.chart.data.datasets[0].data = chartData;
        this.chart.update('none');
      }
    });

    effect(() => {
      this.themeService.theme(); // depend on theme signal
      if (this.chart) {
        this.updateChartTheme();
      }
    });
  }

  ngAfterViewInit() {
    this.createChart();
  }
  
  ngOnDestroy() {
      this.chart?.destroy();
  }
  
  private getCssVariable(variable: string): string {
    return getComputedStyle(document.documentElement).getPropertyValue(variable).trim();
  }

  private updateChartTheme(): void {
    const gridColor = this.getCssVariable('--border-primary');
    const ticksColor = this.getCssVariable('--text-tertiary');

    if (this.chart.options.scales) {
        this.chart.options.scales.x.grid.color = gridColor;
        this.chart.options.scales.x.ticks.color = ticksColor;
        this.chart.options.scales.y.ticks.color = ticksColor;
    }
    this.chart.update();
  }

  createChart() {
    if (this.chart) this.chart.destroy();
    if (!this.barCanvas) return;

    const ctx = this.barCanvas.nativeElement.getContext('2d');
    
    const accentPrimary = this.getCssVariable('--accent-primary');
    const accentSecondary = this.getCssVariable('--accent-secondary');
    const gridColor = this.getCssVariable('--border-primary');
    const ticksColor = this.getCssVariable('--text-tertiary');

    const gradient = ctx.createLinearGradient(0, 0, 0, 200);
    gradient.addColorStop(0, accentSecondary + 'CC'); // ~80% opacity
    gradient.addColorStop(1, accentPrimary + 'CC');   // ~80% opacity

    this.chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['NA', 'EU', 'APAC', 'LATAM', 'MEA'],
        datasets: [{
          label: 'Sales ($k)',
          data: this.data() ?? [],
          backgroundColor: gradient,
          borderColor: accentSecondary,
          borderWidth: 0,
          borderRadius: 6,
          barThickness: 12,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: 'y',
        scales: {
          x: { 
              grid: { color: gridColor },
              ticks: { color: ticksColor }
          },
          y: { 
              grid: { display: false },
              ticks: { color: ticksColor }
          }
        },
        plugins: {
          legend: {
            display: false,
          }
        }
      }
    });
  }
}
