import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Sidebar2Component } from '../sidebar2/sidebar2.component';
import { Header2Component } from '../header2/header2.component';

@Component({
  selector: 'app-dashboard2',
  standalone: true,
  imports: [
    RouterOutlet,
    Sidebar2Component,
    Header2Component,
  ],
  templateUrl: './dashboard2.component.html',
  styleUrls: ['./dashboard2.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Dashboard2Component {}
