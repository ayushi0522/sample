import { Component, ChangeDetectionStrategy, OnInit, OnDestroy, signal } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { LineChartComponent } from '../charts/line-chart.component';
import { DoughnutChartComponent } from '../charts/doughnut-chart.component';
import { FileUploadComponent } from '../file-upload/file-upload.component';
import { ModalComponent } from '../shared/modal/modal.component';
import { BarChartComponent } from '../charts/bar-chart.component';
import { LiveSensorWidgetComponent } from './live-sensor-widget.component';

@Component({
  selector: 'app-overview',
  standalone: true,
  imports: [
    CommonModule,
    LineChartComponent,
    DoughnutChartComponent,
    FileUploadComponent,
    ModalComponent,
    BarChartComponent,
    LiveSensorWidgetComponent,
  ],
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.css'],
  providers: [DecimalPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OverviewComponent implements OnInit, OnDestroy {
  // Stat Card Signals
  totalRevenue = signal(45231.89);
  revenueChange = signal(20.1);
  activeUsers = signal(2389);
  usersChange = signal(3.0);
  newSales = signal(1234);
  salesChange = signal(-5.4);
  deviceUptime = signal(99.8);

  // Chart Data Signals
  performanceData = signal([65, 59, 80, 81, 56, 55, 40, 60]);
  salesByRegionData = signal([120, 95, 150, 70, 45]);
  trafficSourceData = signal([300, 200, 100, 50]);

  // Modal Signal
  isModalOpen = signal(false);

  private intervalId?: number;

  constructor(private decimalPipe: DecimalPipe) {}

  ngOnInit() {
    this.intervalId = window.setInterval(
      () => this.updateDashboardData(),
      3000
    );
  }

  ngOnDestroy() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  openModal() {
    this.isModalOpen.set(true);
  }

  closeModal() {
    this.isModalOpen.set(false);
  }

  downloadReport(): void {
    const headers = ['Metric', 'Value', 'Change'];
    const data = [
      ['Total Revenue', this.decimalPipe.transform(this.totalRevenue(), '1.2-2'), `${this.decimalPipe.transform(this.revenueChange(), '1.1-1')}%`],
      ['Active Users', this.activeUsers(), `${this.decimalPipe.transform(this.usersChange(), '1.1-1')}%`],
      ['New Sales', this.newSales(), `${this.decimalPipe.transform(this.salesChange(), '1.1-1')}%`],
      ['Device Uptime', `${this.deviceUptime()}%`, 'N/A'],
    ];

    let csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(",") + "\n" 
      + data.map(e => e.join(",")).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "dashboard_report.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  private updateDashboardData(): void {
    // Update stat cards
    this.totalRevenue.update((value) => value + Math.random() * 100 - 40);
    this.revenueChange.set(Math.random() * 5 - 2.5);
    this.activeUsers.update(
      (value) => value + Math.floor(Math.random() * 20 - 10)
    );
    this.usersChange.set(Math.random() * 2 - 1);
    this.newSales.update(
      (value) => value + Math.floor(Math.random() * 10 - 5)
    );
    this.salesChange.set(Math.random() * 4 - 2);
    this.deviceUptime.update((value) =>
      parseFloat(
        Math.max(99, Math.min(99.9, value + (Math.random() * 0.2 - 0.1))).toFixed(
          1
        )
      )
    );

    // Update charts
    this.performanceData.update((data) => {
      const newData = [...data];
      const lastValue = newData[newData.length - 1] ?? 50;
      newData.shift();
      newData.push(Math.max(20, lastValue + Math.random() * 20 - 10));
      return newData;
    });

    this.salesByRegionData.update((data) =>
      data.map((value) => Math.max(20, value + Math.random() * 10 - 5))
    );

    this.trafficSourceData.update((data) =>
      data.map((value) => Math.max(30, value + Math.random() * 20 - 10))
    );
  }
}
