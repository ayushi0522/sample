import { Component, ChangeDetectionStrategy, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
// FIX: Import UserRole from AuthService to resolve type mismatch and remove local type definition.
import { AuthService, UserRole } from '../../services/auth.service';

interface MenuItem {
  name: string;
  iconName: 'overview' | 'devices' | 'tracking' | 'queries' | 'settings';
  link: string;
  roles: UserRole[]; // Roles that can see this item
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SidebarComponent {
  isExpanded = signal(true);
  authService = inject(AuthService);

  // FIX: Updated menu item roles to support new specialized user roles.
  private allMenuItems: MenuItem[] = [
    { name: 'Overview', iconName: 'overview', link: '/dashboard/overview', roles: ['Admin', 'Manager', 'User', 'IoT Supervisor', 'Financial Analyst', 'Lab Researcher', 'Data Engineer'] },
    { name: 'Devices', iconName: 'devices', link: '/dashboard/devices', roles: ['Admin', 'Manager', 'User', 'IoT Supervisor', 'Lab Researcher'] },
    { name: 'Tracking', iconName: 'tracking', link: '/dashboard/tracking', roles: ['Admin', 'Manager', 'User', 'IoT Supervisor'] },
    { name: 'Queries', iconName: 'queries', link: '/dashboard/queries', roles: ['Admin', 'Manager', 'User', 'Financial Analyst', 'Lab Researcher', 'Data Engineer'] },
    { name: 'Settings', iconName: 'settings', link: '/dashboard/settings', roles: ['Admin'] },
  ];

  // Filter menu items based on the current user's role
  menuItems = computed(() => {
    const userRole = this.authService.currentUser()?.role;
    if (!userRole) {
      return [];
    }
    return this.allMenuItems.filter(item => item.roles.includes(userRole));
  });

  toggleSidebar() {
    this.isExpanded.update(value => !value);
  }
}
