import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { OverviewComponent } from './components/overview/overview.component';
import { DevicesComponent } from './components/devices/devices.component';
import { TrackingComponent } from './components/tracking/tracking.component';
import { authGuard } from './guards/auth.guard';
import { RegisterComponent } from './components/register/register.component';
import { SettingsComponent } from './components/settings/settings.component';
import { QueriesComponent } from './components/queries/queries.component';
import { Login2Component } from './components/login2/login2.component';
import { Dashboard2Component } from './components/dashboard2/dashboard2.component';
import { ItineraryPlannerComponent } from './components/itinerary-planner/itinerary-planner.component';
import { IotLoginComponent } from './components/iot-login/iot-login.component';
import { FinanceLoginComponent } from './components/finance-login/finance-login.component';
import { LifescienceLoginComponent } from './components/lifescience-login/lifescience-login.component';
import { DataLoginComponent } from './components/data-login/data-login.component';

export const APP_ROUTES: Routes = [
  // Existing App Routes
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [authGuard],
    children: [
      { path: '', redirectTo: 'overview', pathMatch: 'full' },
      { path: 'overview', component: OverviewComponent },
      { path: 'devices', component: DevicesComponent },
      { path: 'tracking', component: TrackingComponent },
      { path: 'queries', component: QueriesComponent },
      {
        path: 'settings',
        component: SettingsComponent,
        canActivate: [authGuard],
        data: { roles: ['Admin'] },
      },
    ],
  },
  
  // New Travel Planner Routes
  { path: 'travel-login', component: Login2Component },
  {
    path: 'travel-dashboard',
    component: Dashboard2Component,
    canActivate: [authGuard],
    children: [
      { path: '', redirectTo: 'planner', pathMatch: 'full' },
      { path: 'planner', component: ItineraryPlannerComponent },
      // Future routes like 'my-trips' or 'profile' can be added here
    ]
  },

  // New Domain Specific Login Routes
  { path: 'iot-login', component: IotLoginComponent },
  { path: 'finance-login', component: FinanceLoginComponent },
  { path: 'lifescience-login', component: LifescienceLoginComponent },
  { path: 'data-login', component: DataLoginComponent },

  // Default and wildcard routes
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', redirectTo: '/login' },
];
