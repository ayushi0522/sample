import { Injectable, signal, effect, PLATFORM_ID, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

export type Theme = 'light' | 'dark' | 'neon-blue' | 'forest-green' | 'midnight-purple';

export interface ThemeOption {
  id: Theme;
  name: string;
}

@Injectable({
  providedIn: 'root',
})
export class ThemeService {
  private platformId = inject(PLATFORM_ID);
  
  themes: ThemeOption[] = [
    { id: 'light', name: 'Light' },
    { id: 'dark', name: 'Dark' },
    { id: 'neon-blue', name: 'Neon Blue' },
    { id: 'forest-green', name: 'Forest Green' },
    { id: 'midnight-purple', name: 'Midnight Purple' },
  ];
  
  theme = signal<Theme>('dark');

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      const storedTheme = localStorage.getItem('app-theme') as Theme | null;
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      this.theme.set(storedTheme || (prefersDark ? 'dark' : 'light'));

      effect(() => {
        const currentTheme = this.theme();
        // Remove all theme classes
        this.themes.forEach(t => document.documentElement.classList.remove(`theme-${t.id}`));
        // Add the current theme class
        document.documentElement.classList.add(`theme-${currentTheme}`);
        localStorage.setItem('app-theme', currentTheme);
      });
    }
  }

  setTheme(themeId: Theme): void {
    this.theme.set(themeId);
  }
}
