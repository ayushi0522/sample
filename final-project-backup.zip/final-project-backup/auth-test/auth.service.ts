import { Injectable, signal, PLATFORM_ID, inject, computed } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root',
})
export class AuthService {

   private API = 'http://localhost:8000';
  private platformId = inject(PLATFORM_ID);
  // FIX: Explicitly type the injected Router to resolve type inference issues.
  private router: Router = inject(Router);
  
  private authToken = signal<string | null>(null);
  
  isAuthenticated = computed(() => this.authToken() !== null);

  constructor(private http: HttpClient ) {
    if (isPlatformBrowser(this.platformId)) {
      this.authToken.set(localStorage.getItem('authToken'));
    }
  }
  register(data: any) {
    return this.http.post(`${this.API}/register`, data);
  }
  // login(email: string, password: string): void {
  //   // Simulate API call and getting a token
  //   const fakeToken = `fake-jwt-token-for-${email}`;
  //   this.setToken(fakeToken);
  // }

  // loginWithGoogle(): void {
  //   const fakeToken = 'fake-google-jwt-token';
  //   this.setToken(fakeToken);
  // }

  // logout(): void {
  //   this.clearToken();
  //   this.router.navigate(['/login']);
  // }


   login(data: any) {
    return this.http.post(`${this.API}/login`, data);
  }

  sendOtp(email: string) {
    return this.http.post(`${this.API}/send-otp?email=${email}`, {});
  }

  resetPassword(data: any) {
    return this.http.post(`${this.API}/reset-password`, data);
  }

  googleLogin() {
    return this.http.get(`${this.API}/auth/google`);
  }



   setToken(token: string): void {
    this.authToken.set(token);
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('authToken', token);
    }
  }

   clearToken(): void {
    this.authToken.set(null);
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('authToken');
    }
  }

   getToken() {
    return localStorage.getItem('authToken');
  }

   isLoggedIn(): boolean {
    return !!this.getToken();
  }

  logout() {
    localStorage.removeItem('authToken');
    this.router.navigate(['/login']);
  }
}
