import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  imports: [],
  templateUrl: './login.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent {
  private readonly router: Router = inject(Router);
  private authService = inject(AuthService);

  email ="";
  password = "";

  login(): void {

  this.authService.login({ email: this.email, password: this.password })
      .subscribe((res: any) => {
        this.authService.setToken(res.access_token);
        window.location.href = "/dashboard";
      }, err => {
        alert("Invalid credentials");
      });
  }

 googleLogin() {
    this.authService.googleLogin().subscribe((res: any) => {
      window.location.href = res.auth_url;  // Redirect to Google OAuth
    });
  }
}