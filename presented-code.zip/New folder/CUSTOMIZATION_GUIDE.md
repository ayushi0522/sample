# 🎨 Customization Guide - IoT Digital Twin Dashboard

## Quick Customization Tips

### 1. Change Factory Name

**File**: `src/components/iot-digital-twin/iot-digital-twin.component.html`

```html
<!-- Find line ~6 -->
<h1 class="dashboard-title">
  <span class="icon">🏭</span>
  Washing Machine Factory - Digital Twin Dashboard  <!-- Change this -->
</h1>
```

### 2. Add More Stations

**File**: `src/services/iot-production.service.ts`

In `initializeProductionLine()` method, add a new station:

```typescript
{
  id: 'packaging-inspection',
  name: 'Packaging Inspection',
  cycleTime: 30,
  downtime: 0,
  defectRate: 1.0,
  sensors: [
    {
      id: 'camera-pi-1',
      name: 'Visual Detection',
      value: 95,
      unit: '%',
      threshold: 100,
      status: 'normal',
    },
    // Add 2 more sensors...
  ],
  completed: 85,
  queue: 2,
  efficiency: 97,
  operatorName: 'Your Name',
  shiftStart: new Date(new Date().setHours(6, 0, 0)),
  shiftEnd: new Date(new Date().setHours(14, 0, 0)),
}
```

### 3. Adjust Update Frequency

**File**: `src/services/iot-production.service.ts`

```typescript
// Line ~300 - Change from 5000 (5 seconds) to desired milliseconds
private startRealTimeSimulation(): void {
  interval(5000).subscribe(() => {  // Change to 3000 for 3 seconds
    // ...
  });
}
```

**File**: `src/components/iot-alerts/iot-alerts.component.ts`

```typescript
// Line ~30 - Alert update frequency
interval(5000)  // Change this value
  .pipe(takeUntil(this.destroy$))
  .subscribe(() => {
    this.updateAlerts();
  });
```

### 4. Change Color Theme

**File**: Any `.component.css` file

Replace color values:

```css
/* Primary Blue → Your Color */
#3b82f6 → #YOUR_COLOR
#2563eb → #YOUR_COLOR_DARK

/* Success Green → Your Color */
#10b981 → #YOUR_COLOR
#059669 → #YOUR_COLOR_DARK

/* Warning Yellow → Your Color */
#f59e0b → #YOUR_COLOR
#d97706 → #YOUR_COLOR_DARK

/* Danger Red → Your Color */
#ef4444 → #YOUR_COLOR
#dc2626 → #YOUR_COLOR_DARK
```

### 5. Modify Sensor Thresholds

**File**: `src/services/iot-production.service.ts`

Change threshold values in sensor definitions:

```typescript
{
  id: 'temp-sm-1',
  name: 'Temperature',
  value: 68,
  unit: '°C',
  threshold: 85,  // Change this to your desired threshold
  status: 'normal',
}
```

### 6. Add Custom KPI Card

**File**: `src/components/iot-kpi-metrics/iot-kpi-metrics.component.html`

Add after existing KPI cards:

```html
<!-- Your Custom KPI -->
<div class="kpi-card info">
  <div class="kpi-icon">🎯</div>
  <div class="kpi-content">
    <span class="kpi-label">Your Metric</span>
    <span class="kpi-value">{{ yourValue }}</span>
    <span class="kpi-trend">Units</span>
  </div>
</div>
```

**File**: `src/components/iot-kpi-metrics/iot-kpi-metrics.component.ts`

Add the method:

```typescript
getYourValue(): number {
  if (!this.productionData) return 0;
  // Your calculation logic
  return 100;
}
```

### 7. Change Simulation Range

**File**: `src/components/iot-production-simulation/iot-production-simulation.component.ts`

```typescript
simulationHours: number = 8;  // Default hours
maxHours: number = 24;        // Maximum hours - change as needed
```

### 8. Modify Alert Severity Logic

**File**: `src/services/iot-production.service.ts`

In `getAlerts()` method:

```typescript
// Change thresholds for alerts
if (station.downtime > 10) {  // Change threshold
  alerts.push({
    stationId: station.id,
    stationName: station.name,
    message: `Downtime: ${Math.round(station.downtime)} minutes`,
    severity: 'critical',
  });
}
```

### 9. Add New Tab

**Step 1**: Create new component:
```bash
# In project directory
ng generate component components/iot-your-tab --standalone
```

**Step 2**: Import in `iot-digital-twin.component.ts`:
```typescript
import { YourTabComponent } from '../iot-your-tab/iot-your-tab.component';

@Component({
  // ...
  imports: [
    // ...existing imports
    YourTabComponent,
  ],
})
```

**Step 3**: Add tab button in `iot-digital-twin.component.html`:
```html
<button
  class="tab-button"
  [class.active]="activeTab === 'yourtab'"
  (click)="setActiveTab('yourtab')"
>
  <span class="tab-icon">🎯</span> Your Tab
</button>
```

**Step 4**: Add tab content:
```html
<div *ngIf="activeTab === 'yourtab'" class="tab-pane">
  <app-iot-your-tab></app-iot-your-tab>
</div>
```

**Step 5**: Update TypeScript:
```typescript
activeTab: 'overview' | 'stations' | 'simulation' | 'alerts' | 'yourtab' = 'overview';
```

### 10. Change Login Credentials

**File**: `src/components/iot-login/iot-login.component.ts`

```typescript
email = signal('supervisor@iot.com');    // Change default email
password = signal('password');           // Change default password
```

Or modify the authentication logic in `src/services/auth.service.ts`

### 11. Add More Operators

**File**: `src/services/iot-production.service.ts`

Change operator names in station definitions:

```typescript
operatorName: 'John Smith',  // Change to any name
```

### 12. Modify Cycle Time Ranges

**File**: `src/services/iot-production.service.ts`

In `updateStationData()` method:

```typescript
updated.cycleTime = Math.max(
  30,  // Minimum cycle time - change this
  station.cycleTime + (Math.random() - 0.5) * 10  // Variation - change this
);
```

### 13. Custom Defect Rate Calculation

**File**: `src/services/iot-production.service.ts`

Modify defect rates in station initialization or add dynamic calculation:

```typescript
defectRate: 2.5,  // Static percentage

// Or add method for dynamic calculation
calculateDefectRate(station: StationData): number {
  // Your logic here
  return station.downtime * 0.1 + Math.random();
}
```

### 14. Add Station Images/Icons

**File**: `src/components/iot-station-monitoring/iot-station-monitoring.component.html`

Add image element:

```html
<div class="station-card">
  <img src="assets/images/station-{{station.id}}.png" alt="{{station.name}}" />
  <!-- Rest of card content -->
</div>
```

**File**: Create images in `src/assets/images/` folder

### 15. Export Data Feature

**File**: `src/components/iot-kpi-metrics/iot-kpi-metrics.component.ts`

Add export method:

```typescript
exportToCSV(): void {
  if (!this.productionData) return;
  
  const csv = this.productionData.stations.map(s => 
    `${s.name},${s.efficiency},${s.completed},${s.queue}`
  ).join('\n');
  
  const header = 'Station,Efficiency,Completed,Queue\n';
  const blob = new Blob([header + csv], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'production-data.csv';
  link.click();
}
```

Add button in template:

```html
<button (click)="exportToCSV()">📥 Export CSV</button>
```

### 16. Add Sound Alerts

**File**: `src/components/iot-alerts/iot-alerts.component.ts`

```typescript
private playAlertSound(): void {
  const audio = new Audio('assets/sounds/alert.mp3');
  audio.play();
}

updateAlerts(): void {
  const newAlerts = this.iotService.getAlerts().map((alert) => ({
    ...alert,
    timestamp: new Date(),
  }));
  
  // Play sound if critical alert
  if (newAlerts.some(a => a.severity === 'critical')) {
    this.playAlertSound();
  }
  
  // ... rest of method
}
```

Add sound file to `src/assets/sounds/alert.mp3`

### 17. Dark/Light Theme Toggle

**File**: Create new service or add to theme.service.ts

```typescript
toggleTheme(): void {
  document.body.classList.toggle('light-theme');
}
```

**File**: Add CSS variables in global styles:

```css
:root {
  --bg-primary: #1e293b;
  --text-primary: #ffffff;
}

.light-theme {
  --bg-primary: #ffffff;
  --text-primary: #000000;
}
```

Use variables in component CSS:

```css
background: var(--bg-primary);
color: var(--text-primary);
```

### 18. Real-Time Charts

Install chart library:

```bash
npm install chart.js ng2-charts
```

Add to component:

```typescript
import { BaseChartDirective } from 'ng2-charts';
import { ChartConfiguration } from 'chart.js';

@Component({
  imports: [BaseChartDirective],
  // ...
})
export class YourComponent {
  public lineChartData: ChartConfiguration['data'] = {
    datasets: [
      {
        data: [65, 59, 80, 81, 56, 55, 40],
        label: 'Efficiency',
      },
    ],
    labels: ['Hour 1', 'Hour 2', 'Hour 3', 'Hour 4', 'Hour 5', 'Hour 6', 'Hour 7'],
  };
}
```

### 19. Add Notifications API

**File**: Any component

```typescript
showNotification(message: string): void {
  if ('Notification' in window && Notification.permission === 'granted') {
    new Notification('IoT Alert', {
      body: message,
      icon: 'assets/icons/factory.png',
    });
  }
}

requestNotificationPermission(): void {
  if ('Notification' in window) {
    Notification.requestPermission();
  }
}
```

### 20. Connect to Real API

**File**: `src/services/iot-production.service.ts`

Replace simulated data with HTTP calls:

```typescript
import { HttpClient } from '@angular/common/http';

constructor(private http: HttpClient) {}

getProductionLine(): Observable<ProductionLineSnapshot> {
  return this.http.get<ProductionLineSnapshot>('https://your-api.com/production-line');
}
```

Remember to add HttpClient to providers!

---

## Environment Configuration

Create environment files for different setups:

**File**: `src/environments/environment.ts`

```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000',
  updateInterval: 5000,
  defaultSimulationHours: 8,
  maxSimulationHours: 24,
  factoryName: 'Washing Machine Factory',
};
```

**File**: `src/environments/environment.prod.ts`

```typescript
export const environment = {
  production: true,
  apiUrl: 'https://api.yourfactory.com',
  updateInterval: 3000,
  defaultSimulationHours: 8,
  maxSimulationHours: 48,
  factoryName: 'Your Factory Name',
};
```

Use in services:

```typescript
import { environment } from '../environments/environment';

interval(environment.updateInterval).subscribe(() => {
  // ...
});
```

---

## Tips & Best Practices

1. **Test After Changes**: Always test after modifications
2. **Keep Backups**: Save original files before major changes
3. **Consistent Naming**: Follow existing naming conventions
4. **Comment Your Code**: Add comments for custom logic
5. **TypeScript Types**: Maintain type safety
6. **Responsive Design**: Test on different screen sizes
7. **Performance**: Monitor for memory leaks
8. **Accessibility**: Add ARIA labels where needed
9. **Documentation**: Update documentation for changes
10. **Version Control**: Use git for tracking changes

---

**Happy Customizing! 🎨🔧**
