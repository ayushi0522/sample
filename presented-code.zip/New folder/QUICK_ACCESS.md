# Quick Access Instructions

## 🚀 To See the IoT Dashboard:

### Step 1: Make sure the server is running
If not already running:
```powershell
cd c:\ayushi\sample-main\sample-main\final-project-backup\final-project-backup
npm start
```

### Step 2: Open your browser
Navigate to **ONE** of these URLs (they're all the same, just pick one):

**Option A - Direct to IoT Login:**
```
http://localhost:4200/iot-login
```

**Option B - Let it redirect:**
```
http://localhost:4200
```

### Step 3: Login
- **Email:** `user@example.com`
- **Password:** `password`
- Click **Sign In**

### Step 4: You should see:
✅ **IoT Digital Twin Dashboard** with:
- Left sidebar with 🏭 IoT Twin logo
- 6 menu items (📊 Dashboard, 🤖 AI Analytics, etc.)
- Main content area with KPIs
- Production line grid with 7 stations
- Header with theme selector at top

---

## ❌ If You Still See the Old Dashboard

This means you're on the **wrong route**. The old dashboard is at `/dashboard`, not `/iot-dashboard`.

### Check your browser URL:
- ✅ **CORRECT:** `http://localhost:4200/iot-dashboard/dashboard`
- ❌ **WRONG:** `http://localhost:4200/dashboard` (this is the old one!)

### How to fix:
1. **Clear your browser cache** (Very important!)
   - Press `Ctrl + Shift + Delete`
   - Select "Cached images and files"
   - Click "Clear data"

2. **Hard reload the page:**
   - Press `Ctrl + F5` (Windows)
   - Or `Ctrl + Shift + R`

3. **Try incognito/private mode:**
   - Press `Ctrl + Shift + N` (Chrome/Edge)
   - Press `Ctrl + Shift + P` (Firefox)
   - Then go to `http://localhost:4200/iot-login`

4. **Manually navigate:**
   - Type in address bar: `http://localhost:4200/iot-login`
   - Press Enter
   - Login again

---

## 🎨 If Theme is Not Applied

The theme should match your selected theme from the header.

### Check:
1. **In browser DevTools (Press F12):**
   - Go to **Elements** tab
   - Look at `<body>` element
   - Should have class like: `theme-dark` or `theme-light` or `theme-neon-blue`

2. **If no theme class:**
   - Click the theme selector (🎨 icon) in the header
   - Select any theme (Dark, Light, etc.)
   - It should update immediately

3. **If theme selector not visible:**
   - You might still be on the old dashboard
   - Follow the steps above to get to IoT dashboard

---

## 🔍 How to Tell Which Dashboard You're On

### OLD Dashboard (Regular Dashboard):
- URL: `http://localhost:4200/dashboard/overview`
- Sidebar items: Overview, Devices, Tracking, Queries, Settings
- No emoji icons
- Regular UI

### NEW IoT Dashboard (What you want):
- URL: `http://localhost:4200/iot-dashboard/dashboard`
- Sidebar items: Dashboard 📊, AI Analytics 🤖, Machine Status ⚙️, etc.
- Emoji icons everywhere
- IoT Twin logo 🏭
- Production line visualization

---

## 🛠️ Quick Commands

### Stop the server:
```powershell
# Press Ctrl + C in the terminal
```

### Restart the server:
```powershell
npm start
```

### Clear Angular cache:
```powershell
npx ng cache clean
```

### Rebuild from scratch:
```powershell
Remove-Item -Recurse -Force node_modules
npm install
npm start
```

---

## 📞 Still Not Working?

1. **Take a screenshot** of what you're seeing
2. **Check the browser URL** - copy and paste it
3. **Open browser console** (F12) and check for red errors
4. **Share these three things** and we can diagnose the issue

---

## ✨ What Success Looks Like

After login, you should see this layout:

```
╔════════════════════════════════════════════════════╗
║ [Theme 🎨] [User Menu 👤]                         ║
╠═══════╦════════════════════════════════════════════╣
║ 🏭    ║  IoT Digital Twin Dashboard                ║
║ IoT   ║  Last Update: 10:30:45 AM                  ║
║ Twin  ║  ────────────────────────────────          ║
║       ║  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐     ║
║ ────  ║  │ 1234 │ │ 87%  │ │ 7/7  │ │  3   │     ║
║ 📊 D  ║  │Units │ │Effic.│ │Active│ │Alert │     ║
║ 🤖 AI ║  └──────┘ └──────┘ └──────┘ └──────┘     ║
║ ⚙️ M  ║  ────────────────────────────────          ║
║ 🔔 A  ║  Production Line Stations:                 ║
║ 📈 An ║  [🔧 Sheet] [🥁 Drum] [⚡ Motor]            ║
║ 🎮 S  ║  [🔌 Wire] [🔩 Assm] [✅ Test] [📦 Pack]   ║
║       ║                                             ║
║ Online║                                             ║
║  ⚫   ║                                             ║
╚═══════╩════════════════════════════════════════════╝
```

Key things to look for:
- ✅ 🏭 IoT Twin logo in sidebar
- ✅ Emoji icons (📊 🤖 ⚙️ 🔔 📈 🎮)
- ✅ "System Online" at bottom of sidebar
- ✅ KPI cards showing numbers
- ✅ Production stations with emojis
- ✅ Theme colors applied (not plain white)

---

**Quick Link:** http://localhost:4200/iot-login

**Remember:** Clear cache if you see the old dashboard!
