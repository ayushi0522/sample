# 🎯 IMPORTANT: How to Access the IoT Dashboard

## ⚠️ Common Issue: Seeing the Old Dashboard

If you're seeing the **old dashboard** without the sidebar or with old theme, you're on the **WRONG URL**.

---

## ✅ CORRECT Way to Access IoT Dashboard

### Method 1: Direct Link (RECOMMENDED)
1. **Stop your current browser session**
2. **Clear browser cache** (Ctrl + Shift + Delete)
3. **Type this URL directly:**
   ```
   http://localhost:4200/iot-login
   ```
4. **Login with:**
   - Email: `user@example.com`
   - Password: `password`
5. **You will be redirected to:** `http://localhost:4200/iot-dashboard/dashboard`

### Method 2: Force Navigation
If you're already logged in to the old dashboard:
1. **In the browser address bar, type:**
   ```
   http://localhost:4200/iot-dashboard
   ```
2. **Press Enter**
3. **You should see the IoT dashboard with sidebar**

---

## 🔍 How to Know You're on the RIGHT Dashboard

### IoT Dashboard (NEW - What You Want):
```
URL: http://localhost:4200/iot-dashboard/dashboard
                              ^^^^^^^^^^^^
                              This part is KEY!

Sidebar Menu Items:
├─ 📊 Dashboard
├─ 🤖 AI Analytics
├─ ⚙️ Machine Status
├─ 🔔 Alerts
├─ 📈 Analytics
└─ 🎮 Simulator

Logo: 🏭 IoT Twin Manufacturing
```

### Old Dashboard (WRONG - Not What You Want):
```
URL: http://localhost:4200/dashboard/overview
                              ^^^^^^^^^
                              NO "iot-" prefix!

Sidebar Menu Items:
├─ Overview
├─ Devices
├─ Tracking
├─ Queries
└─ Settings

Logo: Regular app logo (no IoT)
```

---

## 🚨 Key Differences at a Glance

| Feature | Old Dashboard | IoT Dashboard (NEW) |
|---------|--------------|---------------------|
| **URL** | `/dashboard` | `/iot-dashboard` |
| **Login URL** | `/login` | `/iot-login` |
| **Emojis in Menu** | ❌ No | ✅ Yes (📊🤖⚙️🔔📈🎮) |
| **IoT Twin Logo** | ❌ No | ✅ Yes (🏭) |
| **Production Stations** | ❌ No | ✅ Yes (7 stations) |
| **Sidebar Footer** | ❌ No | ✅ "System Online" ⚫ |
| **Real-time Sensors** | ❌ No | ✅ Yes (21 sensors) |

---

## 🛠️ Troubleshooting Steps

### Step 1: Verify You're on IoT Login
**Check your URL:** Should be `http://localhost:4200/iot-login`

**You should see:**
- "IoT Digital Twin Dashboard" title
- "Manufacturing Production Line Monitor" subtitle
- Factory/industry themed design

**If you see regular login page instead:**
- You're at `/login` (wrong!)
- Navigate to `/iot-login` (correct!)

### Step 2: After Login, Check URL
**Immediately after clicking "Sign In", your URL should become:**
```
http://localhost:4200/iot-dashboard/dashboard
```

**If URL is:**
- `/dashboard/overview` → You logged into OLD dashboard
- `/iot-dashboard/dashboard` → ✅ Correct! You're on IoT dashboard

### Step 3: Look for Visual Indicators
**You should immediately see:**
1. ✅ **Sidebar on the left** with:
   - 🏭 IoT Twin logo at top
   - 6 menu items with emojis
   - System Online indicator at bottom

2. ✅ **Header at top** with:
   - Theme selector (🎨)
   - User menu
   - Current time

3. ✅ **Main content** with:
   - 4 KPI cards (Units, Efficiency, Active Stations, Alerts)
   - Production line grid with 7 stations
   - Each station has emoji icon

**If you DON'T see these:**
- You're on the wrong dashboard
- Follow Method 2 above to force navigate

---

## 🎨 About the Theme

The IoT dashboard uses the **same theme system** as your main dashboard.

### To Change Theme:
1. Click the palette icon (🎨) in the header (top right)
2. Select a theme:
   - Light
   - Dark  
   - Neon Blue
   - Forest Green
   - Midnight Purple
3. The IoT dashboard will update immediately

### If Theme Not Applying:
1. Make sure you're on `/iot-dashboard` (not `/dashboard`)
2. Themes only work when CSS variables are loaded
3. Try switching theme manually with the selector
4. Hard reload (Ctrl + F5)

---

## 🔄 Fresh Start Instructions

If nothing works, do a complete fresh start:

### Step 1: Logout
- Click user menu in header
- Click "Logout"
- You should be redirected to login page

### Step 2: Clear Everything
```powershell
# In your browser:
1. Press Ctrl + Shift + Delete
2. Select "All time"
3. Check all boxes
4. Click "Clear data"
```

### Step 3: Close All Browser Tabs
- Close ALL tabs of your application
- Close the browser completely
- Reopen browser

### Step 4: Navigate Fresh
1. Open browser
2. Type: `http://localhost:4200/iot-login`
3. Login
4. Should work!

---

## 📋 Quick Checklist

Before asking for help, verify:

- [ ] Server is running (`npm start`)
- [ ] URL is `http://localhost:4200/iot-login` (not `/login`)
- [ ] After login, URL is `/iot-dashboard/dashboard` (not `/dashboard`)
- [ ] Browser cache is cleared
- [ ] Tried incognito/private mode
- [ ] Checked browser console (F12) for errors
- [ ] Looked at page source to verify components loaded

---

## 🎯 Success Criteria

You know you're on the correct IoT dashboard when you see ALL of these:

1. ✅ URL contains `/iot-dashboard/`
2. ✅ Sidebar visible on the left
3. ✅ 🏭 IoT Twin logo in sidebar
4. ✅ Emoji icons in menu (📊🤖⚙️🔔📈🎮)
5. ✅ "System Online ⚫" at sidebar bottom
6. ✅ 4 KPI cards in main area
7. ✅ 7 production station cards
8. ✅ Theme colors applied
9. ✅ Real-time timestamp updating

**If you see ALL 9 items above → SUCCESS! You're on the IoT dashboard! 🎉**

**If you're missing ANY of the above → You're on the wrong dashboard or have a loading issue.**

---

## 🆘 Last Resort

If you've tried EVERYTHING and it still doesn't work:

1. **Take a screenshot** of your current page
2. **Copy the URL** from your browser address bar
3. **Open browser DevTools** (Press F12)
4. **Go to Console tab**
5. **Screenshot any red errors**
6. **Share all 3 screenshots**

This will help diagnose the exact issue.

---

## ✨ Remember

**TWO SEPARATE DASHBOARDS:**
1. **Old Dashboard** - `/dashboard` (logistics/tracking)
2. **IoT Dashboard** - `/iot-dashboard` (manufacturing/IoT) ← **YOU WANT THIS ONE!**

**TWO SEPARATE LOGINS:**
1. **Old Login** - `/login` (for old dashboard)
2. **IoT Login** - `/iot-login` (for IoT dashboard) ← **USE THIS ONE!**

---

**Quick Access Link:** [http://localhost:4200/iot-login](http://localhost:4200/iot-login)

**Good luck!** 🚀
