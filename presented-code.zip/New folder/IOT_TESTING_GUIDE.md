# IoT Dashboard Testing Guide

## Overview
This guide will help you test all features of the IoT Digital Twin Dashboard for the washing machine factory production line.

## Testing Checklist

### 1. Initial Access
- [ ] Navigate to http://localhost:4200/iot-login
- [ ] Login with credentials (user@example.com / password)
- [ ] Verify redirect to /iot-dashboard
- [ ] Confirm sidebar is visible and expanded by default

### 2. Sidebar Navigation
- [ ] **Dashboard Tab** (📊) - Loads main overview
  - Production line visualization with 7 stations
  - 4 KPI cards (Units Produced, Efficiency, Active Stations, Alerts)
  - Real-time timestamp updates
  
- [ ] **AI Analytics Tab** (🤖) - Loads KPI metrics
  - Grid of metric cards with icons
  - Color-coded borders (primary, success, warning, danger, info)
  - Trend indicators with percentages
  
- [ ] **Machine Status Tab** (⚙️) - Loads station monitoring
  - Grid of 7 station cards (Sheet Metal, Drum & Tub, Motor, etc.)
  - Detail panel on the right when station is selected
  - Real-time sensor data (temperature, vibration, energy)
  
- [ ] **Alerts Tab** (🔔) - Loads alerts management
  - Filter buttons (All, Critical, Warning, Info)
  - Alert list with severity badges
  - Dismiss and clear all functionality
  
- [ ] **Analytics Tab** (📈) - Loads analytics view
  - Same as AI Analytics (reuses KPI metrics)
  - Performance trends and insights
  
- [ ] **Simulator Tab** (🎮) - Loads production simulation
  - Hour range slider (1-24 hours)
  - Hourly forecast chart
  - AI insights (bottlenecks, peak production, optimization)

### 3. Sidebar Functionality
- [ ] Click toggle button (☰) to collapse sidebar
- [ ] Verify icons remain visible when collapsed
- [ ] Verify text labels hide when collapsed
- [ ] Click toggle again to expand sidebar
- [ ] Verify smooth animations during expand/collapse
- [ ] Check "System Online" status indicator at bottom

### 4. Theme Consistency
Test all themes and verify IoT dashboard adapts:

#### Light Theme
- [ ] Background: White (#ffffff)
- [ ] Text: Dark slate (#1e293b)
- [ ] Accent: Sky blue (#0ea5e9)
- [ ] Cards have subtle borders

#### Dark Theme
- [ ] Background: Dark slate (#1e293b)
- [ ] Text: Light gray (#f8fafc)
- [ ] Accent: Light sky (#38bdf8)
- [ ] Cards blend with dark background

#### Neon Blue Theme
- [ ] Background: Deep navy (#0a192f)
- [ ] Accent: Cyan (#64ffda)
- [ ] Futuristic glow effects

#### Forest Green Theme
- [ ] Background: Dark teal (#2d3a3a)
- [ ] Accent: Amber (#ffab40)
- [ ] Nature-inspired palette

#### Midnight Purple Theme
- [ ] Background: Deep purple (#2c2a4a)
- [ ] Accent: Light purple (#ba68c8)
- [ ] Modern purple tones

**How to switch themes:**
1. Click the palette icon (🎨) in the header
2. Select a theme from the dropdown
3. Verify IoT dashboard updates instantly

### 5. Real-Time Data Updates
- [ ] Watch the timestamp in dashboard header update every second
- [ ] Observe KPI values change every 5 seconds
- [ ] Check station efficiency bars animate
- [ ] Verify new alerts appear in the alerts list
- [ ] Confirm sensor readings update in real-time

### 6. Production Line Visualization
- [ ] All 7 stations display in grid layout
- [ ] Each station shows:
  - Station name with emoji icon
  - Status badge (Operational/Warning/Critical)
  - Efficiency percentage
  - Cycle time
  - Units processed today
- [ ] Hover effects work on station cards
- [ ] Color coding: Green (>85%), Yellow (70-85%), Red (<70%)

### 7. Station Monitoring Details
- [ ] Click on any station card
- [ ] Detail panel opens on the right
- [ ] Verify it shows:
  - Station name and operator
  - Current status
  - Key metrics (efficiency, cycle time, throughput)
  - Real-time sensor readings
  - Historical performance chart
  - Recent events timeline
- [ ] Click different stations to switch details
- [ ] Close detail panel functionality

### 8. Production Simulation
- [ ] Drag slider to select hours (1-24)
- [ ] Verify hours display updates
- [ ] Check forecast chart renders
- [ ] Confirm AI insights update based on prediction:
  - Potential bottlenecks
  - Peak production hours
  - Optimization opportunities
- [ ] Try different hour ranges

### 9. Alerts Management
- [ ] Verify alerts list shows all alerts
- [ ] Click "Critical" filter - only red alerts show
- [ ] Click "Warning" filter - only yellow alerts show
- [ ] Click "Info" filter - only blue alerts show
- [ ] Click "All" to see everything again
- [ ] Dismiss individual alerts by clicking X
- [ ] Click "Clear All" to remove all alerts
- [ ] Verify badge counts update correctly

### 10. Responsive Design
Test on different screen sizes:

#### Desktop (>1024px)
- [ ] Sidebar expanded by default
- [ ] Grid layouts show multiple columns
- [ ] All content visible without scrolling horizontally

#### Tablet (768px - 1024px)
- [ ] Sidebar can collapse/expand
- [ ] Grid layouts adapt to 2 columns
- [ ] Content remains readable

#### Mobile (<768px)
- [ ] Sidebar starts collapsed
- [ ] Grid layouts become single column
- [ ] Touch-friendly button sizes
- [ ] Horizontal scrolling where needed

### 11. Navigation Flow
- [ ] Navigate from Dashboard to AI Analytics
- [ ] URL changes to /iot-dashboard/ai-analytics
- [ ] Active menu item highlights
- [ ] Navigate to Machine Status
- [ ] URL changes to /iot-dashboard/machine-status
- [ ] Test all routes:
  - /iot-dashboard/dashboard
  - /iot-dashboard/ai-analytics
  - /iot-dashboard/machine-status
  - /iot-dashboard/alerts
  - /iot-dashboard/analytics
  - /iot-dashboard/simulator

### 12. Performance
- [ ] Page loads quickly (<2 seconds)
- [ ] No lag when switching tabs
- [ ] Smooth animations (60fps)
- [ ] Data updates don't cause stuttering
- [ ] Memory usage remains stable over time

### 13. Data Service Integration
- [ ] Open browser DevTools console
- [ ] Verify no errors in console
- [ ] Check IoTProductionService is providing data
- [ ] Confirm observables are updating every 5 seconds
- [ ] Verify predictive simulation calculations work

### 14. Edge Cases
- [ ] Refresh page while on specific route (e.g., /iot-dashboard/alerts)
- [ ] Verify it loads correct view
- [ ] Try navigating with browser back/forward buttons
- [ ] Test with slow network throttling
- [ ] Verify graceful handling of missing data

### 15. Accessibility
- [ ] Tab through navigation items with keyboard
- [ ] Verify focus indicators are visible
- [ ] Test with screen reader (basic)
- [ ] Check color contrast ratios
- [ ] Ensure all interactive elements are keyboard accessible

## Common Issues & Solutions

### Issue: Sidebar doesn't collapse
**Solution:** Check that IotSidebarComponent is properly imported and the toggle button event is bound correctly.

### Issue: Routes don't load child components
**Solution:** Verify `<router-outlet>` exists in iot-digital-twin.component.html and routes are configured in app.routes.ts.

### Issue: Data not updating
**Solution:** Check that IoTProductionService is provided in the component and subscriptions are active.

### Issue: Theme not applying
**Solution:** Verify CSS variables are defined in index.html and components use `var(--variable-name)` syntax.

### Issue: Styles look broken
**Solution:** Ensure all CSS files are properly imported in component decorators.

## Browser Compatibility

Test on:
- [ ] Chrome (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest)
- [ ] Edge (latest)

## Final Validation

After completing all tests:
- [ ] No console errors
- [ ] No broken images or icons
- [ ] All animations smooth
- [ ] Data flows correctly
- [ ] Theme switching works
- [ ] Responsive on all devices
- [ ] Navigation is intuitive
- [ ] Real-time updates functioning

## Success Criteria

✅ All 7 production stations display correctly
✅ Sidebar navigation works for all 6 sections
✅ Real-time data updates every 5 seconds
✅ Themes apply consistently across all views
✅ Responsive design works on mobile, tablet, desktop
✅ No console errors or warnings
✅ Smooth performance (60fps animations)
✅ Auth guard protects routes properly

## Reporting Issues

If you find any issues:
1. Note the exact steps to reproduce
2. Include browser and OS information
3. Capture screenshots or videos
4. Check browser console for errors
5. Document expected vs actual behavior

---

**Happy Testing!** 🚀
