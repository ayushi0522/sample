# 🏭 IoT Digital Twin Dashboard - Washing Machine Factory

## Overview

This is a comprehensive **Digital Twin Dashboard** for a washing machine production line. It provides real-time monitoring, predictive simulation, and intelligent analytics for optimizing manufacturing operations.

## 🎯 Features

### 1. **Real-Time Production Monitoring**
- Live tracking of all 7 production stations:
  - Sheet Metal Processing
  - Drum & Tub Assembly
  - Motor Assembly
  - Wiring & Connections
  - Final Assembly
  - Quality Testing
  - Packing & Shipping

### 2. **Digital Twin Capabilities**
- **Real Data Monitoring**:
  - Cycle time at each station
  - Downtime events tracking
  - Sensor data (temperature, vibration, energy, pressure, noise)
  - Quality defect tracking
  
- **Virtual Model**:
  - Complete station representation
  - Buffer and queue management
  - Operator shift tracking
  - Product routing visualization

- **Predictive Simulation**:
  - 1-24 hour production forecasting
  - Queue buildup prediction
  - Downtime impact analysis
  - Bottleneck identification
  - Actionable recommendations

### 3. **Key Performance Indicators (KPI)**
- Overall line efficiency
- Total units completed
- Work in queue
- Estimated time to completion
- Average downtime across stations
- Defect rate estimation
- Top performing stations
- Bottleneck detection

### 4. **Station Monitoring**
- Detailed view of each station
- Real-time sensor data with thresholds
- Efficiency metrics
- Operator information
- Shift timing
- Interactive station selection
- Downtime simulation for testing

### 5. **Smart Alerts System**
- Real-time notifications
- Critical, warning, and info level alerts
- Station-specific issues
- Sensor threshold violations
- Filter by severity
- Alert history tracking

### 6. **Production Simulation**
- Configurable time horizon (1-24 hours)
- Expected completion predictions
- Queue length forecasts
- Downtime accumulation
- Bottleneck identification
- Key insights and recommendations

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- Angular 21+
- Modern web browser

### Installation

1. Navigate to the project directory:
```bash
cd c:\ayushi\sample-main\sample-main\final-project-backup\final-project-backup
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to:
```
http://localhost:4200
```

### Login

Use the IoT Login page with the following credentials:
- **Email**: supervisor@iot.com
- **Password**: password

## 📊 Dashboard Components

### Main Dashboard (`iot-digital-twin`)
- Central hub for all IoT monitoring
- Tab-based navigation (Overview, Stations, Simulation, Alerts)
- Real-time status bar with key metrics
- Production line flow visualization

### Station Monitoring (`iot-station-monitoring`)
- Grid view of all stations
- Detailed sensor monitoring
- Performance metrics per station
- Interactive station selection
- Test downtime events

### Production Simulation (`iot-production-simulation`)
- Adjustable time horizon slider
- Hourly predictions
- Visual progress indicators
- Summary statistics
- Key insights panel

### KPI Metrics (`iot-kpi-metrics`)
- 6 main KPI cards
- Top performers ranking
- Issues and bottlenecks list
- Performance matrix
- Real-time production flow

### Alerts (`iot-alerts`)
- Live alert feed
- Severity filtering
- Alert statistics
- Empty state for no alerts
- Clear all functionality

## 🎨 UI/UX Features

- **Modern Dark Theme**: Professional industrial dashboard aesthetic
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Real-Time Updates**: Data refreshes every 5 seconds
- **Smooth Animations**: Engaging transitions and effects
- **Color-Coded Status**: Intuitive visual indicators
- **Interactive Elements**: Hover effects and click interactions
- **Gradient Accents**: Beautiful color gradients
- **Backdrop Blur**: Modern glassmorphism effects

## 🔧 Technical Architecture

### Services
- **IotProductionService**: 
  - Manages production line data
  - Real-time simulation engine
  - Alert generation
  - Historical data tracking
  - Predictive analytics

### Components
- Standalone Angular components
- OnPush change detection for performance
- RxJS for reactive data streams
- Signal-based state management
- Type-safe TypeScript interfaces

### Data Flow
1. Service generates simulated real-time data
2. Components subscribe to observables
3. UI updates automatically via change detection
4. User interactions trigger service methods
5. Predictions calculated on-demand

## 📈 Simulation Logic

The digital twin uses sophisticated algorithms:

1. **Cycle Time Variation**: ±10 seconds random variation
2. **Downtime Events**: 5% probability per update
3. **Queue Management**: Based on upstream/downstream flow
4. **Efficiency Calculation**: Factors in downtime and defects
5. **Bottleneck Detection**: Identifies slowest stations
6. **Predictive Modeling**: Linear projection with current metrics

## 🎯 Use Cases

1. **Production Managers**: Monitor overall line performance
2. **Station Supervisors**: Track individual station metrics
3. **Maintenance Teams**: Respond to sensor alerts
4. **Quality Control**: Monitor defect rates
5. **Operations Planning**: Use simulations for capacity planning
6. **Executives**: View KPI dashboard for decision making

## 🔐 Security

- Authentication required via AuthGuard
- Domain-specific user roles
- Secure session management

## 🌟 Future Enhancements

- [ ] Machine learning-based predictions
- [ ] Historical trend analysis
- [ ] Maintenance scheduling
- [ ] Energy consumption optimization
- [ ] Integration with real IoT devices (MQTT, OPC UA)
- [ ] Export reports to PDF/Excel
- [ ] Custom alert rules
- [ ] Mobile app
- [ ] AR/VR visualization
- [ ] Multi-factory support

## 📝 License

This project is part of a portfolio demonstration.

## 👥 Credits

Developed as an IoT Digital Twin solution for manufacturing optimization.

---

**Last Updated**: December 2025
**Version**: 1.0.0
