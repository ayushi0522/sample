# 🔍 Clickable Bottleneck Details - Quick Guide

## Overview
The bottleneck warning badges in the flow diagram are now **clickable**, allowing users to view detailed information about each bottleneck in a beautiful popup modal.

---

## 📸 Visual Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    FLOW DIAGRAM                                  │
│                                                                   │
│  ┌──────────┐     ┌──────────┐     ┌──────────┐                │
│  │ 🟢 Prep  │ →   │ 🔴 Cut   │ →   │ 🟢 Pack  │                │
│  │  75%     │     │  95%     │     │  80%     │                │
│  └──────────┘     └──────────┘     └──────────┘                │
│                   │ ⚠️ BOTTLENECK   │                            │
│                   │ 🔍 Click details│ ← CLICKABLE!              │
│                   └─────────────────┘                            │
└─────────────────────────────────────────────────────────────────┘
                             ↓ USER CLICKS
┌─────────────────────────────────────────────────────────────────┐
│                   BOTTLENECK DETAILS POPUP                       │
│  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓  │
│  ┃ 🔴 Bottleneck Details: Cutting Station            [X]   ┃  │
│  ┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┫  │
│  ┃                                                           ┃  │
│  ┃  Severity Level                                          ┃  │
│  ┃  ┌─────────────┐                                         ┃  │
│  ┃  │  CRITICAL   │ (Red badge)                            ┃  │
│  ┃  └─────────────┘                                         ┃  │
│  ┃                                                           ┃  │
│  ┃  Impact                                                  ┃  │
│  ┃  ┌───────────────────────────────────────────────────┐  ┃  │
│  ┃  │ This station is operating at 95% utilization,    │  ┃  │
│  ┃  │ causing delays and limiting throughput by 15%.   │  ┃  │
│  ┃  └───────────────────────────────────────────────────┘  ┃  │
│  ┃                                                           ┃  │
│  ┃  Recommended Actions                                     ┃  │
│  ┃  ✓ Implement predictive maintenance                     ┃  │
│  ┃  ✓ Add a second cutting line to distribute load        ┃  │
│  ┃  ✓ Optimize material queue management                   ┃  │
│  ┃                                                           ┃  │
│  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🎯 How It Works

### 1. **Bottleneck Detection**
When the API response includes `bottleneck: true` for a station:
```typescript
"station_utilization": {
  "cutting_station": {
    "baseline": 0.85,
    "scenario": 0.95,
    "delta_pct": 11.76,
    "bottleneck": true  // ← Triggers bottleneck UI
  }
}
```

### 2. **Visual Indicators Appear**
- Red border on node card
- Red pulsing utilization bar
- Red icon (🔴)
- **"⚠️ BOTTLENECK" warning badge**

### 3. **Conditional Clickability**
The warning badge becomes clickable ONLY if detailed bottleneck data exists:

```html
<div class="bottleneck-warning" 
     (click)="openBottleneckDetails(station.key, message.report)"
     [class.clickable]="message.report.bottlenecks && message.report.bottlenecks[station.key]">
  ⚠️ BOTTLENECK
  @if (message.report.bottlenecks && message.report.bottlenecks[station.key]) {
    <span class="details-hint">🔍 Click for details</span>
  }
</div>
```

### 4. **User Interaction**
- **Hover:** Badge scales up, cursor changes to pointer
- **Click:** Opens popup modal with details
- **Click outside/X button:** Closes popup

---

## 📋 Required API Response Structure

For the popup to work, include `bottlenecks` in your API response:

```json
{
  "report": {
    "summary": { /* ... */ },
    "kpi_comparison": { /* ... */ },
    "station_utilization": {
      "cutting_station": {
        "baseline": 0.85,
        "scenario": 0.95,
        "delta_pct": 11.76,
        "bottleneck": true  // ← Must be true
      }
    },
    "bottlenecks": {
      "cutting_station": {  // ← Must match station key
        "severity": "Critical",  // Or "High", "Medium", "Low"
        "impact": "This station is operating at 95% utilization, causing delays in downstream processes and limiting overall throughput by approximately 15%.",
        "recommendations": [
          "Implement predictive maintenance to reduce downtime",
          "Add a second cutting line to distribute load",
          "Optimize material queue management"
        ]
      }
    }
  }
}
```

---

## 🎨 Severity Badge Colors

The popup displays color-coded severity badges:

| Severity   | Color   | CSS Class             | Badge Style                |
|------------|---------|----------------------|----------------------------|
| **CRITICAL** | Red     | `.severity-critical` | `#ef4444` with shadow     |
| **HIGH**     | Orange  | `.severity-high`     | `#f59e0b` with shadow     |
| **MEDIUM**   | Yellow  | `.severity-medium`   | `#eab308` with shadow     |
| **LOW**      | Blue    | `.severity-low`      | `#3b82f6` with shadow     |

---

## 🔧 Component Methods

### Opening the Popup
```typescript
openBottleneckDetails(station: string, report: SimulationReport) {
  if (report.bottlenecks && report.bottlenecks[station]) {
    this.selectedBottleneck.set({
      station: station,
      details: report.bottlenecks[station]
    });
  }
}
```

### Closing the Popup
```typescript
closeBottleneckPopup() {
  this.selectedBottleneck.set(null);
}
```

### State Management
```typescript
selectedBottleneck = signal<{ station: string; details: any } | null>(null);
```

---

## 💡 User Experience Features

### ✅ Visual Feedback
- **Clickable hint:** "🔍 Click for details" appears below warning
- **Hover effect:** Badge scales to 105% with darker red background
- **Cursor change:** Pointer cursor indicates clickability

### ✅ Smooth Animations
- **Popup entrance:** 0.3s fade-in + slide-up animation
- **Backdrop blur:** Blurs background for focus
- **Close button:** Rotates 90° on hover

### ✅ Accessibility
- **Click outside to close:** Intuitive dismissal
- **X button:** Clear close action
- **Keyboard support:** ESC key closes popup (future enhancement)
- **Focus management:** Traps focus within modal

### ✅ Responsive Design
- **Mobile:** Full-width popup with scrolling
- **Tablet:** Medium-sized popup with padding
- **Desktop:** Max-width 600px centered modal

---

## 🧪 Testing Scenarios

### Scenario 1: Complete Data
**API Response:** Includes `bottlenecks` object with station details  
**Expected:** Badge is clickable, popup displays all information

### Scenario 2: Missing Bottleneck Details
**API Response:** `bottleneck: true` but no `bottlenecks` object  
**Expected:** Badge displays but is NOT clickable, no hint text

### Scenario 3: No Bottlenecks
**API Response:** No stations marked as bottlenecks  
**Expected:** No warning badges display at all

### Scenario 4: Partial Details
**API Response:** Some stations have bottleneck details, others don't  
**Expected:** Only stations with details are clickable

---

## 📱 Mobile Experience

```
┌─────────────────────────────┐
│  📱 MOBILE VIEW              │
│                              │
│  [Flow Diagram Scrolls →]   │
│                              │
│  ┌──────────┐               │
│  │ 🔴 Cut   │               │
│  │  95%     │               │
│  └──────────┘               │
│  │ ⚠️ BTL   │ ← Tap here   │
│  │ 🔍 Click │               │
│  └──────────┘               │
│         ↓                    │
│  ╔══════════════════════╗   │
│  ║ 🔴 Cutting Station   ║   │
│  ║                 [X]  ║   │
│  ╠══════════════════════╣   │
│  ║ Severity            ║   │
│  ║ [CRITICAL]          ║   │
│  ║                      ║   │
│  ║ Impact              ║   │
│  ║ Operating at 95%... ║   │
│  ║                      ║   │
│  ║ Actions             ║   │
│  ║ ✓ Add capacity      ║   │
│  ║ ✓ Optimize flow     ║   │
│  ╚══════════════════════╝   │
└─────────────────────────────┘
```

---

## 🎯 Implementation Checklist

- ✅ Added `bottlenecks` to `SimulationReport` interface
- ✅ Created `selectedBottleneck` signal for state management
- ✅ Implemented `openBottleneckDetails()` method
- ✅ Implemented `closeBottleneckPopup()` method
- ✅ Added conditional `[class.clickable]` to warning badge
- ✅ Added "🔍 Click for details" hint text
- ✅ Created popup overlay with backdrop blur
- ✅ Styled popup with animations (fadeIn, slideUp)
- ✅ Added severity badge with color coding
- ✅ Styled impact section with red left border
- ✅ Created recommendations list with checkmarks
- ✅ Added close button with rotation animation
- ✅ Implemented click-outside-to-close functionality
- ✅ Made fully responsive for all screen sizes
- ✅ Tested with sample data

---

## 🚀 Quick Start

### Step 1: Ensure Your API Returns Bottleneck Details
```python
# Python backend example
response = {
    "report": {
        # ... other fields ...
        "bottlenecks": {
            "cutting_station": {
                "severity": "Critical",
                "impact": "Detailed impact description...",
                "recommendations": [
                    "Action 1",
                    "Action 2",
                    "Action 3"
                ]
            }
        }
    }
}
```

### Step 2: User Interaction
1. User sends simulation query
2. Report displays with flow diagram
3. Bottleneck stations show warning badge
4. User clicks "⚠️ BOTTLENECK" badge
5. Popup appears with detailed information
6. User reviews severity, impact, and recommendations
7. User closes popup and returns to report

### Step 3: Test Everything
```powershell
# Start your backend
python app.py

# Start Angular dev server
ng serve

# Navigate to Production Simulation
# Send a query that triggers bottlenecks
# Click the bottleneck warning badges
```

---

## 📚 Related Files

**Component:**
- `src/components/iot-simulation-chat/iot-simulation-chat.component.ts`
- `src/components/iot-simulation-chat/iot-simulation-chat.component.html`
- `src/components/iot-simulation-chat/iot-simulation-chat.component.css`

**Documentation:**
- `SIMULATION_CHAT_COMPLETE_FEATURES.md` - All features summary
- `IOT_SIMULATION_CHAT_GUIDE.md` - Complete implementation guide
- `STATION_UTILIZATION_FINAL_SUMMARY.md` - Visual indicators

---

**Status:** ✅ FULLY IMPLEMENTED AND TESTED  
**Last Updated:** December 6, 2025
