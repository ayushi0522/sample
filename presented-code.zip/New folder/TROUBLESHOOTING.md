# 🔧 IoT Dashboard Troubleshooting Guide

## Issue: Not Seeing IoT Dashboard or Theme Not Applied

### Quick Fixes to Try First:

### 1️⃣ Clear Browser Cache
```powershell
# Press in your browser:
Ctrl + Shift + Delete
# Or
Ctrl + F5 (Hard reload)
```

### 2️⃣ Restart Development Server
```powershell
# Stop the server (Ctrl + C in terminal)
# Then restart:
cd c:\ayushi\sample-main\sample-main\final-project-backup\final-project-backup
npm start
```

### 3️⃣ Access the Correct URL
Make sure you're navigating to:
```
http://localhost:4200/iot-login
```

NOT:
- ❌ `http://localhost:4200/login` (Old login)
- ❌ `http://localhost:4200/dashboard` (Old dashboard)
- ❌ `http://localhost:4200` (Redirects to iot-login but may have cache)

---

## Step-by-Step Verification

### Step 1: Check if Server is Running
Open browser to: `http://localhost:4200`

**Expected:** Should redirect to `/iot-login`

**If you see old login page:**
- Clear browser cache
- Try incognito/private mode
- Hard reload (Ctrl + F5)

### Step 2: Login to IoT Dashboard
On the IoT login page:
- Enter email: `user@example.com`
- Enter password: `password`
- Click "Sign In"

**Expected:** Should redirect to `/iot-dashboard/dashboard`

### Step 3: Verify Sidebar is Visible
After login, you should see:
- ✅ Left sidebar with IoT Twin logo (🏭)
- ✅ 6 menu items with emoji icons
- ✅ Toggle button (☰) at top
- ✅ "System Online" status at bottom

**If sidebar is NOT visible:**
```powershell
# Check browser console (F12) for errors
# Look for import errors or routing issues
```

### Step 4: Verify Theme is Applied
The page should use theme colors from your theme selector.

**Check:**
- Background should match selected theme
- Text colors should match theme
- Cards should have theme borders
- No hardcoded dark/light colors

**If theme is NOT applied:**
- Check if CSS variables are loaded in browser DevTools
- Look at `<body>` element - should have theme class like `theme-dark`
- Verify `index.html` contains theme CSS variables

---

## Common Issues & Solutions

### Issue 1: "Old Dashboard Still Showing"
**Cause:** Browser cache or wrong URL

**Solution:**
1. Open browser DevTools (F12)
2. Go to Network tab
3. Check "Disable cache"
4. Hard reload (Ctrl + Shift + R)
5. Navigate to `http://localhost:4200/iot-login`

### Issue 2: "Sidebar Not Visible"
**Cause:** Component not loaded or CSS issue

**Solution:**
1. Open browser console (F12)
2. Check for errors like:
   - "Cannot find module"
   - "Component not found"
3. Verify in Elements tab that `<app-iot-sidebar>` element exists
4. Check if CSS file is loaded

**Debug commands:**
```powershell
# Check if component files exist
Test-Path "c:\ayushi\sample-main\sample-main\final-project-backup\final-project-backup\src\components\iot-sidebar\iot-sidebar.component.ts"
Test-Path "c:\ayushi\sample-main\sample-main\final-project-backup\final-project-backup\src\components\iot-sidebar\iot-sidebar.component.html"
Test-Path "c:\ayushi\sample-main\sample-main\final-project-backup\final-project-backup\src\components\iot-sidebar\iot-sidebar.component.css"
```

### Issue 3: "Theme Colors Not Applied"
**Cause:** CSS variables not loaded or body class missing

**Solution:**
1. Open DevTools (F12)
2. Go to Elements tab
3. Check `<body>` element should have class like: `theme-dark` or `theme-light`
4. In Styles panel, verify CSS variables exist:
   - `--bg-primary`
   - `--text-primary`
   - `--accent-primary`

**If variables are missing:**
- Check `index.html` contains theme styles
- Verify ThemeService is working
- Try switching theme manually with header selector

### Issue 4: "Routes Not Working"
**Cause:** Routing configuration issue

**Solution:**
1. Check browser URL when clicking sidebar items
2. Should change to:
   - `/iot-dashboard/dashboard`
   - `/iot-dashboard/ai-analytics`
   - `/iot-dashboard/machine-status`
   - etc.

**If URL doesn't change:**
- Check RouterLink directives in sidebar HTML
- Verify RouterOutlet exists in main component
- Check app.routes.ts configuration

### Issue 5: "Blank Page After Login"
**Cause:** Child route not loading

**Solution:**
1. Check browser console for errors
2. Verify default child route redirects to 'dashboard'
3. Check if IotDashboardViewComponent is properly imported

---

## Browser DevTools Checklist

### Console Tab
✅ No red errors
✅ No "Cannot find module" errors
✅ No "Component not registered" errors

### Network Tab
✅ All JS files loading (200 status)
✅ All CSS files loading (200 status)
✅ No 404 errors

### Elements Tab
✅ `<app-iot-sidebar>` element exists
✅ `<app-header>` element exists  
✅ `<router-outlet>` element exists
✅ `<body>` has theme class

### Application Tab
✅ localStorage has auth token
✅ Session storage has user data

---

## Nuclear Option: Complete Reset

If nothing works, try this complete reset:

```powershell
# Stop the server (Ctrl + C)

# Clear node modules and reinstall
Remove-Item -Recurse -Force node_modules
Remove-Item -Force package-lock.json
npm install

# Clear Angular cache
npm cache clean --force
npx ng cache clean

# Rebuild and restart
npm start
```

---

## Verification Commands

Run these to verify setup:

```powershell
# 1. Check if IoT components exist
Get-ChildItem -Path "c:\ayushi\sample-main\sample-main\final-project-backup\final-project-backup\src\components" -Filter "iot-*" -Directory

# Expected output: 7 directories
# - iot-alerts
# - iot-dashboard-view
# - iot-digital-twin
# - iot-kpi-metrics
# - iot-login
# - iot-production-simulation
# - iot-sidebar
# - iot-station-monitoring

# 2. Check if service exists
Test-Path "c:\ayushi\sample-main\sample-main\final-project-backup\final-project-backup\src\services\iot-production.service.ts"

# Expected: True

# 3. Check if routes file is correct
Get-Content "c:\ayushi\sample-main\sample-main\final-project-backup\final-project-backup\src\app.routes.ts" | Select-String "iot-dashboard"

# Expected: Multiple matches showing iot-dashboard routes
```

---

## What You SHOULD See

### After Login Screen:
```
┌────────────────────────────────────────────────────────┐
│ [Theme Selector 🎨] [User Menu]                       │
├──────────┬─────────────────────────────────────────────┤
│ 🏭 IoT   │  IoT Digital Twin Dashboard                 │
│ Twin     │  ──────────────────────────────            │
│          │  [KPI Cards]                                │
│ 📊 Dash  │  • Units Produced: 1,234                    │
│ 🤖 AI    │  • Efficiency: 87%                          │
│ ⚙️ Mach  │  • Active Stations: 7/7                    │
│ 🔔 Alert │  • Alerts: 3                                │
│ 📈 Anal  │  ──────────────────────────────            │
│ 🎮 Sim   │  [Production Line Grid]                     │
│          │  [Sheet Metal] [Drum] [Motor] [Wiring]     │
│ System   │  [Assembly] [Testing] [Packaging]          │
│ Online ⚫│                                             │
└──────────┴─────────────────────────────────────────────┘
```

### Key Visual Elements:
- ✅ Sidebar on the left with emojis
- ✅ Header at top with theme selector
- ✅ Main content area showing dashboard
- ✅ Theme colors applied (not plain white/black)
- ✅ "System Online" indicator in sidebar footer

---

## Still Having Issues?

### Check These Files Exist and Have Content:

```powershell
# Core component files
Test-Path "src\components\iot-digital-twin\iot-digital-twin.component.ts"
Test-Path "src\components\iot-sidebar\iot-sidebar.component.ts"
Test-Path "src\components\iot-dashboard-view\iot-dashboard-view.component.ts"

# Service file
Test-Path "src\services\iot-production.service.ts"

# Route configuration
Test-Path "src\app.routes.ts"

# All should return: True
```

### Check Component Imports in Routes:
Open `app.routes.ts` and verify these imports exist:
```typescript
import { IotDigitalTwinComponent } from './components/iot-digital-twin/iot-digital-twin.component';
import { IotDashboardViewComponent } from './components/iot-dashboard-view/iot-dashboard-view.component';
import { IotSidebarComponent } from './components/iot-sidebar/iot-sidebar.component';
```

---

## Contact Points

If you're still stuck after trying all of the above:
1. Screenshot browser console errors
2. Screenshot the current page you're seeing
3. Share the browser URL
4. Check if Angular CLI version is compatible

```powershell
# Check Angular version
ng version

# Should be Angular 18+
```

---

**Last Updated:** December 5, 2025
**Version:** 1.0
