# 🚀 IoT Sensor Streams - Quick Start

## ⚡ 30-Second Setup

```bash
# Already integrated! No installation needed.
# Just navigate to the page.
```

---

## 📍 Access in 3 Steps

### 1️⃣ Login
```
http://localhost:4200
↓
Enter credentials
↓
Click "Login"
```

### 2️⃣ Navigate
```
IoT Dashboard
↓
Sidebar: Click "📡 Sensor Streams"
↓
Page loads
```

### 3️⃣ Explore
```
Click tabs: 🌡️ | 〰️ | ⚡ | 📈
↓
View real-time graphs
↓
Check station readings
```

---

## 🎯 What You'll See

```
┌────────────────────────────────┐
│  📊 Real-Time Sensor Streams   │
├────────────────────────────────┤
│  [🌡️] [〰️] [⚡] [📈]          │
├────────────────────────────────┤
│  Stats: Avg | Max | Count      │
├────────────────────────────────┤
│  📈 Live Graph (updates 5s)   │
├────────────────────────────────┤
│  7 Station Cards with Readings │
└────────────────────────────────┘
```

---

## 📊 4 Tabs Explained

| Click | Shows | When to Use |
|-------|-------|-------------|
| 🌡️ Temp | Temperature across all stations | Check for overheating |
| 〰️ Vibration | Mechanical vibration levels | Monitor equipment health |
| ⚡ Energy | Power consumption patterns | Optimize energy usage |
| 📈 Combined | All sensors in one view | Quick system overview |

---

## ⏱️ Update Frequency

```
Real-time data updates: Every 5 seconds
Chart displays: Last 20 data points
Time window: ~100 seconds of history
```

---

## 🎨 Status Colors

```
🟢 Green   = Normal    (All good!)
🟡 Amber   = Warning   (Watch this)
🔴 Red     = Critical  (Take action!)
```

---

## 💡 Quick Tips

✅ **Best for**: Desktop/laptop viewing  
✅ **Mobile**: Use landscape mode  
✅ **Performance**: Keep tab active  
✅ **Data**: Wait 5s after page load  
✅ **Themes**: All 5 themes supported  

---

## 🔍 What to Monitor

### Temperature Tab
```
Look for: Rising trends
Alert if: Any station > 85°C
Action: Check cooling system
```

### Vibration Tab
```
Look for: Sudden spikes
Alert if: Value > 4 mm/s
Action: Schedule maintenance
```

### Energy Tab
```
Look for: High consumption
Alert if: Total > 150 kW
Action: Optimize production
```

### Combined Tab
```
Look for: Correlations
Alert if: Multiple warnings
Action: System-wide check
```

---

## 📱 Shortcuts

| Action | Desktop | Mobile |
|--------|---------|--------|
| Navigate | Click sidebar | Swipe menu |
| Switch tab | Click tab | Tap tab |
| View details | Hover card | Tap card |
| Scroll tabs | Mouse wheel | Swipe left/right |

---

## ✅ Quick Check

After opening the page:

- [ ] Can you see 4 tabs?
- [ ] Does the chart display?
- [ ] Do station cards show data?
- [ ] Does data update after 5s?
- [ ] Do tabs switch correctly?

**All ✅? You're good to go!**

---

## 🆘 Common Issues

### Chart Not Showing
```
Wait 5 seconds for first data
Refresh page (Ctrl+F5)
Check console for errors
```

### Tabs Not Working
```
Click directly on tab button
Wait for animation to complete
Check browser compatibility
```

### Data Not Updating
```
Keep browser tab active
Check internet connection
Verify service is running
```

---

## 🎓 Learn More

Full guides available:
- `IOT_SENSOR_STREAMS_GUIDE.md` - Complete documentation
- `SENSOR_STREAMS_QUICK_REF.md` - Quick reference
- `SENSOR_STREAMS_VISUAL_GUIDE.md` - Visual examples

---

## 📸 Screenshot Checklist

Take screenshots of:
1. ✅ Full page view (Temperature tab)
2. ✅ Active chart with data
3. ✅ Station reading cards
4. ✅ All 4 tabs visible
5. ✅ Mobile responsive view

---

## 🎯 Success Criteria

You're successfully using Sensor Streams if:

✅ You can navigate to the page  
✅ All tabs are clickable  
✅ Chart displays and updates  
✅ Station cards show live data  
✅ Status colors appear correctly  
✅ Page is responsive on your device  

---

## 🚀 Next Steps

1. **Explore all tabs** - See different sensor types
2. **Watch updates** - Observe real-time changes
3. **Check stations** - Review individual readings
4. **Monitor trends** - Identify patterns over time
5. **Use combined view** - Quick system health check

---

## 📞 Need Help?

**Quick answers:**
- Not loading? Wait 5 seconds
- No data? Check service status
- Tabs frozen? Refresh browser
- Theme wrong? Use settings

**Still stuck?**
Check `TROUBLESHOOTING.md`

---

## 🎉 You're Ready!

```
🎯 Goal: Monitor sensor streams
✅ Tool: Sensor Streams component
📊 View: Real-time graphs
⏱️ Update: Every 5 seconds
🌡️ Metrics: Temp, Vibration, Energy
```

**Happy monitoring! 📡**

---

**Quick Start Version**: 1.0  
**Last Updated**: December 5, 2025  
**Estimated Read Time**: 2 minutes
