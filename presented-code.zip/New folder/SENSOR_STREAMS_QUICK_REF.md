# Quick Reference - IoT Sensor Streams

## 🎯 Access Path
```
IoT Dashboard → Sidebar → 📡 Sensor Streams
URL: http://localhost:4200/iot-dashboard/sensor-streams
```

## 📊 Tabs Overview

| Tab | Icon | Shows | Metrics |
|-----|------|-------|---------|
| **Temperature** | 🌡️ | Thermal readings | Avg, Max, Count |
| **Vibration** | 〰️ | Mechanical health | Avg, Max, Count |
| **Energy** | ⚡ | Power consumption | Avg, Total, Count |
| **Combined** | 📈 | All sensor types | Temp, Vib, Energy |

## 🔢 Key Features

✅ **Real-time updates** every 5 seconds  
✅ **20-point rolling window** for smooth graphs  
✅ **7 production stations** monitored  
✅ **3 sensor types** tracked per station  
✅ **Color-coded status** (Normal/Warning/Critical)  
✅ **Theme-compatible** with all 5 themes  
✅ **Fully responsive** on all devices  

## 📐 Layout Structure

```
┌──────────────────────────────────────┐
│ Header: Real-Time Sensor Streams    │
├──────────────────────────────────────┤
│ [🌡️ Temp] [〰️ Vib] [⚡ Energy] [📈]  │
├──────────────────────────────────────┤
│ [Avg: X] [Max: Y] [Count: 7]        │
├──────────────────────────────────────┤
│        Line Chart (20 points)        │
│            📈                         │
├──────────────────────────────────────┤
│ Station Readings (Grid)              │
│ [Station 1] [Station 2] [Station 3] │
└──────────────────────────────────────┘
```

## 🎨 Visual Elements

### Tab Active State
- Gradient background: Blue → Purple
- White text color
- Glowing shadow effect
- Badge highlighted

### Stat Cards
- Gradient text values
- Hover lift effect (3px)
- Animated top accent bar
- Smooth transitions

### Station Cards
- Status color indicators
- Hover border highlight
- Compact information display
- Click-ready appearance

### Chart
- Smooth line animation
- Auto-scaling Y-axis
- Theme-colored grid
- No animation on updates (real-time feel)

## 🔧 Technical Specs

### Data Flow
```
Service (5s) → Component → Filter → Array → Chart
```

### Sensor Mapping
- **Temperature**: All 7 stations have temp sensors
- **Vibration**: Subset of stations (4-5)
- **Energy**: All 7 stations (Power Consumption)

### Status Thresholds
```typescript
Normal:   value < threshold * 0.7
Warning:  value >= threshold * 0.7
Critical: value >= threshold * 0.9
```

### Status Colors
```typescript
Normal:   #10b981 (Green)
Warning:  #f59e0b (Amber)
Critical: #ef4444 (Red)
```

## 📱 Responsive Breakpoints

| Screen | Stats Grid | Station Grid | Tabs |
|--------|-----------|-------------|------|
| Desktop (>1024px) | 3-col | 3-col | Full labels |
| Tablet (768-1024px) | 2-col | 2-col | Full labels |
| Mobile (<768px) | 1-col | 1-col | Icons only |
| Small (<480px) | 1-col | 1-col | Minimal |

## 🧪 Quick Test Checklist

- [ ] Navigate to Sensor Streams page
- [ ] All 4 tabs clickable
- [ ] Chart displays and updates
- [ ] Station cards show data
- [ ] Statistics calculate correctly
- [ ] Status colors appear
- [ ] Hover effects work
- [ ] Responsive on mobile
- [ ] Works on all themes

## 🚀 Files Modified/Created

### Created:
```
src/components/iot-sensor-streams/
├── iot-sensor-streams.component.ts
├── iot-sensor-streams.component.html
└── iot-sensor-streams.component.css
```

### Modified:
```
src/app.routes.ts                     (Added route)
src/components/iot-sidebar/
└── iot-sidebar.component.ts          (Added menu item)
```

## 💡 Pro Tips

1. **Best View**: Desktop with 1920x1080 resolution
2. **Quick Navigation**: Use keyboard shortcuts (if enabled)
3. **Data Accuracy**: Wait 5 seconds for first update after page load
4. **Performance**: Keep browser tab active for continuous updates
5. **Debugging**: Check console for any service errors

## 🎯 Common Use Cases

### Monitor Temperature Trends
1. Click **Temperature** tab
2. Watch for rising values
3. Check which stations exceed threshold

### Check Energy Consumption
1. Click **Energy** tab
2. View total consumption
3. Identify high-usage stations

### Quick System Health Check
1. Click **Combined** tab
2. View all metrics at once
3. Scan for warning/critical status

### Track Mechanical Health
1. Click **Vibration** tab
2. Look for abnormal spikes
3. Schedule maintenance if needed

## 📊 Sample Data

### Typical Values:
```
Temperature:  55-75°C
Vibration:    1.5-3.5 mm/s
Energy:       2-25 kW
Combined:     Normalized 0-100
```

### Update Rate:
```
Interval:     5 seconds
Buffer Size:  20 points
Time Span:    ~100 seconds visible
```

## 🔗 Related Pages

- **Dashboard**: Main production overview
- **Machine Status**: Detailed station info
- **Alerts**: Critical notifications
- **Simulator**: Predictive analytics

## 📞 Quick Help

**Not updating?**  
→ Check IoT service is running

**Chart blank?**  
→ Wait 5 seconds for first data point

**Wrong theme?**  
→ Use theme selector in header

**Mobile issues?**  
→ Use landscape mode for better view

---

**Status**: ✅ Production Ready  
**Last Updated**: December 5, 2025  
**Version**: 1.0
