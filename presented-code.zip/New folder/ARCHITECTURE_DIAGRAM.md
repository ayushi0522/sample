# 🏗️ IoT Dashboard Architecture Diagram

## 📐 System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         User Browser                             │
└────────────────────────────────┬────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Angular Application                         │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    App Routes                            │   │
│  │  /iot-login → IotLoginComponent                         │   │
│  │  /iot-dashboard → IotDigitalTwinComponent [AuthGuard]   │   │
│  │    ├── dashboard → IotDashboardViewComponent           │   │
│  │    ├── ai-analytics → IotKpiMetricsComponent           │   │
│  │    ├── machine-status → StationMonitoringComponent     │   │
│  │    ├── alerts → IotAlertsComponent                     │   │
│  │    ├── analytics → IotKpiMetricsComponent              │   │
│  │    └── simulator → ProductionSimulationComponent       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    Services Layer                        │   │
│  │                                                          │   │
│  │  ┌─────────────────────┐  ┌─────────────────────┐     │   │
│  │  │ IoTProductionService│  │   AuthService       │     │   │
│  │  │ • Production data   │  │   • Login/Logout    │     │   │
│  │  │ • Real-time sim     │  │   • Token mgmt      │     │   │
│  │  │ • Alerts            │  │   • User session    │     │   │
│  │  │ • Predictions       │  └─────────────────────┘     │   │
│  │  └─────────────────────┘                               │   │
│  │                                                          │   │
│  │  ┌─────────────────────┐  ┌─────────────────────┐     │   │
│  │  │   ThemeService      │  │   AlertService      │     │   │
│  │  │ • Theme switching   │  │   • Notifications   │     │   │
│  │  │ • CSS variables     │  │   • Toasts          │     │   │
│  │  └─────────────────────┘  └─────────────────────┘     │   │
│  └─────────────────────────────────────────────────────────┘   │
└───────────────────────────────────────────────────────────────┘
```

---

## 🔄 Component Hierarchy

```
IotDigitalTwinComponent (Main Container)
│
├─ IotSidebarComponent (Left Navigation)
│   ├─ Logo Section
│   ├─ Toggle Button
│   ├─ Navigation Links (6 items)
│   │   ├─ 📊 Dashboard
│   │   ├─ 🤖 AI Analytics
│   │   ├─ ⚙️ Machine Status
│   │   ├─ 🔔 Alerts
│   │   ├─ 📈 Analytics
│   │   └─ 🎮 Simulator
│   └─ Status Indicator
│
└─ <router-outlet> (Dynamic Content Area)
    │
    ├─ IotDashboardViewComponent
    │   ├─ Page Header (Title + Timestamp)
    │   ├─ KPI Cards (4)
    │   │   ├─ Units Produced
    │   │   ├─ Overall Efficiency
    │   │   ├─ Active Stations
    │   │   └─ Active Alerts
    │   └─ Production Line Grid (7 stations)
    │
    ├─ IotKpiMetricsComponent
    │   ├─ KPI Header
    │   ├─ Metrics Grid
    │   │   ├─ Production Efficiency
    │   │   ├─ Quality Score
    │   │   ├─ Downtime Today
    │   │   ├─ Energy Consumption
    │   │   ├─ Defect Rate
    │   │   └─ Throughput Rate
    │   └─ Trend Indicators
    │
    ├─ StationMonitoringComponent
    │   ├─ Station Grid (Left)
    │   │   ├─ Sheet Metal Card
    │   │   ├─ Drum & Tub Card
    │   │   ├─ Motor Card
    │   │   ├─ Wiring Card
    │   │   ├─ Final Assembly Card
    │   │   ├─ Testing Card
    │   │   └─ Packaging Card
    │   └─ Detail Panel (Right)
    │       ├─ Station Header
    │       ├─ Key Metrics
    │       ├─ Sensor Readings
    │       ├─ Performance Chart
    │       └─ Recent Events
    │
    ├─ IotAlertsComponent
    │   ├─ Header (Title + Clear Button)
    │   ├─ Filter Bar
    │   │   ├─ All
    │   │   ├─ Critical
    │   │   ├─ Warning
    │   │   └─ Info
    │   └─ Alerts List
    │       ├─ Critical Alerts (Red)
    │       ├─ Warning Alerts (Yellow)
    │       └─ Info Alerts (Blue)
    │
    └─ ProductionSimulationComponent
        ├─ Simulation Header
        ├─ Controls Panel
        │   ├─ Hour Range Slider (1-24)
        │   └─ Hour Display
        ├─ Forecast Results
        │   ├─ Hourly Chart
        │   └─ Summary Stats
        └─ AI Insights
            ├─ Bottlenecks
            ├─ Peak Production
            └─ Optimization Tips
```

---

## 🔌 Data Flow Diagram

```
┌──────────────────────────────────────────────────────────────┐
│                  IoTProductionService                         │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │         Initialize Production Line Data             │    │
│  │  • 7 Stations                                       │    │
│  │  • 21 Sensors (3 per station)                      │    │
│  │  • Initial KPI values                               │    │
│  └─────────────────────────────────────────────────────┘    │
│                         │                                     │
│                         ▼                                     │
│  ┌─────────────────────────────────────────────────────┐    │
│  │    Real-Time Simulation Engine (5 sec interval)     │    │
│  │  • Update sensor readings (±5% variation)           │    │
│  │  • Calculate efficiency per station                 │    │
│  │  • Generate alerts (thresholds)                     │    │
│  │  • Update KPIs                                      │    │
│  └─────────────────────────────────────────────────────┘    │
│                         │                                     │
│                         ▼                                     │
│  ┌─────────────────────────────────────────────────────┐    │
│  │         Observable Streams (BehaviorSubject)        │    │
│  │  • productionData$                                  │    │
│  │  • alerts$                                          │    │
│  │  • kpis$                                            │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────┬────────────────────────────────────┘
                          │
                          │ Subscribe
                          ▼
┌──────────────────────────────────────────────────────────────┐
│                    UI Components                              │
│                                                               │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐ │
│  │  Dashboard     │  │  KPI Metrics   │  │  Monitoring    │ │
│  │  • Auto update │  │  • Auto update │  │  • Auto update │ │
│  │  • 5 sec       │  │  • 5 sec       │  │  • 5 sec       │ │
│  └────────────────┘  └────────────────┘  └────────────────┘ │
│                                                               │
│  ┌────────────────┐  ┌────────────────┐                      │
│  │  Alerts        │  │  Simulator     │                      │
│  │  • On event    │  │  • On demand   │                      │
│  └────────────────┘  └────────────────┘                      │
└──────────────────────────────────────────────────────────────┘
```

---

## 🎨 Theme System Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                     index.html (Root)                         │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐    │
│  │            CSS Variable Definitions                  │    │
│  │                                                      │    │
│  │  :root, .theme-light {                              │    │
│  │    --bg-primary: #ffffff;                           │    │
│  │    --text-primary: #1e293b;                         │    │
│  │    --accent-primary: #0ea5e9;                       │    │
│  │    ...                                              │    │
│  │  }                                                   │    │
│  │                                                      │    │
│  │  .theme-dark {                                      │    │
│  │    --bg-primary: #1e293b;                           │    │
│  │    --text-primary: #f8fafc;                         │    │
│  │    --accent-primary: #38bdf8;                       │    │
│  │    ...                                              │    │
│  │  }                                                   │    │
│  │                                                      │    │
│  │  .theme-neon-blue { ... }                           │    │
│  │  .theme-forest-green { ... }                        │    │
│  │  .theme-midnight-purple { ... }                     │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────┬────────────────────────────────────┘
                          │ Inherited by all components
                          ▼
┌──────────────────────────────────────────────────────────────┐
│                   Component Stylesheets                       │
│                                                               │
│  ┌────────────────────────────────────────────────────┐     │
│  │  .my-component {                                   │     │
│  │    background-color: var(--bg-primary);           │     │
│  │    color: var(--text-primary);                    │     │
│  │    border: 1px solid var(--border-primary);       │     │
│  │  }                                                 │     │
│  │                                                     │     │
│  │  .accent-button {                                  │     │
│  │    background-color: var(--accent-primary);       │     │
│  │  }                                                 │     │
│  └────────────────────────────────────────────────────┘     │
│                                                               │
│  Theme Change: ThemeService → Update <body> class           │
│                → CSS variables apply instantly               │
└──────────────────────────────────────────────────────────────┘
```

---

## 🔐 Authentication Flow

```
User Access Attempt
        │
        ▼
    /iot-login
        │
        ▼
IotLoginComponent
    │ Enter credentials
    ▼
AuthService.login()
    │
    ├─ Valid? ──── YES ──┐
    │                    │
    └─ NO               │
        │                │
        ▼                ▼
   Show Error      Store Token
                    Set User
                        │
                        ▼
              Navigate to /iot-dashboard
                        │
                        ▼
                   AuthGuard Check
                        │
                    ├─ Authenticated? ── YES ──┐
                    │                           │
                    └─ NO                       │
                        │                       │
                        ▼                       ▼
                Redirect to login    Allow Access
                                          │
                                          ▼
                             IotDigitalTwinComponent
                                          │
                                          ▼
                                  Load Dashboard
```

---

## 📊 Production Line Flow

```
Raw Materials
      │
      ▼
┌──────────────────┐
│ 1. Sheet Metal   │ 🔧  Temperature: 45-55°C
│    Forming       │     Vibration: 0.5-1.5 mm/s
└────────┬─────────┘     Energy: 8-12 kWh
         │
         ▼
┌──────────────────┐
│ 2. Drum & Tub    │ 🥁  Temperature: 40-50°C
│    Assembly      │     Vibration: 0.3-1.2 mm/s
└────────┬─────────┘     Energy: 6-10 kWh
         │
         ▼
┌──────────────────┐
│ 3. Motor         │ ⚡  Temperature: 50-60°C
│    Installation  │     Vibration: 0.4-1.3 mm/s
└────────┬─────────┘     Energy: 10-15 kWh
         │
         ▼
┌──────────────────┐
│ 4. Wiring &      │ 🔌  Temperature: 35-45°C
│    Electronics   │     Vibration: 0.2-0.8 mm/s
└────────┬─────────┘     Energy: 4-8 kWh
         │
         ▼
┌──────────────────┐
│ 5. Final         │ 🔩  Temperature: 40-50°C
│    Assembly      │     Vibration: 0.5-1.5 mm/s
└────────┬─────────┘     Energy: 7-11 kWh
         │
         ▼
┌──────────────────┐
│ 6. Testing &     │ ✅  Temperature: 30-40°C
│    Quality       │     Vibration: 0.3-1.0 mm/s
└────────┬─────────┘     Energy: 5-9 kWh
         │
         ▼
┌──────────────────┐
│ 7. Packaging     │ 📦  Temperature: 25-35°C
│                  │     Vibration: 0.2-0.6 mm/s
└────────┬─────────┘     Energy: 3-7 kWh
         │
         ▼
   Finished Product
```

---

## 🔔 Alert Generation Logic

```
Sensor Reading Update (every 5 seconds)
            │
            ▼
    Check Thresholds
            │
            ├─ Temperature > 70°C ─────────┐
            ├─ Vibration > 2.0 mm/s ───────┤
            ├─ Energy > 20 kWh ────────────┤
            ├─ Efficiency < 70% ───────────┤
            │                              │
            │                              ▼
            │                      Generate CRITICAL Alert
            │
            ├─ Temperature > 60°C ─────────┐
            ├─ Vibration > 1.5 mm/s ───────┤
            ├─ Energy > 15 kWh ────────────┤
            ├─ Efficiency < 80% ───────────┤
            │                              │
            │                              ▼
            │                      Generate WARNING Alert
            │
            ├─ Other conditions ───────────┐
            │                              │
            │                              ▼
            │                       Generate INFO Alert
            │
            ▼
    Add to alerts$ Observable
            │
            ▼
    UI Updates Automatically
```

---

## 📱 Responsive Behavior

```
Desktop (>1024px)
┌────────────────────────────────────────────────┐
│ [Sidebar]    [Main Content Area]              │
│ [Expanded]   [────────────────────────────]   │
│ 📊 Dashboard [   KPI Cards Grid (4 cols)   ]  │
│ 🤖 AI        [────────────────────────────]   │
│ ⚙️ Machine   [   Station Grid (3-4 cols)  ]   │
│ 🔔 Alerts    [────────────────────────────]   │
│ 📈 Analytics [                             ]   │
│ 🎮 Simulator [                             ]   │
│              [                             ]   │
│ [Online ⚫]  [                             ]   │
└────────────────────────────────────────────────┘

Tablet (768-1024px)
┌──────────────────────────────────────┐
│ [SB]  [Main Content Area]           │
│ [Col] [──────────────────────]      │
│ 📊   [  KPI Cards (2 cols)   ]      │
│ 🤖   [──────────────────────]      │
│ ⚙️   [  Stations (2 cols)    ]      │
│ 🔔   [──────────────────────]      │
│ 📈   [                       ]      │
│ 🎮   [                       ]      │
│ ⚫   [                       ]      │
└──────────────────────────────────────┘

Mobile (<768px)
┌────────────────────┐
│ [☰] [Header]      │
│ ──────────────────│
│  KPI Card         │
│ ──────────────────│
│  KPI Card         │
│ ──────────────────│
│  Station Card     │
│ ──────────────────│
│  Station Card     │
│ ──────────────────│
│ (Single Column)   │
└────────────────────┘
```

---

## 🎯 Summary

This architecture provides:
- ✅ **Scalability** - Modular component design
- ✅ **Maintainability** - Service-based architecture
- ✅ **Performance** - Optimized data flow
- ✅ **Flexibility** - Theme system & responsive
- ✅ **Security** - Auth guard protection
- ✅ **Real-time** - Observable-based updates

---

*Architecture designed for production-ready IoT monitoring system*
