# IoT Sensor Streams - Visual Guide

## 🎨 Component Preview

### Desktop View (1920x1080)
```
┌─────────────────────────────────────────────────────────────────────────┐
│  [Sidebar]  │                                                            │
│             │  📊 Real-Time Sensor Streams                               │
│  📊 Dash    │  Live monitoring of production line sensors                │
│  📡 Sensor  │  ┌───────────────────────────────────────────────────────┐│
│  🤖 AI      │  │ Last Updated: 14:35:42                                ││
│  🔧 Machine │  └───────────────────────────────────────────────────────┘│
│  ⚠️ Alerts  │                                                            │
│  📈 Analytics│  ╔════════════════════════════════════════════════════╗ │
│  🎯 Sim     │  ║  🌡️ Temperature │ 〰️ Vibration │ ⚡ Energy │ 📈 All ║ │
│             │  ╚════════════════════════════════════════════════════╝ │
│             │                                                            │
│             │  ┌────────────┐ ┌────────────┐ ┌────────────┐           │
│             │  │ Average    │ │ Maximum    │ │ Monitored  │           │
│             │  │ 65.3°C     │ │ 75.8°C     │ │ 7 Stations │           │
│             │  └────────────┘ └────────────┘ └────────────┘           │
│             │                                                            │
│             │  ┌────────────────────────────────────────────────────┐  │
│             │  │                                                     │  │
│             │  │    75°C ┤                  📈                       │  │
│             │  │         │             ╱╲  ╱  ╲                     │  │
│             │  │    70°C ┤       ╱╲  ╱  ╲╱    ╲╱╲                  │  │
│             │  │         │  ╱╲  ╱  ╲╱              ╲                │  │
│             │  │    65°C ┤─╱──╲╱──────────────────────╲─           │  │
│             │  │         │                               ╲          │  │
│             │  │    60°C ┤                                ╲╱        │  │
│             │  │         └────────────────────────────────────────  │  │
│             │  │              Time (Last 20 readings)               │  │
│             │  └────────────────────────────────────────────────────┘  │
│             │                                                            │
│             │  Station Readings                                         │
│             │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐        │
│             │  │ Sheet Metal │ │ Drum & Tub  │ │ Motor Asm   │        │
│             │  │ Processing  │ │ Assembly    │ │             │        │
│             │  │ normal      │ │ normal      │ │ warning     │        │
│             │  │ 68.5°C      │ │ 62.3°C      │ │ 75.2°C      │        │
│             │  └─────────────┘ └─────────────┘ └─────────────┘        │
│             │                                                            │
│             │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐        │
│             │  │ Wiring &    │ │ Final       │ │ Quality     │        │
│             │  │ Connections │ │ Assembly    │ │ Testing     │        │
│             │  │ normal      │ │ normal      │ │ warning     │        │
│             │  │ 58.1°C      │ │ 65.4°C      │ │ 72.8°C      │        │
│             │  └─────────────┘ └─────────────┘ └─────────────┘        │
│             │                                                            │
│             │  ┌─────────────┐                                          │
│             │  │ Packing &   │                                          │
│             │  │ Shipping    │                                          │
│             │  │ normal      │                                          │
│             │  │ 55.2°C      │                                          │
│             │  └─────────────┘                           [💬 Chat]      │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 📱 Mobile View (375x667)

```
┌──────────────────────────┐
│ ☰  Real-Time Sensors    │
├──────────────────────────┤
│                          │
│ 🌡️  〰️  ⚡  📈          │
│ [Active Tab]             │
│                          │
├──────────────────────────┤
│ ┌──────────────────────┐ │
│ │ Average              │ │
│ │ 65.3°C               │ │
│ └──────────────────────┘ │
│ ┌──────────────────────┐ │
│ │ Maximum              │ │
│ │ 75.8°C               │ │
│ └──────────────────────┘ │
│ ┌──────────────────────┐ │
│ │ Monitored            │ │
│ │ 7 Stations           │ │
│ └──────────────────────┘ │
├──────────────────────────┤
│ ┌──────────────────────┐ │
│ │       Chart          │ │
│ │         📈           │ │
│ │                      │ │
│ └──────────────────────┘ │
├──────────────────────────┤
│ Station Readings         │
│ ┌──────────────────────┐ │
│ │ Sheet Metal Proc     │ │
│ │ normal   68.5°C      │ │
│ └──────────────────────┘ │
│ ┌──────────────────────┐ │
│ │ Drum & Tub Asm       │ │
│ │ normal   62.3°C      │ │
│ └──────────────────────┘ │
│ ┌──────────────────────┐ │
│ │ Motor Assembly       │ │
│ │ warning  75.2°C      │ │
│ └──────────────────────┘ │
│          ...             │
│                          │
│                [💬]      │
└──────────────────────────┘
```

---

## 🎨 Tab States

### Inactive Tab
```
┌──────────────────┐
│ 🌡️ Temperature  │
│      7          │
└──────────────────┘
Background: Transparent
Border: 1px transparent
Color: Secondary text
```

### Hover Tab
```
┌──────────────────┐
│ 🌡️ Temperature  │
│      7          │
└──────────────────┘
Background: Light gradient
Border: 1px primary
Transform: translateY(-2px)
Color: Primary text
```

### Active Tab
```
╔══════════════════╗
║ 🌡️ Temperature  ║
║      7          ║
╚══════════════════╝
Background: Blue → Purple gradient
Border: 1px accent
Shadow: Glowing effect
Color: White
```

---

## 📊 Chart Animation

### Data Update Flow
```
Time: 0s                 Time: 5s                 Time: 10s
┌──────────┐            ┌──────────┐            ┌──────────┐
│    ╱╲    │            │    ╱╲╱╲  │            │  ╱╲╱╲╱╲  │
│   ╱  ╲   │  Update    │   ╱    ╲ │  Update    │ ╱      ╲ │
│  ╱    ╲  │  ──────>   │  ╱      ╲│  ──────>   │╱        ╲│
│─╱──────╲─│            │─╱────────│            │──────────│
└──────────┘            └──────────┘            └──────────┘
```

### Rolling Window
```
Buffer: [Point 1, Point 2, ..., Point 20]
         ↓
New data arrives (Point 21)
         ↓
Buffer: [Point 2, Point 3, ..., Point 21]
         ↑
Point 1 removed (FIFO)
```

---

## 🎨 Color Coding System

### Status Colors
```
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│   NORMAL    │  │  WARNING    │  │  CRITICAL   │
│   ✓ OK      │  │   ⚠️ High   │  │   ❌ Danger │
│   #10b981   │  │   #f59e0b   │  │   #ef4444   │
│   Green     │  │   Amber     │  │   Red       │
└─────────────┘  └─────────────┘  └─────────────┘
```

### Threshold Ranges
```
Sensor Value
│
├─ 0% ────────────────────┐
│                         │  NORMAL (Green)
│                         │  < 70% of threshold
├─ 70% ───────────────────┤
│                         │  WARNING (Amber)
│                         │  70% - 90% of threshold
├─ 90% ───────────────────┤
│                         │  CRITICAL (Red)
│                         │  > 90% of threshold
├─ 100% (Threshold) ──────┘
```

---

## 🎯 Card Hover Effects

### Before Hover
```
┌────────────────┐
│ Sheet Metal    │
│ Processing     │
│ normal         │
│ 68.5°C         │
└────────────────┘
Border: 1px secondary
Shadow: None
Transform: none
```

### On Hover
```
╔════════════════╗
║ Sheet Metal    ║
║ Processing     ║  ← Lifted 2px
║ normal         ║
║ 68.5°C         ║
╚════════════════╝
Border: 1px primary (blue)
Shadow: 0 4px 12px blue glow
Transform: translateY(-2px)
Cursor: pointer
```

---

## 📈 Combined Tab Layout

```
┌──────────────────────────────────────────────────────────┐
│  Statistics Row                                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐     │
│  │ Temperature │  │ Vibration   │  │ Energy      │     │
│  │  65.3°C     │  │  2.1 mm/s   │  │  12.5 kW    │     │
│  └─────────────┘  └─────────────┘  └─────────────┘     │
├──────────────────────────────────────────────────────────┤
│  Combined Chart (Normalized Data)                       │
│  ┌────────────────────────────────────────────────────┐ │
│  │                                                     │ │
│  │    📈 Normalized values from all sensor types     │ │
│  │                                                     │ │
│  └────────────────────────────────────────────────────┘ │
├──────────────────────────────────────────────────────────┤
│  Mini Overview Cards                                     │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────┐│
│  │ 🌡️ Temperature   │  │ 〰️ Vibration    │  │ ⚡ Energy ││
│  │ Avg: 65.3°C     │  │ Avg: 2.1 mm/s  │  │ Avg: 12.5│││
│  │ Max: 75.8°C     │  │ Max: 3.5 mm/s  │  │ Tot: 87.5│││
│  └─────────────────┘  └─────────────────┘  └──────────┘│
└──────────────────────────────────────────────────────────┘
```

---

## 🔄 Real-Time Update Animation

```
Step 1: Data Arrives (t=0s)
┌────────────────────┐
│ New sensor values  │
│ Temperature: 65.3°C│
│ Vibration: 2.1 mm/s│
│ Energy: 12.5 kW    │
└────────────────────┘

Step 2: Process Data (t=0.01s)
┌────────────────────┐
│ Calculate averages │
│ Update buffers     │
│ Shift old values   │
└────────────────────┘

Step 3: Update UI (t=0.02s)
┌────────────────────┐
│ Stat cards refresh │
│ Chart adds point   │
│ Station cards update│
└────────────────────┘

Step 4: Animate (t=0.05s)
┌────────────────────┐
│ Smooth transitions │
│ Line draws         │
│ Values fade in     │
└────────────────────┘

Wait 5 seconds, repeat from Step 1
```

---

## 📐 Responsive Grid Layouts

### Desktop (>1024px)
```
Statistics:
┌───────┐ ┌───────┐ ┌───────┐
│ Stat1 │ │ Stat2 │ │ Stat3 │
└───────┘ └───────┘ └───────┘

Stations:
┌───────┐ ┌───────┐ ┌───────┐
│ Stn 1 │ │ Stn 2 │ │ Stn 3 │
└───────┘ └───────┘ └───────┘
┌───────┐ ┌───────┐ ┌───────┐
│ Stn 4 │ │ Stn 5 │ │ Stn 6 │
└───────┘ └───────┘ └───────┘
┌───────┐
│ Stn 7 │
└───────┘
```

### Tablet (768-1024px)
```
Statistics:
┌───────┐ ┌───────┐
│ Stat1 │ │ Stat2 │
└───────┘ └───────┘
┌───────┐
│ Stat3 │
└───────┘

Stations:
┌───────┐ ┌───────┐
│ Stn 1 │ │ Stn 2 │
└───────┘ └───────┘
┌───────┐ ┌───────┐
│ Stn 3 │ │ Stn 4 │
└───────┘ └───────┘
    ...
```

### Mobile (<768px)
```
Statistics:
┌─────────────┐
│   Stat 1    │
└─────────────┘
┌─────────────┐
│   Stat 2    │
└─────────────┘
┌─────────────┐
│   Stat 3    │
└─────────────┘

Stations:
┌─────────────┐
│  Station 1  │
└─────────────┘
┌─────────────┐
│  Station 2  │
└─────────────┘
    ...
```

---

## 🎨 Gradient Examples

### Active Tab Gradient
```
Left (Blue)          Right (Purple)
#3b82f6    ────────────────>    #8b5cf6
```

### Stat Value Gradient
```
Left (Primary)       Right (Secondary)
var(--accent-primary) ──> var(--accent-secondary)
```

### Card Hover Accent Bar
```
Top Border:
Blue ──> Purple ──> Pink
#3b82f6   #8b5cf6   #ec4899
```

---

## 🔍 Zoom Levels

### 100% (Default)
```
Full view, all elements visible
Charts: 400px height
Cards: Normal size
Text: 100%
```

### 90% (Compact)
```
More content visible
Charts: 360px height
Cards: Slightly smaller
Text: 90%
```

### 110% (Enlarged)
```
Better readability
Charts: 440px height
Cards: Larger
Text: 110%
```

---

## 📊 Data Visualization Key

```
Chart Elements:
───────  Gridline (theme border color)
━━━━━━━  Data line (accent gradient)
●        Data point (with glow)
▲        Peak value
▼        Low value

Colors:
Blue line    = Good performance
Amber line   = Warning state
Red line     = Critical state
```

---

**Visual Guide Version**: 1.0  
**Last Updated**: December 5, 2025  
**Status**: Complete
