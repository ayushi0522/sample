# 📊 Station Utilization Table & Flow Diagram - Implementation Guide

## ✨ New Features Added

### 1. **Professional Data Table**
A clean, properly aligned table displaying station utilization metrics with:
- Color-coded rows for bottlenecks (red border)
- Sortable columns (Station, Baseline, Scenario, Change, Status)
- Status badges with icons
- Hover effects and animations
- Responsive design

### 2. **Visual Flow Diagram**
An interactive production flow visualization showing:
- Station nodes with color-coded borders
- Bottleneck stations highlighted in RED with pulsing animation
- Utilization bars within each node
- Directional arrows showing flow sequence
- Real-time status indicators (🔴 🟡 🟢)
- Legend explaining color codes

---

## 🎨 Visual Design

### **Station Utilization Table**

```
┌─────────────────────────────────────────────────────────────────────┐
│ Station          │ Baseline │ Scenario │ Change    │ Status        │
├─────────────────────────────────────────────────────────────────────┤
│ 🏭 Assembly      │  75.0%   │  85.0%   │ +13.3%    │ ✓ Normal     │
│ 🏭 Quality Check │  80.0%   │  90.0%   │ +12.5%    │ ⚡ High Load │
│ 🏭 Packaging     │  95.0%   │  98.0%   │  +3.2%    │ ⚠️ Bottleneck│ 🔴
└─────────────────────────────────────────────────────────────────────┘
```

### **Flow Diagram Structure**

```
┌───────────────┐        ┌───────────────┐        ┌───────────────┐
│ 🟢 Assembly   │   →    │ 🟡 Quality    │   →    │ 🔴 Packaging  │
│               │        │               │        │ ⚠️ BOTTLENECK │
│ ████████░░ 85%│        │ █████████░ 90%│        │ ██████████ 98%│
└───────────────┘        └───────────────┘        └───────────────┘
     Normal                 High Load              CRITICAL ALERT
```

---

## 🎯 Status Indicators

### **Table Status Badges**

| Badge | Utilization | Color | Icon | Description |
|-------|-------------|-------|------|-------------|
| ⚠️ Bottleneck | >90% + Critical | Red | ⚠️ | Primary bottleneck (pulsing) |
| ⚡ High Load | >90% | Orange | ⚡ | Near capacity |
| ✓ Normal | 75-90% | Green | ✓ | Optimal range |
| ○ Low | <75% | Gray | ○ | Underutilized |

### **Flow Diagram Colors**

| Status | Border Color | Background | Icon | Animation |
|--------|-------------|------------|------|-----------|
| Bottleneck | #ef4444 (Red) | Red gradient | 🔴 | Pulsing border + flashing warning |
| High Load | #f59e0b (Orange) | Orange gradient | 🟡 | None |
| Normal | #10b981 (Green) | Green gradient | 🟢 | None |
| Low | #6b7280 (Gray) | Gray gradient | 🟢 | None |

---

## 📐 Table Layout Details

### **Column Structure**

1. **Station Column**
   - Icon: 🏭
   - Name: Formatted (underscores → spaces, capitalized)
   - Left-aligned
   - Bold font

2. **Baseline Column**
   - Format: XX.X%
   - Center-aligned
   - Background badge
   - Shows original utilization

3. **Scenario Column**
   - Format: XX.X%
   - Center-aligned
   - Red background if >90%
   - Shows predicted utilization

4. **Change Column**
   - Format: ±XX.X%
   - Color-coded badge:
     - Green for positive changes (slight/high increase)
     - Red for negative changes
     - Gray for no change
   - Center-aligned

5. **Status Column**
   - Dynamic badge based on utilization
   - Icon + text
   - Pulsing animation for bottlenecks
   - Center-aligned

### **Row Styling**

- **Normal Rows**: White background, gray border
- **Bottleneck Rows**: Red tint, red left border (4px), pulsing shadow
- **Hover Effect**: Scale up, background change
- **Responsive**: Single column on mobile

---

## 🔄 Flow Diagram Layout

### **Node Structure**

Each station is represented as a card containing:

```
┌─────────────────────────┐
│ 🔴 Station Name         │  ← Header with status icon
├─────────────────────────┤
│ ██████████░░░░░ 85%     │  ← Utilization bar
├─────────────────────────┤
│ ⚠️ BOTTLENECK          │  ← Warning (if applicable)
└─────────────────────────┘
```

### **Node Variants**

#### **Bottleneck Node (RED)**
- Border: 3px solid red
- Background: Red gradient
- Animation: Pulsing border + shadow
- Bar color: Red gradient
- Warning text: "⚠️ BOTTLENECK" (flashing)
- Icon: 🔴

#### **High Load Node (ORANGE)**
- Border: 3px solid orange
- Background: Orange gradient
- Bar color: Orange gradient
- Icon: 🟡

#### **Normal Node (GREEN)**
- Border: 3px solid green
- Background: Green gradient
- Bar color: Green gradient
- Icon: 🟢

#### **Low Load Node (GRAY)**
- Border: 3px solid gray
- Background: Gray gradient
- Bar color: Green gradient
- Icon: 🟢

### **Flow Arrows**

- Default: Gray, 2rem font size
- Bottleneck Arrow: Red, pulsing scale animation
- Direction: Left to right (horizontal on desktop)
- Mobile: Rotated 90° (vertical flow)

---

## 💻 Code Implementation

### **TypeScript Helper Method**

```typescript
getStationArray(stationUtilization: { [key: string]: any }): Array<{ key: string; value: any }> {
  return Object.entries(stationUtilization)
    .map(([key, value]) => ({ key, value }))
    .sort((a, b) => {
      // Bottlenecks first
      if (a.value.bottleneck && !b.value.bottleneck) return -1;
      if (!a.value.bottleneck && b.value.bottleneck) return 1;
      // Then by utilization descending
      return b.value.scenario - a.value.scenario;
    });
}
```

**Purpose**: Converts object to sorted array
**Sort Order**: 
1. Bottlenecks first
2. Highest utilization to lowest

### **HTML Template Structure**

```html
<!-- Table Section -->
<div class="utilization-table-container">
  <table class="utilization-table">
    <thead>...</thead>
    <tbody>
      @for (station of message.report.station_utilization | keyvalue) {
        <tr [class.bottleneck-row]="station.value.bottleneck">
          <!-- 5 columns here -->
        </tr>
      }
    </tbody>
  </table>
</div>

<!-- Flow Diagram Section -->
<div class="flow-diagram-container">
  <div class="flow-diagram">
    @for (station of getStationArray(...)) {
      <div class="flow-node-wrapper">
        <div class="flow-node" [class.bottleneck-node]="...">
          <!-- Node content -->
        </div>
        <div class="flow-arrow">→</div>
      </div>
    }
  </div>
  <div class="diagram-legend">...</div>
</div>
```

---

## 🎬 Animations

### **1. Pulse Border (Bottleneck Nodes)**
```css
@keyframes pulse-border {
  0%, 100% {
    border-color: #ef4444;
    box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4);
  }
  50% {
    border-color: #dc2626;
    box-shadow: 0 0 0 8px rgba(239, 68, 68, 0);
  }
}
```
**Duration**: 2s
**Effect**: Expanding red shadow ring

### **2. Flash (Bottleneck Warning)**
```css
@keyframes flash {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.6; }
}
```
**Duration**: 1.5s
**Effect**: Pulsing opacity

### **3. Progress Pulse (Bottleneck Bar)**
```css
@keyframes progress-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.7; }
}
```
**Duration**: 1.5s
**Effect**: Breathing animation

### **4. Arrow Pulse (Bottleneck Arrow)**
```css
@keyframes arrow-pulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.2); }
}
```
**Duration**: 1.5s
**Effect**: Growing/shrinking

### **5. Pulse Red (Status Badge)**
```css
@keyframes pulse-red {
  0%, 100% {
    box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7);
  }
  50% {
    box-shadow: 0 0 0 8px rgba(239, 68, 68, 0);
  }
}
```
**Duration**: 2s
**Effect**: Expanding shadow

---

## 📱 Responsive Design

### **Desktop (>1024px)**
- Table: Full width with all columns visible
- Flow: Horizontal layout with right-pointing arrows
- Nodes: Side by side
- Legend: Single row

### **Tablet (768px - 1024px)**
- Table: Slightly smaller fonts
- Flow: Vertical layout with down-pointing arrows
- Nodes: Stacked vertically
- Legend: Wrapped to 2 rows

### **Mobile (<768px)**
- Table: Compact padding, smaller fonts
- Flow: Full-width cards, rotated arrows
- Nodes: Full width, max 400px
- Legend: Compact items

---

## 🎯 Usage Example

### **API Response Format**

```json
{
  "report": {
    "station_utilization": {
      "assembly": {
        "baseline": 0.75,
        "scenario": 0.85,
        "delta_pct": 13.33,
        "bottleneck": false
      },
      "packaging": {
        "baseline": 0.95,
        "scenario": 0.98,
        "delta_pct": 3.16,
        "bottleneck": true
      }
    }
  }
}
```

### **Rendered Output**

**Table Row for Bottleneck:**
```
🏭 Packaging | 95.0% | 98.0% | +3.2% | ⚠️ Bottleneck
                                        ↑
                                   Red, pulsing
```

**Flow Node for Bottleneck:**
```
┌─────────────────────────┐
│ 🔴 Packaging            │  ← Red icon
├─────────────────────────┤
│ ██████████ 98%          │  ← Red bar, pulsing
├─────────────────────────┤
│ ⚠️ BOTTLENECK          │  ← Flashing warning
└─────────────────────────┘
   ↑ Red border, pulsing animation
```

---

## 🔍 Visual Indicators Summary

### **Bottleneck Station Gets:**
1. ✅ Red border on table row
2. ✅ Pulsing red shadow on status badge
3. ✅ Red "⚠️ Bottleneck" badge
4. ✅ Red node border with pulsing animation
5. ✅ Red utilization bar with pulsing
6. ✅ Flashing "⚠️ BOTTLENECK" warning text
7. ✅ 🔴 Red status icon
8. ✅ Red pulsing arrow to next station

**Total Indicators**: 8 different visual cues!

---

## 🎨 Color Palette

| Element | Color Code | RGB | Usage |
|---------|-----------|-----|-------|
| Bottleneck Red | #ef4444 | (239, 68, 68) | Critical alerts |
| Dark Red | #dc2626 | (220, 38, 38) | Pulsing variant |
| High Load Orange | #f59e0b | (245, 158, 11) | Warnings |
| Dark Orange | #d97706 | (217, 119, 6) | Hover state |
| Normal Green | #10b981 | (16, 185, 129) | Optimal range |
| Dark Green | #059669 | (5, 150, 105) | Bar gradient |
| Low Gray | #6b7280 | (107, 114, 128) | Underutilized |
| Dark Gray | #4b5563 | (75, 85, 99) | Border |

---

## 🚀 Performance Features

1. **CSS Animations**: GPU-accelerated transforms
2. **Efficient Sorting**: O(n log n) complexity
3. **Conditional Rendering**: Only renders when data exists
4. **Optimized Loops**: Uses @for with track by
5. **Lazy Loading**: Sections only render with report data

---

## 📊 Benefits

### **For Users:**
- ✅ **Clear Data Visualization**: Easy to understand at a glance
- ✅ **Immediate Bottleneck Identification**: Red = problem
- ✅ **Flow Understanding**: See production sequence
- ✅ **Status Awareness**: Know which stations need attention
- ✅ **Comparative Analysis**: Baseline vs Scenario side-by-side

### **For Operators:**
- ✅ **Quick Decision Making**: Visual cues speed up analysis
- ✅ **Priority Setting**: Bottlenecks shown first
- ✅ **Trend Recognition**: See utilization patterns
- ✅ **Capacity Planning**: Identify overloaded stations

### **For Managers:**
- ✅ **Performance Overview**: Complete station status
- ✅ **Resource Allocation**: Know where to add capacity
- ✅ **Efficiency Metrics**: Track improvements
- ✅ **Presentation Ready**: Professional visualization

---

## 🧪 Testing Checklist

### **Table Testing**
- [ ] All columns display correctly
- [ ] Bottleneck rows have red border
- [ ] Status badges show correct colors
- [ ] Hover effects work
- [ ] Values format properly (XX.X%)
- [ ] Responsive on mobile

### **Flow Diagram Testing**
- [ ] Nodes display in order
- [ ] Bottlenecks show red border
- [ ] Arrows point correctly
- [ ] Icons display (🔴 🟡 🟢)
- [ ] Utilization bars fill correctly
- [ ] Warning text appears on bottlenecks
- [ ] Animations play smoothly
- [ ] Legend matches node colors
- [ ] Responsive on mobile (vertical flow)

### **Animation Testing**
- [ ] Border pulsing on bottleneck nodes
- [ ] Warning text flashing
- [ ] Progress bar pulsing
- [ ] Arrow scaling
- [ ] Status badge shadow expanding
- [ ] No performance lag

---

## 🐛 Troubleshooting

### **Issue: Table not showing**
**Check:**
- API response includes `station_utilization` object
- Data structure matches interface
- No console errors

### **Issue: Flow diagram nodes not appearing**
**Check:**
- `getStationArray()` method exists in component
- Array has items
- CSS loaded properly

### **Issue: Colors not showing**
**Check:**
- CSS file included in component
- Theme variables defined
- Browser supports CSS gradients

### **Issue: Animations not playing**
**Check:**
- Browser supports CSS animations
- No `prefers-reduced-motion` setting
- Animation keyframes defined

---

## 📝 Customization Options

### **Change Bottleneck Threshold**
In TypeScript, modify logic:
```typescript
station.value.scenario > 0.9 && station.value.bottleneck
```

### **Change Colors**
In CSS, modify:
```css
.flow-node.bottleneck-node {
  border-color: #your-color;
}
```

### **Change Animation Speed**
In CSS, modify:
```css
animation: pulse-border 2s ease-in-out infinite;
                        ↑ Change duration
```

### **Add More Status Levels**
1. Add new thresholds in TypeScript
2. Add new CSS classes
3. Add new legend items

---

## 🎉 Summary

### **What Was Added:**
1. ✅ Professional data table with 5 columns
2. ✅ Color-coded status badges
3. ✅ Interactive flow diagram
4. ✅ Visual bottleneck indicators (RED)
5. ✅ 5 different animations
6. ✅ Sortable station array
7. ✅ Responsive design
8. ✅ Legend with color codes

### **Visual Indicators:**
- **8 different ways** bottlenecks are highlighted
- **4 status levels** with unique colors
- **5 animations** for attention-grabbing

### **Code Added:**
- **~150 lines** of HTML
- **~400 lines** of CSS
- **~15 lines** of TypeScript

---

## 🚦 Status: ✅ COMPLETE

**The station utilization now features:**
- ✅ Properly aligned tabular format
- ✅ Visual flow diagram
- ✅ RED bottleneck highlighting
- ✅ Professional animations
- ✅ Responsive design
- ✅ Comprehensive status indicators

**Ready to use!** 🎉

---

*Last Updated: December 6, 2025*
*Version: 2.0.0 - Enhanced Visualization*
