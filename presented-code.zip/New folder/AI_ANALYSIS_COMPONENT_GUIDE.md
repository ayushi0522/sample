# 🤖 AI Analysis Component - Complete Guide

## 📋 Overview

The **AI Analysis Component** is a powerful manufacturing simulation tool that allows users to configure production parameters using interactive sliders and analyze the results through comprehensive visualizations.

---

## ✨ Features

### 1. **Interactive Parameter Configuration**
- 7 configurable parameters with real-time sliders
- Live value display as you adjust
- Visual feedback with gradient-styled sliders
- Min/max range indicators

### 2. **API Integration**
- Connects to simulation API: `http://127.0.0.1:8100/simulate`
- Real-time simulation execution
- Loading states with spinner
- Error handling with user-friendly messages

### 3. **Comprehensive Results Display**
- **8 KPI Cards** showing key metrics
- **Resource Utilization Table** with bottleneck detection
- **Color-coded status indicators**
- **Animated visualizations**

---

## 🎛️ Configuration Parameters

### Parameter Details

| Parameter | Range | Default | Description |
|-----------|-------|---------|-------------|
| **NUM_MACHINES** | 50 - 200 | 120 | Number of machines in production |
| **INTER_ARRIVAL** | 1 - 10 min | 3 | Time between machine arrivals |
| **LEAK_FAIL_RATE** | 0% - 20% | 6% | Leak test failure rate |
| **FUNC_FAIL_SCRAP_RATE** | 0% - 10% | 2% | Functional test scrap rate |
| **MTBF_SCALE** | 0.5 - 2.0 | 1.0 | Mean Time Between Failures scale |
| **TUB_STOCK** | 50 - 500 | 200 | Tub stock quantity |
| **CAB_STOCK** | 50 - 500 | 200 | Cabinet stock quantity |

---

## 📊 KPI Metrics Displayed

### 1. **Started** 🏁
- Total number of units started in production
- Icon: 🏁 with purple background

### 2. **Good Units** ✅
- Successfully completed units
- Icon: ✅ with green background

### 3. **Scrap** 🗑️
- Units scrapped due to failures
- Icon: 🗑️ with red background

### 4. **Rework** 🔄
- Units requiring rework
- Icon: 🔄 with orange background

### 5. **Material Waits** ⏱️
- Count of material shortages
- Icon: ⏱️ with pink background

### 6. **Average Lead Time** ⏰
- Average time from start to finish (minutes)
- Icon: ⏰ with blue background

### 7. **Throughput** 📈
- Units produced per hour
- Icon: 📈 with green background

### 8. **Total Energy** ⚡
- Energy consumption in kWh
- Icon: ⚡ with yellow background

---

## 🏭 Resource Utilization Analysis

### Resources Monitored

1. **Cabinet Sheet Metal** - Metal cutting and forming
2. **Cabinet Coating** - Surface coating process
3. **Plastic Molding** - Plastic component molding
4. **Drum Deep Draw** - Drum forming
5. **Drum Weld Polish** - Welding and finishing
6. **PCB SMT** - Surface mount technology
7. **PCB Test** - PCB testing
8. **Subassembly Mount** - Component mounting
9. **Final Assembly** - Final product assembly
10. **Leak Test** - Leak detection testing
11. **Leak Rework** - Rework for leak failures
12. **Functional Test** - Functional testing
13. **Aging** - Product aging process
14. **Packing** - Final packing

### Utilization Status Classification

| Status | Utilization | Color | Description |
|--------|-------------|-------|-------------|
| **🔴 Bottleneck** | ≥ 90% | Red | Critical - Limiting production |
| **⚡ High Load** | 75% - 89% | Orange | High - Monitor closely |
| **✓ Normal** | 50% - 74% | Blue | Normal operation |
| **○ Low** | < 50% | Gray | Underutilized |

---

## 🎨 Visual Design

### Color Palette

```css
/* Primary Gradient */
Background: linear-gradient(135deg, #6366f1, #ec4899)

/* Status Colors */
Critical (Red):    #ef4444
High (Orange):     #f59e0b
Medium (Blue):     #3b82f6
Low (Gray):        #64748b
Success (Green):   #10b981
```

### Key Visual Elements

1. **Gradient Header**
   - Purple → Pink gradient
   - White text with shadow
   - Animated on hover

2. **Interactive Sliders**
   - Gradient thumb (purple → pink)
   - Progress fill animation
   - Hover scale effect (1.2x)

3. **KPI Cards**
   - Hover lift effect (-4px)
   - Color-coded icon backgrounds
   - Border highlight on hover

4. **Utilization Bars**
   - Gradient fills based on status
   - Smooth width animations
   - Shadow effects for depth

5. **Bottleneck Indicators**
   - Red dot with pulsing animation
   - Red row background tint
   - Red left border (4px)

---

## 🔧 Component Structure

### TypeScript (`iot-ai-analysis.component.ts`)

```typescript
// Key Properties
params = signal<SimulationParams>({...});  // Configuration
results = signal<SimulationResponse | null>(null);  // API response
isLoading = signal(false);  // Loading state
error = signal<string | null>(null);  // Error messages

// Key Methods
updateParam(key, value)  // Update slider value
runSimulation()          // Call API
resetToDefaults()        // Reset all values
formatResourceName()     // Format display names
getUtilizationClass()    // Get color class
isBottleneck()          // Check if resource is bottleneck
getSortedUtilization()  // Sort by utilization
```

### HTML (`iot-ai-analysis.component.html`)

```html
<!-- Structure -->
<div class="ai-analysis-container">
  <div class="analysis-header">...</div>        <!-- Title & Reset -->
  <div class="config-panel">...</div>           <!-- Parameter Sliders -->
  <div class="error-banner">...</div>           <!-- Error Display -->
  <div class="results-container">
    <div class="results-section">              <!-- KPI Cards -->
      <div class="kpi-grid">...</div>
    </div>
    <div class="results-section">              <!-- Utilization Table -->
      <table class="utilization-table">...</table>
    </div>
  </div>
</div>
```

### CSS (`iot-ai-analysis.component.css`)

- **Grid Layouts**: Responsive parameter and KPI grids
- **Custom Sliders**: Styled range inputs with gradients
- **Animations**: Pulse, fade-in, slide-in effects
- **Hover Effects**: Lift, scale, shadow transitions
- **Responsive**: Mobile-optimized breakpoints

---

## 🚀 How to Use

### Step 1: Navigate to Component
1. Log in to IoT Dashboard
2. Click **AI Analytics** in sidebar
3. Component loads with default values

### Step 2: Configure Parameters
1. Use **sliders** to adjust values
2. Watch **live value updates** in the header
3. See **range indicators** below each slider

### Step 3: Run Simulation
1. Click **"Run Simulation"** button
2. Wait for **loading spinner**
3. View results when complete

### Step 4: Analyze Results
1. Check **8 KPI cards** for key metrics
2. Review **utilization table** for bottlenecks
3. Look for **red indicators** (bottlenecks)
4. Identify **optimization opportunities**

### Step 5: Iterate
1. Adjust parameters based on results
2. Run simulation again
3. Compare results
4. Find optimal configuration

---

## 📡 API Integration

### Request Format

```json
POST http://127.0.0.1:8100/simulate

{
  "NUM_MACHINES": 120,
  "INTER_ARRIVAL": 3,
  "LEAK_FAIL_RATE": 0.06,
  "FUNC_FAIL_SCRAP_RATE": 0.02,
  "MTBF_SCALE": 1,
  "TUB_STOCK": 200,
  "CAB_STOCK": 200
}
```

### Response Format

```json
{
  "kpis": {
    "started": 120,
    "good": 15,
    "scrap": 2,
    "rework": 3,
    "material_waits": 0,
    "avg_lead_time": 267.22,
    "throughput_per_hr": 1.88,
    "energy_kwh": 930.09
  },
  "utilization": [
    {
      "resource": "cabinet_coating",
      "utilization": 0.97,
      "energy_kwh": 233.12,
      "avg_wait": 171.18
    }
    // ... more resources
  ],
  "params": { /* echo of request params */ }
}
```

---

## 🎯 Use Cases

### 1. **Bottleneck Identification**
- Run simulation with current settings
- Look for resources with ≥90% utilization (red)
- Focus optimization efforts on these areas

### 2. **Capacity Planning**
- Increase `NUM_MACHINES`
- Observe throughput changes
- Find optimal machine count

### 3. **Quality Improvement**
- Reduce `LEAK_FAIL_RATE` and `FUNC_FAIL_SCRAP_RATE`
- See impact on good units and scrap
- Calculate ROI of quality improvements

### 4. **Inventory Optimization**
- Adjust `TUB_STOCK` and `CAB_STOCK`
- Monitor `material_waits`
- Find minimum safe stock levels

### 5. **Energy Analysis**
- Compare `energy_kwh` across scenarios
- Identify energy-intensive processes
- Plan energy efficiency improvements

---

## 🎨 Responsive Design

### Desktop (≥768px)
```
┌────────────────────────────────────────────┐
│  Header with gradient background           │
├────────────────────────────────────────────┤
│  ┌──────────┐ ┌──────────┐ ┌──────────┐  │
│  │ Param 1  │ │ Param 2  │ │ Param 3  │  │
│  └──────────┘ └──────────┘ └──────────┘  │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐  │
│  │ Param 4  │ │ Param 5  │ │ Param 6  │  │
│  └──────────┘ └──────────┘ └──────────┘  │
│              [Run Simulation]              │
├────────────────────────────────────────────┤
│  ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐    │
│  │KPI│ │KPI│ │KPI│ │KPI│ │KPI│ │KPI│    │
│  └───┘ └───┘ └───┘ └───┘ └───┘ └───┘    │
├────────────────────────────────────────────┤
│  Resource Utilization Table (scrollable)   │
└────────────────────────────────────────────┘
```

### Mobile (<768px)
```
┌──────────────────┐
│  Header (stack)  │
├──────────────────┤
│  ┌────────────┐  │
│  │  Param 1   │  │
│  └────────────┘  │
│  ┌────────────┐  │
│  │  Param 2   │  │
│  └────────────┘  │
│  ...             │
│  [Run Button]    │
├──────────────────┤
│  ┌────────────┐  │
│  │    KPI     │  │
│  └────────────┘  │
│  (Stack)         │
├──────────────────┤
│  Table (scroll)  │
└──────────────────┘
```

---

## 🐛 Error Handling

### Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| **Connection Failed** | API not running | Start backend server |
| **Timeout** | Slow network | Check connection |
| **400 Bad Request** | Invalid parameters | Check value ranges |
| **500 Server Error** | Backend issue | Check server logs |

### Error Display

```
┌─────────────────────────────────────────┐
│ ⚠️ Failed to run simulation             │
│    Connection to API failed             │
└─────────────────────────────────────────┘
```

---

## 🎭 Animations

### 1. **Slider Thumb Hover**
```css
transform: scale(1.2);
box-shadow: 0 4px 16px rgba(99, 102, 241, 0.6);
transition: 0.3s ease;
```

### 2. **KPI Card Hover**
```css
transform: translateY(-4px);
box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
transition: 0.3s ease;
```

### 3. **Bottleneck Pulse**
```css
@keyframes pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.7; transform: scale(1.1); }
}
```

### 4. **Results Fade-In**
```css
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}
```

### 5. **Loading Spinner**
```css
@keyframes spin {
  to { transform: rotate(360deg); }
}
```

---

## 📂 File Structure

```
src/components/iot-ai-analysis/
├── iot-ai-analysis.component.ts      (~140 lines)
├── iot-ai-analysis.component.html    (~310 lines)
└── iot-ai-analysis.component.css     (~600 lines)
```

---

## 🔗 Integration

### Added to Routes (`app.routes.ts`)
```typescript
import { IotAiAnalysisComponent } from './components/iot-ai-analysis/iot-ai-analysis.component';

{
  path: 'iot-dashboard',
  children: [
    { path: 'ai-analytics', component: IotAiAnalysisComponent },
    // ... other routes
  ]
}
```

### Sidebar Menu
- **Name**: "AI Analytics"
- **Icon**: 🤖
- **Route**: `/iot-dashboard/ai-analytics`

---

## ✅ Testing Checklist

- [ ] Navigate to AI Analytics page
- [ ] Verify all 7 sliders are working
- [ ] Check value updates in real-time
- [ ] Click "Run Simulation" button
- [ ] Verify loading spinner appears
- [ ] Check API call is made
- [ ] Verify results display correctly
- [ ] Check all 8 KPI cards show data
- [ ] Verify utilization table populates
- [ ] Check bottleneck indicators (red)
- [ ] Test "Reset" button
- [ ] Verify responsive design on mobile
- [ ] Test error handling (stop API)

---

## 🚀 Quick Start

### Start Backend API
```powershell
# Start your Python/Node backend on port 8100
python app.py
# or
node server.js
```

### Access Component
1. Navigate to: `http://localhost:4200/iot-dashboard/ai-analytics`
2. Adjust sliders
3. Click "Run Simulation"
4. Analyze results!

---

## 🎓 Advanced Tips

### Optimization Workflow
1. **Baseline**: Run with defaults, note bottlenecks
2. **Hypothesis**: Adjust parameters to address bottlenecks
3. **Test**: Run simulation again
4. **Compare**: Check if throughput improved
5. **Iterate**: Repeat until optimal

### Finding Bottlenecks
- Sort table by utilization (descending)
- Focus on resources with >90% utilization
- Check average wait times
- High wait time + high utilization = bottleneck

### Energy Efficiency
- Compare total energy across scenarios
- Identify high-energy resources
- Balance throughput vs energy cost

---

## 📊 Sample Scenarios

### Scenario 1: High Volume Production
```json
{
  "NUM_MACHINES": 200,
  "INTER_ARRIVAL": 2,
  "LEAK_FAIL_RATE": 0.04,
  "FUNC_FAIL_SCRAP_RATE": 0.01,
  "MTBF_SCALE": 1.5,
  "TUB_STOCK": 400,
  "CAB_STOCK": 400
}
```
**Expected**: Higher throughput, potential new bottlenecks

### Scenario 2: Quality Focus
```json
{
  "NUM_MACHINES": 120,
  "INTER_ARRIVAL": 4,
  "LEAK_FAIL_RATE": 0.02,
  "FUNC_FAIL_SCRAP_RATE": 0.005,
  "MTBF_SCALE": 2.0,
  "TUB_STOCK": 200,
  "CAB_STOCK": 200
}
```
**Expected**: Lower scrap, higher good units, lower throughput

---

**Status:** ✅ FULLY IMPLEMENTED  
**Version:** 1.0  
**Last Updated:** December 6, 2025  
**API Endpoint:** `http://127.0.0.1:8100/simulate`
