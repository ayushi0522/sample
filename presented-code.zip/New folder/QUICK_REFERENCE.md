# 🏭 IoT Digital Twin Dashboard - Quick Reference

## 🎯 Access Points

| Login Page | Dashboard URL |
|------------|--------------|
| `/iot-login` | `/iot-dashboard` |

**Default Credentials:** `user@example.com` / `password`

---

## 📍 Navigation Routes

| Icon | Section | Route | Description |
|------|---------|-------|-------------|
| 📊 | Dashboard | `/iot-dashboard/dashboard` | Main overview with KPIs and production line |
| 🤖 | AI Analytics | `/iot-dashboard/ai-analytics` | KPI metrics and performance analytics |
| ⚙️ | Machine Status | `/iot-dashboard/machine-status` | Detailed station monitoring |
| 🔔 | Alerts | `/iot-dashboard/alerts` | Real-time alert management |
| 📈 | Analytics | `/iot-dashboard/analytics` | Performance trends |
| 🎮 | Simulator | `/iot-dashboard/simulator` | Predictive simulation (1-24 hours) |

---

## 🏭 Production Stations

| # | Station | Icon | Sensors |
|---|---------|------|---------|
| 1 | Sheet Metal Forming | 🔧 | Temperature, Vibration, Energy |
| 2 | Drum & Tub Assembly | 🥁 | Temperature, Vibration, Energy |
| 3 | Motor Installation | ⚡ | Temperature, Vibration, Energy |
| 4 | Wiring & Electronics | 🔌 | Temperature, Vibration, Energy |
| 5 | Final Assembly | 🔩 | Temperature, Vibration, Energy |
| 6 | Testing & Quality | ✅ | Temperature, Vibration, Energy |
| 7 | Packaging | 📦 | Temperature, Vibration, Energy |

**Total:** 21 sensors (3 per station)

---

## 🎨 Supported Themes

| Theme | Background | Accent | Use Case |
|-------|------------|--------|----------|
| Light | White | Sky Blue | Day work |
| Dark | Dark Slate | Light Sky | Night shifts |
| Neon Blue | Deep Navy | Cyan | Tech aesthetic |
| Forest Green | Dark Teal | Amber | Nature-inspired |
| Midnight Purple | Deep Purple | Light Purple | Modern look |

**How to Switch:** Click palette icon (🎨) in header

---

## 📊 Key Performance Indicators (KPIs)

### Dashboard View
- **Units Produced Today** - Total production count
- **Overall Efficiency** - Average across all stations
- **Active Stations** - Currently operational
- **Active Alerts** - Pending notifications

### Station Metrics
- **Efficiency** - Performance percentage (Target: >85%)
- **Cycle Time** - Time per unit (in seconds)
- **Throughput** - Units per hour
- **Downtime** - Inactive time today

### Alert Levels
- 🔴 **Critical** - Immediate attention required
- 🟡 **Warning** - Potential issue
- 🔵 **Info** - General notification

---

## 🔄 Real-Time Updates

| Component | Update Interval |
|-----------|----------------|
| Production Data | 5 seconds |
| Timestamp Display | 1 second |
| Alerts | On event |
| Sensor Readings | 5 seconds |
| KPI Metrics | 5 seconds |

---

## 🎛️ Interactive Features

### Sidebar
- **Toggle Collapse** - Click ☰ button
- **Active Highlight** - Current section shows with accent color
- **Status Indicator** - Green dot = System Online

### Station Cards
- **Click to Select** - Opens detail panel
- **Hover Effects** - Visual feedback
- **Color Coding:**
  - 🟢 Green: >85% efficiency (Operational)
  - 🟡 Yellow: 70-85% efficiency (Warning)
  - 🔴 Red: <70% efficiency (Critical)

### Alerts
- **Filter by Severity** - Click Critical/Warning/Info
- **Dismiss Individual** - Click X on alert
- **Clear All** - Remove all alerts at once

### Simulator
- **Hour Range** - Drag slider 1-24 hours
- **AI Insights** - Auto-generated based on prediction
- **Forecast Chart** - Visual production prediction

---

## 🎨 CSS Theme Variables

### Background Colors
```css
var(--bg-primary)    /* Main background */
var(--bg-secondary)  /* Secondary background */
var(--bg-tertiary)   /* Tertiary background */
```

### Text Colors
```css
var(--text-primary)    /* Main text */
var(--text-secondary)  /* Secondary text */
var(--text-tertiary)   /* Tertiary text */
```

### Accent Colors
```css
var(--accent-primary)    /* Primary accent */
var(--accent-secondary)  /* Secondary accent */
```

### Borders
```css
var(--border-primary)    /* Main borders */
var(--border-secondary)  /* Secondary borders */
var(--border-focus)      /* Focus state */
```

---

## 📱 Responsive Breakpoints

| Device | Width | Sidebar | Grid Columns |
|--------|-------|---------|--------------|
| Desktop | >1024px | Expanded | 3-4 |
| Tablet | 768-1024px | Collapsible | 2 |
| Mobile | <768px | Collapsed | 1 |

---

## 🔧 Component Architecture

```
IotDigitalTwinComponent (Container)
├── IotSidebarComponent (Navigation)
└── <router-outlet> (Dynamic Content)
    ├── IotDashboardViewComponent
    ├── IotKpiMetricsComponent
    ├── StationMonitoringComponent
    ├── IotAlertsComponent
    └── ProductionSimulationComponent
```

---

## 🚀 Quick Commands

### Start Development Server
```powershell
npm start
```

### Build for Production
```powershell
npm run build
```

### Run Tests
```powershell
npm test
```

### Lint Code
```powershell
npm run lint
```

---

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| Routes not loading | Check `app.routes.ts` configuration |
| Styles not applying | Verify CSS variables in `index.html` |
| Data not updating | Check service subscription in component |
| Sidebar not toggling | Verify click event binding |
| Theme not switching | Check ThemeService integration |

---

## 📚 File Structure

```
src/
├── services/
│   └── iot-production.service.ts       # Data service
├── components/
│   ├── iot-digital-twin/               # Main container
│   ├── iot-sidebar/                    # Navigation
│   ├── iot-dashboard-view/             # Overview
│   ├── iot-kpi-metrics/                # Analytics
│   ├── iot-station-monitoring/         # Stations
│   ├── iot-alerts/                     # Alerts
│   └── iot-production-simulation/      # Simulator
└── app.routes.ts                       # Route config
```

---

## 🎓 Key Technologies

- **Angular 18+** - Framework
- **TypeScript** - Programming language
- **RxJS** - Reactive programming
- **CSS Variables** - Dynamic theming
- **RouterModule** - Navigation
- **AuthGuard** - Route protection

---

## ✅ Feature Checklist

- ✅ Real-time monitoring (7 stations, 21 sensors)
- ✅ Digital twin visualization
- ✅ Predictive simulation (1-24 hours)
- ✅ Alert management system
- ✅ Responsive design (mobile/tablet/desktop)
- ✅ Theme switching (5 themes)
- ✅ Sidebar navigation (6 sections)
- ✅ Auth guard protection
- ✅ TypeScript strict mode
- ✅ Zero compilation errors

---

## 📖 Documentation Files

1. `IOT_DASHBOARD_README.md` - Complete overview
2. `QUICK_START.md` - Getting started
3. `IMPLEMENTATION_SUMMARY.md` - Technical details
4. `COMPONENT_STRUCTURE.md` - Architecture
5. `CUSTOMIZATION_GUIDE.md` - Customization
6. `UPDATE_IOT_THEME.md` - Theme migration
7. `IOT_TESTING_GUIDE.md` - Testing checklist
8. `FINAL_IMPLEMENTATION_SUMMARY.md` - Complete summary
9. `QUICK_REFERENCE.md` - This file

---

## 🎯 Status: PRODUCTION READY ✅

**Version:** 1.0.0  
**Last Updated:** December 5, 2025  
**Total Components:** 7  
**Total Routes:** 6  
**Total Sensors:** 21  

---

*Keep this reference handy for quick lookups!* 📌
