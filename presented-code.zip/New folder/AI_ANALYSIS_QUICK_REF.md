# 🤖 AI Analysis - Quick Reference

## 🎯 What It Does
Interactive manufacturing simulation with **7 slider parameters** → API call → **8 KPIs + 14 resource utilization metrics**

---

## 🎛️ Parameters (Quick View)

| Slider | Range | Default | Unit |
|--------|-------|---------|------|
| Machines | 50-200 | 120 | count |
| Inter-Arrival | 1-10 | 3 | min |
| Leak Fail | 0-20 | 6 | % |
| Func Fail | 0-10 | 2 | % |
| MTBF Scale | 0.5-2.0 | 1.0 | factor |
| Tub Stock | 50-500 | 200 | units |
| Cab Stock | 50-500 | 200 | units |

---

## 📊 KPIs Displayed

🏁 Started | ✅ Good | 🗑️ Scrap | 🔄 Rework  
⏱️ Waits | ⏰ Lead Time | 📈 Throughput | ⚡ Energy

---

## 🏭 Resources Monitored

1. Cabinet Sheet Metal
2. Cabinet Coating (often bottleneck)
3. Plastic Molding
4. Drum Deep Draw
5. Drum Weld Polish
6. PCB SMT
7. PCB Test
8. Subassembly Mount
9. Final Assembly
10. Leak Test
11. Leak Rework
12. Functional Test
13. Aging (often bottleneck)
14. Packing

---

## 🎨 Status Colors

| Color | Utilization | Meaning |
|-------|-------------|---------|
| 🔴 Red | ≥90% | **BOTTLENECK** |
| 🟠 Orange | 75-89% | High Load |
| 🔵 Blue | 50-74% | Normal |
| ⚫ Gray | <50% | Low |

---

## 🚀 Quick Workflow

```
1. Adjust sliders → 2. Click "Run Simulation" 
   ↓                      ↓
3. Wait for spinner → 4. View results
   ↓                      ↓
5. Identify bottlenecks → 6. Iterate!
```

---

## 📡 API

**Endpoint:** `POST http://127.0.0.1:8100/simulate`

**Request:**
```json
{
  "NUM_MACHINES": 120,
  "INTER_ARRIVAL": 3,
  "LEAK_FAIL_RATE": 0.06,
  "FUNC_FAIL_SCRAP_RATE": 0.02,
  "MTBF_SCALE": 1,
  "TUB_STOCK": 200,
  "CAB_STOCK": 200
}
```

**Response:** KPIs + Utilization array

---

## 🔍 How to Find Bottlenecks

1. Run simulation
2. Look for **red rows** in table
3. Check **>90% utilization**
4. High utilization + high wait time = bottleneck!

---

## 💡 Quick Tips

✅ **DO:**
- Start with defaults
- Adjust one parameter at a time
- Focus on red (bottleneck) resources
- Compare multiple runs

❌ **DON'T:**
- Change all parameters at once
- Ignore wait times
- Forget to check energy usage

---

## 📱 Access

**Route:** `/iot-dashboard/ai-analytics`  
**Sidebar:** 🤖 AI Analytics

---

## 🎓 Common Scenarios

### Increase Throughput
```
↑ NUM_MACHINES (150)
↓ INTER_ARRIVAL (2)
↑ Stock levels (300)
```

### Improve Quality
```
↓ LEAK_FAIL_RATE (0.03)
↓ FUNC_FAIL_SCRAP_RATE (0.01)
↑ MTBF_SCALE (1.5)
```

### Balance Energy
```
Keep throughput steady
Optimize bottlenecks
Check energy_kwh output
```

---

## 🐛 Troubleshooting

| Problem | Solution |
|---------|----------|
| Button disabled | Check all values valid |
| No results | Check API is running |
| Error message | Verify API endpoint |
| Slow response | Normal for complex sim |

---

## 📊 Sample Output

```
KPIs:
  Started: 120
  Good: 95 (79%)
  Scrap: 3 (2.5%)
  Throughput: 11.9/hr
  Energy: 930 kWh

Bottlenecks:
  🔴 Cabinet Coating: 97%
  🔴 Aging: 80%
```

---

## ✨ Visual Features

- **Gradient sliders** with live values
- **Animated KPI cards** (hover lift)
- **Color-coded utilization bars**
- **Pulsing bottleneck indicators**
- **Responsive grid layouts**

---

## 🎯 Key Metrics to Watch

1. **Throughput** - Units per hour
2. **Good Units** - Quality indicator
3. **Scrap Rate** - Waste level
4. **Lead Time** - Efficiency measure
5. **Bottleneck Resources** - Optimization targets

---

**Files Created:**
- `iot-ai-analysis.component.ts`
- `iot-ai-analysis.component.html`
- `iot-ai-analysis.component.css`

**Documentation:**
- `AI_ANALYSIS_COMPONENT_GUIDE.md` (full guide)
- `AI_ANALYSIS_QUICK_REF.md` (this file)

---

**Status:** ✅ Ready to Use  
**Version:** 1.0  
**Date:** December 6, 2025
