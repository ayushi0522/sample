# 🗺️ IoT Digital Twin Dashboard - Component Structure

## Application Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                       app.routes.ts                         │
│                    (Routing Configuration)                   │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                   iot-login.component                        │
│                   (Authentication)                           │
│                                                              │
│  Email: supervisor@iot.com                                   │
│  Password: password                                          │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│              iot-digital-twin.component                      │
│                 (Main Dashboard Container)                   │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Header: Factory Name, Status Bar, Timestamp           │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Status Bar: Completed | Queue | Efficiency | ETC      │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Tabs: [Overview] [Stations] [Simulation] [Alerts]    │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │              Tab Content Area                          │ │
│  │  ┌──────────────────────────────────────────────────┐  │ │
│  │  │  <router-outlet for child components>            │  │ │
│  │  └──────────────────────────────────────────────────┘  │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Tab Components Hierarchy

### Tab 1: Overview
```
┌─────────────────────────────────────────────────────────────┐
│              iot-kpi-metrics.component                       │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  KPI Cards Grid (6 cards)                             │ │
│  │  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ │ │
│  │  │ Eff  │ │Compl.│ │Queue │ │ ETC  │ │Downt.│ │Defect│ │ │
│  │  └──────┘ └──────┘ └──────┘ └──────┘ └──────┘ └──────┘ │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌─────────────────────┐  ┌──────────────────────────────┐ │
│  │ Top Performers      │  │ Issues & Bottlenecks         │ │
│  │ 1. Station A - 96%  │  │ • Station X - High Downtime  │ │
│  │ 2. Station B - 94%  │  │ • Station Y - Low Efficiency │ │
│  │ 3. Station C - 92%  │  │ • Station Z - Queue Buildup  │ │
│  └─────────────────────┘  └──────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Performance Matrix (7x7 Grid)                        │ │
│  │  [St1] [St2] [St3] [St4] [St5] [St6] [St7]           │ │
│  │  Color-coded by efficiency                             │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Real-time Production Flow                            │ │
│  │  (1) → (2) → (3) → (4) → (5) → (6) → (7) → ✓         │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### Tab 2: Stations
```
┌─────────────────────────────────────────────────────────────┐
│          iot-station-monitoring.component                    │
│                                                              │
│  ┌──────────────────────────┐  ┌──────────────────────────┐ │
│  │  Station Cards Grid      │  │  Detail Panel            │ │
│  │                          │  │                          │ │
│  │  ┌─────────────────────┐ │  │  Selected Station:       │ │
│  │  │ Sheet Metal Proc.   │ │  │  "Motor Assembly"        │ │
│  │  │ Cycle: 45s          │ │  │                          │ │
│  │  │ Queue: 3            │ │  │  Sensors:               │ │
│  │  │ Efficiency: 96%     │ │  │  🟢 Temp: 75°C / 90°C   │ │
│  │  │ [Test Downtime]     │ │  │  🟢 RPM: 1485 / 1800    │ │
│  │  └─────────────────────┘ │  │  🟢 Power: 18.5kW / 25kW│ │
│  │                          │  │                          │ │
│  │  ┌─────────────────────┐ │  │  Statistics:            │ │
│  │  │ Drum & Tub Asm.     │ │  │  • Cycle: 50s           │ │
│  │  │ Cycle: 55s          │ │  │  • Downtime: 0m         │ │
│  │  │ Queue: 8            │ │  │  • Completed: 112       │ │
│  │  │ Efficiency: 92%     │ │  │  • Queue: 14            │ │
│  │  │ [Test Downtime]     │ │  │  • Defects: 3.2%        │ │
│  │  └─────────────────────┘ │  │  • Efficiency: 88%      │ │
│  │                          │  │                          │ │
│  │  [5 more stations...]    │  │  Operator:              │ │
│  │                          │  │  👤 Ahmed Hassan         │ │
│  └──────────────────────────┘  │  Shift: 06:00 - 14:00   │ │
│                                 └──────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### Tab 3: Simulation
```
┌─────────────────────────────────────────────────────────────┐
│        iot-production-simulation.component                   │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Controls                                              │ │
│  │  Simulation Horizon: [━━━━━●──────] 8 hours           │ │
│  │  [🔄 Refresh Simulation]                              │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Hourly Prediction Cards                              │ │
│  │                                                         │ │
│  │  ┌────────────┐ ┌────────────┐ ┌────────────┐        │ │
│  │  │  Hour 1    │ │  Hour 2    │ │  Hour 3    │  ...   │ │
│  │  │────────────│ │────────────│ │────────────│        │ │
│  │  │ Completed: │ │ Completed: │ │ Completed: │        │ │
│  │  │   45 units │ │   90 units │ │  135 units │        │ │
│  │  │ Queue: 85  │ │ Queue: 70  │ │ Queue: 55  │        │ │
│  │  │ Downtime:  │ │ Downtime:  │ │ Downtime:  │        │ │
│  │  │   15 min   │ │   30 min   │ │   45 min   │        │ │
│  │  │ Bottleneck:│ │ Bottleneck:│ │ Bottleneck:│        │ │
│  │  │  Testing   │ │  Testing   │ │  Testing   │        │ │
│  │  │ ✓ On track │ │ ✓ On track │ │ ⚠ Warning  │        │ │
│  │  └────────────┘ └────────────┘ └────────────┘        │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Summary Statistics                                    │ │
│  │  Total Expected: 360 units | Final Queue: 10 units    │ │
│  │  Total Downtime: 120 min   | Bottleneck: Testing     │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  💡 Key Insights                                        │ │
│  │  • Peak production in hour 5                           │ │
│  │  • Queue levels maintained                             │ │
│  │  • Watch Testing station closely                       │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### Tab 4: Alerts
```
┌─────────────────────────────────────────────────────────────┐
│               iot-alerts.component                           │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Header                                                │ │
│  │  ⚠️ System Alerts & Notifications    [🗑️ Clear All]  │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Filter Bar                                            │ │
│  │  [All (12)] [Critical (3)] [Warning (5)] [Info (4)]   │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Alert Feed (scrollable)                              │ │
│  │                                                         │ │
│  │  ┌──────────────────────────────────────────────────┐  │ │
│  │  │ 🔴 Testing Station                   14:35:22    │  │ │
│  │  │ High downtime: 25 minutes                        │  │ │
│  │  │ [CRITICAL]                                       │  │ │
│  │  └──────────────────────────────────────────────────┘  │ │
│  │                                                         │ │
│  │  ┌──────────────────────────────────────────────────┐  │ │
│  │  │ 🟡 Motor Assembly                    14:35:20    │  │ │
│  │  │ Temperature warning: 82°C                        │  │ │
│  │  │ [WARNING]                                        │  │ │
│  │  └──────────────────────────────────────────────────┘  │ │
│  │                                                         │ │
│  │  [More alerts...]                                      │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Alert Statistics                                      │ │
│  │  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐        │ │
│  │  │ 🔴 (3) │ │ 🟡 (5) │ │ 🔵 (4) │ │ 📋 (12)│        │ │
│  │  │Critical│ │Warning │ │  Info  │ │ Total  │        │ │
│  │  └────────┘ └────────┘ └────────┘ └────────┘        │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Service Layer

```
┌─────────────────────────────────────────────────────────────┐
│            iot-production.service.ts                         │
│                                                              │
│  Data Structures:                                            │
│  • ProductionLineSnapshot                                    │
│  • StationData (x7)                                          │
│  • Sensor (x21 total, 3 per station)                        │
│  • SimulationResult                                          │
│                                                              │
│  Observables:                                                │
│  • productionLineData$ (updates every 5s)                   │
│  • simulationResults$                                        │
│  • stationHistory$                                           │
│                                                              │
│  Methods:                                                    │
│  • getProductionLine(): Observable                          │
│  • getSimulation(hours): Observable                         │
│  • getAlerts(): Alert[]                                     │
│  • triggerDowntimeEvent(stationId): void                    │
│  • updateStationData(station): StationData                  │
│  • calculateLineEfficiency(stations): number                │
│                                                              │
│  Real-time Simulation:                                       │
│  • Cycle time variations (±10s)                             │
│  • Random downtime events (5% probability)                  │
│  • Queue management                                          │
│  • Sensor value fluctuations                                │
│  • Efficiency calculations                                   │
│  • Alert generation                                          │
└─────────────────────────────────────────────────────────────┘
```

## Data Flow

```
┌──────────────────┐
│  User Action     │
│  (Tab Selection, │
│   Simulation,    │
│   Station Click) │
└────────┬─────────┘
         ↓
┌────────────────────────────────────────┐
│     Component Event Handler            │
│  • setActiveTab()                      │
│  • selectStation()                     │
│  • runSimulation()                     │
│  • setFilter()                         │
└────────┬───────────────────────────────┘
         ↓
┌────────────────────────────────────────┐
│   IotProductionService Method Call     │
│  • getProductionLine()                 │
│  • getSimulation(hours)                │
│  • getAlerts()                         │
│  • triggerDowntimeEvent()              │
└────────┬───────────────────────────────┘
         ↓
┌────────────────────────────────────────┐
│   Observable Stream                    │
│  (Real-time data every 5 seconds)      │
└────────┬───────────────────────────────┘
         ↓
┌────────────────────────────────────────┐
│   Component Subscription               │
│  .pipe(takeUntil(destroy$))            │
│  .subscribe(data => { ... })           │
└────────┬───────────────────────────────┘
         ↓
┌────────────────────────────────────────┐
│   Update Component State               │
│  this.productionData = data;           │
│  ChangeDetection: OnPush               │
└────────┬───────────────────────────────┘
         ↓
┌────────────────────────────────────────┐
│   Template Renders                     │
│  {{ data.lineEfficiency }}%            │
│  *ngFor="let station of stations"      │
└────────────────────────────────────────┘
```

## Component Communication

```
         iot-digital-twin (Parent)
                  │
                  │ Provides context
                  │ Manages tab state
                  │
       ┌──────────┼──────────┬──────────┐
       │          │          │          │
   iot-kpi    iot-station  iot-sim   iot-alerts
   -metrics   -monitoring  -ulation   (Child)
   (Child)     (Child)     (Child)
       │          │          │          │
       │          │          │          │
       └──────────┴──────────┴──────────┘
                  │
                  │ All subscribe to
                  │
         IotProductionService
              (Singleton)
```

## File Organization

```
src/
├── services/
│   └── iot-production.service.ts       (1,000 lines)
│
├── components/
│   ├── iot-digital-twin/
│   │   ├── iot-digital-twin.component.ts    (70 lines)
│   │   ├── iot-digital-twin.component.html  (100 lines)
│   │   └── iot-digital-twin.component.css   (350 lines)
│   │
│   ├── iot-station-monitoring/
│   │   ├── iot-station-monitoring.component.ts    (90 lines)
│   │   ├── iot-station-monitoring.component.html  (130 lines)
│   │   └── iot-station-monitoring.component.css   (450 lines)
│   │
│   ├── iot-production-simulation/
│   │   ├── iot-production-simulation.component.ts   (70 lines)
│   │   ├── iot-production-simulation.component.html (150 lines)
│   │   └── iot-production-simulation.component.css  (400 lines)
│   │
│   ├── iot-kpi-metrics/
│   │   ├── iot-kpi-metrics.component.ts    (100 lines)
│   │   ├── iot-kpi-metrics.component.html  (180 lines)
│   │   └── iot-kpi-metrics.component.css   (550 lines)
│   │
│   └── iot-alerts/
│       ├── iot-alerts.component.ts    (100 lines)
│       ├── iot-alerts.component.html  (100 lines)
│       └── iot-alerts.component.css   (350 lines)
│
└── app.routes.ts                      (Modified)

Total: ~3,500+ lines of code
```

## Key Technologies

- **Angular 21**: Latest framework version
- **TypeScript 5.9**: Type-safe development
- **RxJS 7.8**: Reactive programming
- **CSS3**: Modern styling with animations
- **FormsModule**: Two-way data binding
- **CommonModule**: Angular directives

---

**This structure provides a scalable, maintainable, and professional IoT dashboard solution! 🏭**
