# 🚀 Quick Start Guide - IoT Digital Twin Dashboard

## What Was Created

I've built a complete **IoT Digital Twin Dashboard** for a washing machine factory with the following components:

### 📁 New Files Created

1. **Service Layer**:
   - `src/services/iot-production.service.ts` - Core production line simulation and data management

2. **Main Dashboard**:
   - `src/components/iot-digital-twin/iot-digital-twin.component.ts`
   - `src/components/iot-digital-twin/iot-digital-twin.component.html`
   - `src/components/iot-digital-twin/iot-digital-twin.component.css`

3. **Station Monitoring**:
   - `src/components/iot-station-monitoring/iot-station-monitoring.component.ts`
   - `src/components/iot-station-monitoring/iot-station-monitoring.component.html`
   - `src/components/iot-station-monitoring/iot-station-monitoring.component.css`

4. **Production Simulation**:
   - `src/components/iot-production-simulation/iot-production-simulation.component.ts`
   - `src/components/iot-production-simulation/iot-production-simulation.component.html`
   - `src/components/iot-production-simulation/iot-production-simulation.component.css`

5. **KPI Metrics**:
   - `src/components/iot-kpi-metrics/iot-kpi-metrics.component.ts`
   - `src/components/iot-kpi-metrics/iot-kpi-metrics.component.html`
   - `src/components/iot-kpi-metrics/iot-kpi-metrics.component.css`

6. **Alerts System**:
   - `src/components/iot-alerts/iot-alerts.component.ts`
   - `src/components/iot-alerts/iot-alerts.component.html`
   - `src/components/iot-alerts/iot-alerts.component.css`

7. **Documentation**:
   - `IOT_DASHBOARD_README.md`

### 📝 Modified Files

- `src/app.routes.ts` - Added IoT dashboard route
- `src/components/iot-login/iot-login.component.ts` - Updated navigation to IoT dashboard

## 🏭 Production Line Stations

The dashboard monitors 7 stations in the washing machine production line:

1. **Sheet Metal Processing** - Cutting and forming metal sheets
2. **Drum & Tub Assembly** - Assembling the washing drum and tub
3. **Motor Assembly** - Motor installation and configuration
4. **Wiring & Connections** - Electrical wiring and connections
5. **Final Assembly** - Complete unit assembly
6. **Quality Testing** - Leak tests, noise checks, performance validation
7. **Packing & Shipping** - Final packaging and shipping preparation

## 🎯 Key Features

### 1. Real-Time Monitoring
- Live data updates every 5 seconds
- Cycle time tracking per station
- Downtime event detection
- Queue management
- Efficiency calculations

### 2. Sensor Data
Each station has 3 sensors monitoring:
- Temperature (°C)
- Vibration/Pressure/Humidity (varies by station)
- Power Consumption (kW)

All sensors have threshold monitoring with warning/critical alerts.

### 3. Digital Twin Simulation
- Predicts production for next 1-24 hours
- Identifies bottlenecks
- Forecasts queue buildup
- Provides actionable recommendations

### 4. Smart Alerts
- Critical, warning, and info severity levels
- Real-time notification feed
- Filter by severity
- Alert history

## 🚀 How to Run

### Step 1: Navigate to Project
```powershell
cd "c:\ayushi\sample-main\sample-main\final-project-backup\final-project-backup"
```

### Step 2: Start Development Server
```powershell
npm run dev
```

### Step 3: Open Browser
Navigate to: `http://localhost:4200`

### Step 4: Login
- Click on IoT Login (or navigate to `/iot-login`)
- Use credentials:
  - **Email**: `supervisor@iot.com`
  - **Password**: `password`
- Click "Sign In"

### Step 5: Explore Dashboard
You'll be redirected to `/iot-dashboard` where you can:

1. **Overview Tab** (Default):
   - View KPI metrics
   - See top performers
   - Check bottlenecks
   - Monitor production flow
   - View performance matrix

2. **Stations Tab**:
   - Click on any station card
   - View detailed sensor data
   - Monitor station statistics
   - Test downtime events

3. **Simulation Tab**:
   - Adjust time horizon slider (1-24 hours)
   - View hourly predictions
   - Read key insights
   - Check recommendations

4. **Alerts Tab**:
   - See real-time alerts
   - Filter by severity
   - View alert statistics

## 📊 Understanding the Data

### Color Coding
- 🟢 **Green**: Normal operation (≥90% efficiency)
- 🟡 **Yellow**: Warning (75-89% efficiency)
- 🔴 **Red**: Critical (<75% efficiency)

### Key Metrics
- **Line Efficiency**: Overall production line performance
- **Total Completed**: Units finished today
- **Work in Queue**: Units waiting to be processed
- **ETC**: Estimated Time to Completion for current queue
- **Avg Downtime**: Average downtime across all stations

### Sensor Thresholds
- **Normal**: Value < 70% of threshold
- **Warning**: Value between 70-90% of threshold
- **Critical**: Value > 90% of threshold

## 🧪 Testing Features

### Simulate Downtime
1. Go to "Stations" tab
2. Click on any station card
3. Click "Test Downtime" button
4. Watch the station's downtime increase
5. Observe the impact on efficiency and alerts

### Adjust Simulation
1. Go to "Simulation" tab
2. Move the time horizon slider
3. Click "Refresh Simulation"
4. Compare predictions for different time periods

### Filter Alerts
1. Go to "Alerts" tab
2. Click filter buttons (Critical, Warning, Info)
3. View filtered alerts
4. Click "Clear All" to remove alerts

## 💡 Tips

1. **Real-Time Updates**: Data automatically refreshes every 5 seconds
2. **Responsive Design**: Resize browser to see mobile/tablet views
3. **Hover Effects**: Hover over cards for interactive feedback
4. **Status Indicators**: Watch for color changes indicating status
5. **Bottleneck Detection**: "Testing" station often becomes bottleneck

## 🎨 Design Highlights

- Modern dark theme with blue accents
- Glassmorphism effects with backdrop blur
- Smooth animations and transitions
- Gradient backgrounds
- Color-coded status indicators
- Emoji icons for visual clarity
- Responsive grid layouts
- Custom scrollbars

## 🔧 Architecture

### Service Pattern
- **IotProductionService** is a singleton service
- Provides observables for reactive data
- Simulates real-time factory data
- Calculates predictions and alerts

### Component Structure
- Standalone components with OnPush detection
- Minimal re-renders for performance
- RxJS subscriptions with proper cleanup
- Type-safe interfaces

### Data Flow
```
IotProductionService
  ↓ Observable
Dashboard Component
  ↓ Tab Selection
Child Components (KPI, Stations, Simulation, Alerts)
  ↓ Display
User Interface
```

## 📱 Responsive Breakpoints

- **Desktop**: Full layout with all features
- **Tablet (≤1024px)**: Adjusted grid layouts
- **Mobile (≤768px)**: Single column layouts
- **Small Mobile (≤480px)**: Compact UI elements

## 🐛 Troubleshooting

### Issue: Page not loading
- Check if dev server is running
- Verify URL: `http://localhost:4200/iot-login`
- Check browser console for errors

### Issue: Login not working
- Use exact credentials: `supervisor@iot.com` / `password`
- Clear browser cache if needed

### Issue: Data not updating
- Check browser console for errors
- Refresh the page
- Verify service is running

## 📚 Next Steps

1. Explore all four tabs
2. Click on different stations
3. Adjust simulation time horizon
4. Watch alerts appear in real-time
5. Test downtime simulation
6. Monitor efficiency changes

## 🌟 Additional Features

- Export capability (future)
- Historical data analysis (future)
- Machine learning predictions (future)
- Integration with real IoT devices (future)

---

**Enjoy exploring your IoT Digital Twin Dashboard! 🏭✨**
