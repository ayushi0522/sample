# 🎨 Station Utilization - Visual Reference

## 📊 What You'll See

### **1. Data Table (Top Section)**

```
╔══════════════════════════════════════════════════════════════════════╗
║              📊 Station Utilization Analysis                         ║
╠══════════════════════════════════════════════════════════════════════╣
║                                                                       ║
║  ┌──────────────────────────────────────────────────────────────┐  ║
║  │ Station         │ Baseline │ Scenario │ Change  │ Status    │  ║
║  ├──────────────────────────────────────────────────────────────┤  ║
║  │ 🏭 Assembly     │  75.0%   │  85.0%   │ +13.3%  │ ✓ Normal │  ║
║  │ 🏭 Quality      │  80.0%   │  90.5%   │ +13.1%  │⚡High Load│  ║
║  │ 🏭 Packaging    │  95.0%   │  98.0%   │  +3.2%  │⚠️Bottleneck│🔴
║  └──────────────────────────────────────────────────────────────┘  ║
║                                                                       ║
╚══════════════════════════════════════════════════════════════════════╝
```

**Bottleneck Row Features:**
- 🔴 Red left border (4px thick)
- Pink/red background tint
- Pulsing red shadow effect
- "⚠️ Bottleneck" badge

---

### **2. Flow Diagram (Bottom Section)**

```
╔══════════════════════════════════════════════════════════════════════╗
║          📊 Production Flow Visualization                            ║
╠══════════════════════════════════════════════════════════════════════╣
║                                                                       ║
║  ┌─────────────┐       ┌─────────────┐       ┌─────────────┐      ║
║  │ 🟢 Assembly │  →    │ 🟡 Quality  │  →    │ 🔴 Packaging│      ║
║  │             │       │             │       │             │      ║
║  │ ████████░░  │       │ █████████░  │       │ ██████████  │      ║
║  │    85%      │       │    90.5%    │       │    98%      │      ║
║  └─────────────┘       └─────────────┘       └─────────────┘      ║
║     Normal               High Load          ⚠️ BOTTLENECK         ║
║   (Green Border)       (Orange Border)      (Red Border)           ║
║                                             🔴 PULSING              ║
║                                                                       ║
║  Legend:                                                             ║
║  🔴 Bottleneck (>90% + Critical)  🟡 High Load (>90%)              ║
║  🟢 Normal (75-90%)               🟢 Low (<75%)                     ║
╚══════════════════════════════════════════════════════════════════════╝
```

---

## 🎬 Animation Effects

### **Bottleneck Node Animations:**

1. **Border Pulsing** (2 seconds loop)
   ```
   Frame 1: ╔════════╗ (Solid red border)
   Frame 2: ╔ ≈≈≈≈≈≈ ╗ (Border + expanding shadow)
   Frame 3: ╔  ~~~  ╗ (Shadow fades out)
   Frame 1: ╔════════╗ (Repeat)
   ```

2. **Warning Text Flashing** (1.5 seconds loop)
   ```
   "⚠️ BOTTLENECK"  (100% opacity)
   "⚠️ BOTTLENECK"  (60% opacity)
   "⚠️ BOTTLENECK"  (100% opacity)
   ```

3. **Progress Bar Pulsing** (1.5 seconds loop)
   ```
   ██████████ (100% opacity - Red)
   ██████████ (70% opacity - Dark red)
   ██████████ (100% opacity - Red)
   ```

4. **Arrow Pulsing** (1.5 seconds loop)
   ```
   →  (Normal size, red color)
   ⇒  (20% larger, bright red)
   →  (Normal size, red color)
   ```

---

## 🎨 Color Guide

### **Status Colors in Table**

| Status | Badge Color | Text Color | Background |
|--------|-------------|------------|------------|
| ⚠️ Bottleneck | #ef4444 (Red) | White | Pulsing shadow |
| ⚡ High Load | #f59e0b (Orange) | White | Solid |
| ✓ Normal | #10b981 (Green) | White | Solid |
| ○ Low | #6b7280 (Gray) | White | Solid |

### **Node Border Colors**

| Status | Border | Background Gradient |
|--------|--------|---------------------|
| Bottleneck | 🔴 #ef4444 | Red → Light Red |
| High Load | 🟡 #f59e0b | Orange → Light Orange |
| Normal | 🟢 #10b981 | Green → Light Green |
| Low | 🟢 #6b7280 | Gray → Light Gray |

---

## 📱 Responsive Layouts

### **Desktop View (>1024px)**

```
┌─────────┐  →  ┌─────────┐  →  ┌─────────┐  →  ┌─────────┐
│Station 1│     │Station 2│     │Station 3│     │Station 4│
└─────────┘     └─────────┘     └─────────┘     └─────────┘
   (All in one horizontal row)
```

### **Tablet View (768px-1024px)**

```
┌─────────┐
│Station 1│
└─────────┘
     ↓
┌─────────┐
│Station 2│
└─────────┘
     ↓
┌─────────┐
│Station 3│
└─────────┘
   (Stacked vertically with down arrows)
```

### **Mobile View (<768px)**

```
┌──────────────────┐
│    Station 1     │
└──────────────────┘
        ↓
┌──────────────────┐
│    Station 2     │
└──────────────────┘
        ↓
┌──────────────────┐
│    Station 3     │
└──────────────────┘
  (Full width cards)
```

---

## 🔍 Hover Effects

### **Table Row Hover:**
```
Before:  [Normal row with white background]
Hover:   [Slightly larger with gray background]
         [Smooth scale(1.01) transform]
```

### **Flow Node Hover:**
```
Before:  [Node at normal position]
Hover:   [Lifted up 4px with larger shadow]
         [translateY(-4px) + bigger shadow]
```

---

## 🎯 Quick Identification Guide

### **How to Spot Bottlenecks:**

1. **In Table:**
   - Look for RED left border
   - Find "⚠️ Bottleneck" badge (pulsing red)
   - Check for pink/red row background

2. **In Flow Diagram:**
   - Look for 🔴 RED icon
   - Find RED pulsing border
   - See "⚠️ BOTTLENECK" warning text (flashing)
   - Notice RED progress bar (pulsing)
   - Red arrows pointing to/from it

---

## 📊 Example Scenarios

### **Scenario 1: Single Bottleneck**

```
Table:
✓ Assembly     → Green status, normal
✓ Quality      → Green status, normal
⚠️ Packaging   → RED status, pulsing (BOTTLENECK)

Flow:
🟢 Assembly → 🟢 Quality → 🔴 Packaging
                            ↑ 
                         RED PULSING
```

### **Scenario 2: Multiple Issues**

```
Table:
✓ Assembly     → Green (Normal)
⚡ Quality     → Orange (High Load)
⚠️ Packaging   → RED (Bottleneck)
○ Shipping     → Gray (Low)

Flow:
🟢 Assembly → 🟡 Quality → 🔴 Packaging → 🟢 Shipping
               (Warning)    (CRITICAL)     (Underused)
```

---

## 💡 User Tips

### **Reading the Table:**

1. **Scan for RED** - Immediate problems
2. **Check ORANGE** - Potential issues
3. **Compare Baseline vs Scenario** - See impact
4. **Look at Change %** - Understand magnitude

### **Reading the Flow:**

1. **Follow the arrows** - See production sequence
2. **Red nodes = STOP** - Critical attention needed
3. **Yellow nodes = CAUTION** - Monitor closely
4. **Green nodes = GO** - Operating well

### **Taking Action:**

1. **Bottleneck Found?**
   - Add capacity to that station
   - Optimize workflow
   - Redistribute tasks

2. **High Load?**
   - Monitor closely
   - Prepare contingency
   - Schedule maintenance

3. **Low Load?**
   - Reduce resources
   - Increase throughput upstream
   - Reallocate staff

---

## 🎬 Live Example Output

### **User Query:**
```
"What happens if I increase production by 20%?"
```

### **AI Response Includes:**

**📊 Table Section:**
```
Station Utilization Analysis

┌─────────────────────────────────────────────────────┐
│ 🏭 Assembly Line    │ 72% │ 86% │ +19.4% │ ✓ Normal│
│ 🏭 Quality Control  │ 85% │ 94% │ +10.6% │⚡High   │
│ 🏭 Packaging Station│ 92% │ 99% │  +7.6% │⚠️Bottle │← RED
└─────────────────────────────────────────────────────┘
```

**📊 Flow Section:**
```
Production Flow Visualization

┌────────────┐  →  ┌────────────┐  →  ┌────────────┐
│🟢 Assembly │     │🟡 Quality  │     │🔴 Packaging│
│ ████████░░ │     │ █████████░ │     │ ██████████ │
│    86%     │     │    94%     │     │    99%     │
└────────────┘     └────────────┘     └────────────┘
                                      ⚠️ BOTTLENECK
                                      🔴 PULSING
```

**Legend:**
```
🔴 Bottleneck (>90% + Critical)  →  URGENT ACTION
🟡 High Load (>90%)               →  Monitor Closely
🟢 Normal (75-90%)                →  Operating Well
🟢 Low (<75%)                     →  Underutilized
```

---

## ✅ Visual Checklist

When looking at the response, you should see:

**Table:**
- [ ] All 5 columns visible
- [ ] Station names formatted (no underscores)
- [ ] Percentages with 1 decimal place
- [ ] Change badges colored (green/red)
- [ ] Status badges with icons
- [ ] Red border on bottleneck rows
- [ ] Hover effect on rows

**Flow Diagram:**
- [ ] Stations in sequence
- [ ] Colored borders (red/orange/green)
- [ ] Icons (🔴 🟡 🟢)
- [ ] Utilization bars inside nodes
- [ ] Percentage labels
- [ ] Arrows between nodes
- [ ] "⚠️ BOTTLENECK" on critical stations
- [ ] Legend at bottom
- [ ] Animations playing smoothly

**Bottleneck Indicators:**
- [ ] Red color everywhere
- [ ] Pulsing border animation
- [ ] Flashing warning text
- [ ] Pulsing progress bar
- [ ] Pulsing status badge
- [ ] Red arrow to next station
- [ ] Visual hierarchy (stands out)

---

## 🚀 Quick Test

To see this in action:

1. **Start the app:** `npm start`
2. **Login:** iot / iot123
3. **Go to:** Production Simulation
4. **Scroll to:** AI Simulation Assistant
5. **Ask:** "What happens if I increase production by 20%?"
6. **Observe:**
   - Data table appears
   - Flow diagram renders
   - Bottlenecks show in RED
   - Animations play smoothly

**Expected Result:** Beautiful, professional visualization! ✨

---

*This is what you'll see on screen when the API returns station utilization data!*
