import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ThemeService } from './services/theme.service';
import { AlertService } from './services/alert.service';
import { AlertComponent } from './components/shared/alert/alert.component';

@Component({
  selector: 'app-root',
  standalone: true,
  template: `
    <main class="app-main">
      <router-outlet></router-outlet>
      @if(alertService.alert(); as alert) {
        <app-alert [message]="alert.message" [type]="alert.type"></app-alert>
      }
    </main>
  `,
  styleUrls: ['./app.component.css'],
  imports: [RouterOutlet, CommonModule, AlertComponent],
})
export class AppComponent {
  // Initialize theme service to apply the theme on startup
  private themeService = inject(ThemeService); 
  alertService = inject(AlertService);
}
