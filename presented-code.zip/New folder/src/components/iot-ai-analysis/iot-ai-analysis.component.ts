import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

interface SimulationParams {
  NUM_MACHINES: number;
  INTER_ARRIVAL: number;
  LEAK_FAIL_RATE: number;
  FUNC_FAIL_SCRAP_RATE: number;
  MTBF_SCALE: number;
  TUB_STOCK: number;
  CAB_STOCK: number;
}

interface KPIs {
  started: number;
  good: number;
  scrap: number;
  rework: number;
  material_waits: number;
  avg_lead_time: number;
  throughput_per_hr: number;
  energy_kwh: number;
}

interface ResourceUtilization {
  resource: string;
  utilization: number;
  energy_kwh: number;
  avg_wait: number;
}

interface SimulationResponse {
  kpis: KPIs;
  utilization: ResourceUtilization[];
  params: SimulationParams;
}

interface ChatMessage {
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AIAgentRequest {
  question: string;
  baseline: {
    additionalProp1: SimulationResponse;
  };
}

interface AIAgentResponse {
  answer: string;
}

@Component({
  selector: 'app-iot-ai-analysis',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './iot-ai-analysis.component.html',
  styleUrls: ['./iot-ai-analysis.component.css'],
})
export class IotAiAnalysisComponent {
  // Simulation parameters with default values
  params = signal<SimulationParams>({
    NUM_MACHINES: 120,
    INTER_ARRIVAL: 3,
    LEAK_FAIL_RATE: 0.06,
    FUNC_FAIL_SCRAP_RATE: 0.02,
    MTBF_SCALE: 1,
    TUB_STOCK: 200,
    CAB_STOCK: 200,
  });

  isLoading = signal(false);
  error = signal<string | null>(null);
  results = signal<SimulationResponse | null>(null);

  // Chat functionality
  chatMessages = signal<ChatMessage[]>([]);
  userQuestion = signal('');
  isChatLoading = signal(false);
  chatError = signal<string | null>(null);

  private apiUrl = 'http://127.0.0.1:8100/simulate';
  private aiAgentUrl = 'http://127.0.0.1:8100/ai-agent';

  constructor(private http: HttpClient) {}

  // Update parameter value
  updateParam(key: keyof SimulationParams, value: number) {
    this.params.update(params => ({
      ...params,
      [key]: value,
    }));
  }

  // Run simulation
  async runSimulation() {
    this.isLoading.set(true);
    this.error.set(null);

    try {
      const response = await this.http
        .post<SimulationResponse>(this.apiUrl, this.params())
        .toPromise();

      if (response) {
        this.results.set(response);
      }
    } catch (err: any) {
      this.error.set(err.message || 'Failed to run simulation');
      console.error('Simulation error:', err);
    } finally {
      this.isLoading.set(false);
    }
  }

  // Reset to default values
  resetToDefaults() {
    this.params.set({
      NUM_MACHINES: 120,
      INTER_ARRIVAL: 3,
      LEAK_FAIL_RATE: 0.06,
      FUNC_FAIL_SCRAP_RATE: 0.02,
      MTBF_SCALE: 1,
      TUB_STOCK: 200,
      CAB_STOCK: 200,
    });
    this.results.set(null);
    this.error.set(null);
  }

  // Format resource name
  formatResourceName(resource: string): string {
    return resource
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }

  // Get utilization color class
  getUtilizationClass(utilization: number): string {
    if (utilization >= 0.9) return 'critical';
    if (utilization >= 0.75) return 'high';
    if (utilization >= 0.5) return 'medium';
    return 'low';
  }

  // Check if resource is bottleneck
  isBottleneck(utilization: number): boolean {
    return utilization >= 0.9;
  }
  // Get sorted utilization (bottlenecks first)
  getSortedUtilization(): ResourceUtilization[] {
    if (!this.results()) return [];
    return [...this.results()!.utilization].sort((a, b) => b.utilization - a.utilization);
  }

  // Send question to AI agent
  async sendQuestion() {
    const question = this.userQuestion().trim();
    if (!question || this.isChatLoading() || !this.results()) return;

    // Add user message
    this.chatMessages.update(msgs => [
      ...msgs,
      {
        type: 'user',
        content: question,
        timestamp: new Date(),
      },
    ]);

    this.userQuestion.set('');
    this.isChatLoading.set(true);
    this.chatError.set(null);

    try {
      const requestBody: AIAgentRequest = {
        question: question,
        baseline: {
          additionalProp1: this.results()!,
        },
      };

      const response = await this.http
        .post<AIAgentResponse>(this.aiAgentUrl, requestBody)
        .toPromise();

      if (response) {
        // Add assistant message
        this.chatMessages.update(msgs => [
          ...msgs,
          {
            type: 'assistant',
            content: response.answer,
            timestamp: new Date(),
          },
        ]);
      }
    } catch (err: any) {
      this.chatError.set(err.message || 'Failed to get AI response');
      this.chatMessages.update(msgs => [
        ...msgs,
        {
          type: 'assistant',
          content: '❌ Failed to get AI recommendation. Please try again.',
          timestamp: new Date(),
        },
      ]);
    } finally {
      this.isChatLoading.set(false);
    }
  }

  // Clear chat history
  clearChat() {
    this.chatMessages.set([]);
    this.chatError.set(null);
  }

  // Format timestamp for chat messages
  formatTime(date: Date): string {
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }).format(date);
  }

  // Remove markdown formatting from text
  stripMarkdown(text: string): string {
    if (!text) return '';
    
    return text
      // Remove bold (**text** or __text__)
      .replace(/\*\*(.+?)\*\*/g, '$1')
      .replace(/__(.+?)__/g, '$1')
      // Remove italic (*text* or _text_)
      .replace(/\*(.+?)\*/g, '$1')
      .replace(/_(.+?)_/g, '$1')
      // Remove inline code (`code`)
      .replace(/`(.+?)`/g, '$1')
      // Remove headers (# Header)
      .replace(/^#+\s+/gm, '')
      // Remove bullet points
      .replace(/^\s*[-*+]\s+/gm, '• ')
      // Remove numbered lists
      .replace(/^\s*\d+\.\s+/gm, '')
      // Remove links [text](url)
      .replace(/\[(.+?)\]\(.+?\)/g, '$1')
      // Remove remaining special characters
      .replace(/[~`]/g, '')
      .trim();
  }
}
