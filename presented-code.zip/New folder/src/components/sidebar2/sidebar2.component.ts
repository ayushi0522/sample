import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-sidebar2',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './sidebar2.component.html',
  styleUrls: ['./sidebar2.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Sidebar2Component {
  isExpanded = signal(true);

  menuItems = [
    { name: 'Itinerary Planner', iconName: 'planner', link: '/travel-dashboard/planner' },
    { name: 'My Trips', iconName: 'trips', link: '/travel-dashboard/my-trips' },
    { name: 'Profile', iconName: 'profile', link: '/travel-dashboard/profile' },
  ];

  toggleSidebar() {
    this.isExpanded.update(value => !value);
  }
}