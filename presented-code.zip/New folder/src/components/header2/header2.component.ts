import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-header2',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header2.component.html',
  styleUrls: ['./header2.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Header2Component {
  authService = inject(AuthService);
  isProfileOpen = signal(false);

  toggleProfileMenu(): void {
    this.isProfileOpen.update(v => !v);
  }

  logout(): void {
    this.isProfileOpen.set(false);
    this.authService.logout();
  }
}
