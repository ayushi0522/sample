import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ItineraryService, ItineraryRequest } from '../../services/itinerary.service';

@Component({
  selector: 'app-itinerary-planner',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './itinerary-planner.component.html',
  styleUrls: ['./itinerary-planner.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ItineraryPlannerComponent {
  itineraryService = inject(ItineraryService);

  // Form Signals
  destination = signal('Paris, France');
  startDate = signal(new Date().toISOString().split('T')[0]);
  endDate = signal(new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
  interests = signal('history, art, culinary experiences, and local markets');
  budget = signal<'budget' | 'mid-range' | 'luxury'>('mid-range');
  
  // State Signals
  itinerary = signal<any | null>(null);
  error = signal<string | null>(null);

  async generateItinerary(): Promise<void> {
    this.itinerary.set(null);
    this.error.set(null);
    this.itineraryService.resetStatus();

    const request: ItineraryRequest = {
      destination: this.destination(),
      startDate: this.startDate(),
      endDate: this.endDate(),
      interests: this.interests(),
      budget: this.budget(),
    };

    try {
      const result = await this.itineraryService.generateItinerary(request);
      this.itinerary.set(result);
    } catch (e: any) {
      this.error.set(e.message || 'An unknown error occurred.');
    }
  }
  
  getDestinationImageUrl(destination: string): string {
    const cleanDestination = destination.split(',')[0].trim();
    return `https://source.unsplash.com/1600x400/?${encodeURIComponent(cleanDestination)}`;
  }

  getPhotoForActivity(description: string): string | null {
    const lowerDesc = description.toLowerCase();
    let keyword: string | null = null;
    const landmarks = ['eiffel tower', 'louvre', 'notre-dame', 'arc de triomphe', 'sacre-coeur', 'montmartre'];
    const landmark = landmarks.find(l => lowerDesc.includes(l));

    if (landmark) {
      keyword = landmark;
    } else if (lowerDesc.includes('hotel')) {
      keyword = 'luxury hotel lobby';
    } else if (lowerDesc.includes('museum')) {
        keyword = 'art museum';
    } else if (lowerDesc.includes('dinner') || lowerDesc.includes('restaurant') || lowerDesc.includes('culinary')) {
        keyword = 'paris restaurant gourmet';
    } else if (lowerDesc.includes('market')) {
        keyword = 'paris street market';
    }

    if (keyword) {
        return `https://source.unsplash.com/400x300/?${encodeURIComponent(keyword)}`;
    }
    return null;
  }

  getIconForActivity(type: string): string {
    const lowerType = type.toLowerCase();
    if (lowerType.includes('flight') || lowerType.includes('arrive') || lowerType.includes('depart')) return '✈️';
    if (lowerType.includes('hotel') || lowerType.includes('check-in')) return '🏨';
    if (lowerType.includes('train') || lowerType.includes('metro')) return '🚇';
    if (lowerType.includes('uber') || lowerType.includes('taxi') || lowerType.includes('transport')) return '🚕';
    if (lowerType.includes('food') || lowerType.includes('lunch') || lowerType.includes('dinner') || lowerType.includes('breakfast') || lowerType.includes('culinary') || lowerType.includes('restaurant')) return '🍽️';
    if (lowerType.includes('museum') || lowerType.includes('art') || lowerType.includes('history')) return '🏛️';
    if (lowerType.includes('tour') || lowerType.includes('walk')) return '🚶‍♀️';
    if (lowerType.includes('music') || lowerType.includes('show') || lowerType.includes('event')) return '🎭';
    if (lowerType.includes('market') || lowerType.includes('shop')) return '🛍️';
    if (lowerType.includes('park') || lowerType.includes('garden')) return '🌳';
    return '📌';
  }
}