import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IotProductionService,
  SimulationResult,
} from '../../services/iot-production.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { IotSimulationChatComponent } from '../iot-simulation-chat/iot-simulation-chat.component';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-iot-production-simulation',
  standalone: true,
  imports: [CommonModule, FormsModule, IotSimulationChatComponent, HttpClientModule],
  templateUrl: './iot-production-simulation.component.html',
  styleUrls: ['./iot-production-simulation.component.css'],
})
export class ProductionSimulationComponent implements OnInit, OnDestroy {
  simulationResults: SimulationResult[] = [];
  simulationHours: number = 8;
  maxHours: number = 24;
  showChat: boolean = true;
  private destroy$ = new Subject<void>();

  constructor(private iotService: IotProductionService) {}

  ngOnInit(): void {
    this.runSimulation();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  runSimulation(): void {
    this.iotService
      .getSimulation(this.simulationHours)
      .pipe(takeUntil(this.destroy$))
      .subscribe((results) => {
        this.simulationResults = results;
      });
  }

  onHoursChanged(): void {
    this.runSimulation();
  }

  getMaxCompletion(): number {
    if (this.simulationResults.length === 0) return 0;
    return Math.max(...this.simulationResults.map((r) => r.expectedCompletion));
  }

  getRecommendationClass(recommendation: string): string {
    if (recommendation.startsWith('✓')) return 'success';
    if (recommendation.startsWith('⚠')) return 'warning';
    return 'info';
  }

  getProgressPercentage(current: number, max: number): number {
    if (max === 0) return 0;
    return (current / max) * 100;
  }

  toggleChat(): void {
    this.showChat = !this.showChat;
  }
}
