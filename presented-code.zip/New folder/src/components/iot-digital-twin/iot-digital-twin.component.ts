import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { IotSidebarComponent } from '../iot-sidebar/iot-sidebar.component';
import { HeaderComponent } from '../header/header.component';
import { ChatWidgetComponent } from '../chat/chat-widget.component';

@Component({
  selector: 'app-iot-digital-twin',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    IotSidebarComponent,
    HeaderComponent,
    ChatWidgetComponent,
  ],
  templateUrl: './iot-digital-twin.component.html',
  styleUrls: ['./iot-digital-twin.component.css'],
})
export class IotDigitalTwinComponent {}
