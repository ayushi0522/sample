import { Component, ChangeDetectionStrategy, AfterViewInit, ElementRef, ViewChild, OnDestroy, input, effect, inject } from '@angular/core';
import { ThemeService, Theme } from '../../services/theme.service';

declare var Chart: any;

@Component({
  selector: 'app-line-chart',
  template: '<canvas #lineCanvas class="w-full h-80"></canvas>',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LineChartComponent implements AfterViewInit, OnDestroy {
  data = input<number[]>();
  labels = input<string[]>();
  
  @ViewChild('lineCanvas') lineCanvas!: ElementRef;
  chart: any;
  themeService = inject(ThemeService);
  private observer: MutationObserver | undefined;

  constructor() {
    effect(() => {
      const chartData = this.data();
      const chartLabels = this.labels();
      if (this.chart && chartData) {
        this.chart.data.datasets[0].data = chartData;
        if (chartLabels && chartLabels.length > 0) {
          this.chart.data.labels = chartLabels;
        }
        this.chart.update('none'); // 'none' for no animation, making it feel more real-time
      }
    });
  }

  ngAfterViewInit() {
    // We need to wait for the theme to be applied to the DOM
    this.observer = new MutationObserver((mutations) => {
        this.createChart();
        this.observer?.disconnect();
    });
    this.observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class']});
    
    // Fallback in case mutation observer doesn't fire
    setTimeout(() => {
        if (!this.chart) {
            this.createChart();
            this.observer?.disconnect();
        }
    }, 50);

    effect(() => {
        this.themeService.theme(); // Re-run when theme changes
        if (this.chart) {
            this.updateChartTheme();
        }
    });
  }
  
  ngOnDestroy() {
      this.chart?.destroy();
      this.observer?.disconnect();
  }

  private getCssVariable(variable: string): string {
    return getComputedStyle(document.documentElement).getPropertyValue(variable).trim();
  }

  private updateChartTheme(): void {
    const gridColor = this.getCssVariable('--border-primary');
    const ticksColor = this.getCssVariable('--text-tertiary');
    const pointBorderColor = this.getCssVariable('--bg-primary');
    
    if (this.chart.options.scales) {
        this.chart.options.scales.x.grid.color = gridColor;
        this.chart.options.scales.x.ticks.color = ticksColor;
        this.chart.options.scales.y.grid.color = gridColor;
        this.chart.options.scales.y.ticks.color = ticksColor;
    }

    if (this.chart.data.datasets[0]) {
        this.chart.data.datasets[0].pointBorderColor = pointBorderColor;
        this.chart.data.datasets[0].pointHoverBackgroundColor = pointBorderColor;
    }
    
    this.chart.update();
  }

  createChart() {
    if (this.chart) this.chart.destroy();
    if (!this.lineCanvas) return;

    const ctx = this.lineCanvas.nativeElement.getContext('2d');
    
    const accentColor = this.getCssVariable('--accent-primary');
    const gridColor = this.getCssVariable('--border-primary');
    const ticksColor = this.getCssVariable('--text-tertiary');
    const pointBorderColor = this.getCssVariable('--bg-primary');
    
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    // A bit of manual alpha conversion
    gradient.addColorStop(0, accentColor + '80'); // ~50% opacity
    gradient.addColorStop(1, accentColor + '00'); // 0% opacity

    this.chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'],
        datasets: [{
          label: 'Revenue',
          data: this.data() ?? [], // Use initial data if available
          fill: true,
          backgroundColor: gradient,
          borderColor: accentColor,
          tension: 0.4,
          pointBackgroundColor: accentColor,
          pointBorderColor: pointBorderColor,
          pointHoverBackgroundColor: pointBorderColor,
          pointHoverBorderColor: accentColor
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            x: { 
                grid: { color: gridColor },
                ticks: { color: ticksColor }
            },
            y: { 
                grid: { color: gridColor },
                ticks: { color: ticksColor }
            }
        },
        plugins: {
            legend: {
                display: false
            }
        }
      }
    });
  }
}