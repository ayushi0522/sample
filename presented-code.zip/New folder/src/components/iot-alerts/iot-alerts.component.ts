import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IotProductionService } from '../../services/iot-production.service';
import { Subject, interval } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

interface Alert {
  stationId: string;
  stationName: string;
  message: string;
  severity: 'info' | 'warning' | 'critical';
  timestamp: Date;
}

@Component({
  selector: 'app-iot-alerts',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './iot-alerts.component.html',
  styleUrls: ['./iot-alerts.component.css'],
})
export class IotAlertsComponent implements OnInit, OnDestroy {
  alerts: Alert[] = [];
  filteredAlerts: Alert[] = [];
  selectedFilter: 'all' | 'critical' | 'warning' | 'info' = 'all';
  private destroy$ = new Subject<void>();

  constructor(private iotService: IotProductionService) {}

  ngOnInit(): void {
    // Update alerts every 5 seconds
    interval(5000)
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        this.updateAlerts();
      });

    // Initial update
    this.updateAlerts();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  updateAlerts(): void {
    const newAlerts = this.iotService.getAlerts().map((alert) => ({
      ...alert,
      timestamp: new Date(),
    }));

    // Add new alerts to the top
    this.alerts = [...newAlerts, ...this.alerts].slice(0, 50); // Keep max 50 alerts
    this.applyFilter();
  }

  setFilter(filter: 'all' | 'critical' | 'warning' | 'info'): void {
    this.selectedFilter = filter;
    this.applyFilter();
  }

  applyFilter(): void {
    if (this.selectedFilter === 'all') {
      this.filteredAlerts = this.alerts;
    } else {
      this.filteredAlerts = this.alerts.filter(
        (alert) => alert.severity === this.selectedFilter
      );
    }
  }

  clearAlerts(): void {
    this.alerts = [];
    this.filteredAlerts = [];
  }

  getAlertIcon(severity: 'info' | 'warning' | 'critical'): string {
    switch (severity) {
      case 'critical':
        return '🔴';
      case 'warning':
        return '🟡';
      case 'info':
        return '🔵';
    }
  }

  getAlertCount(severity: 'all' | 'critical' | 'warning' | 'info'): number {
    if (severity === 'all') return this.alerts.length;
    return this.alerts.filter((alert) => alert.severity === severity).length;
  }

  getSeverityClass(severity: string): string {
    return `alert-${severity}`;
  }
}
