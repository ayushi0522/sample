import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent {
  private readonly router: Router = inject(Router);
  private authService = inject(AuthService);

  // UI State
  loginMethod = signal<'password' | 'otp'>('password');

  // Form Signals
  username = signal('demo@mediconnect.pro');
  password = signal('password');
  phone = signal('');
  otp = signal('');

  login(): void {
    if (this.authService.login(this.username(), this.password())) {
      this.router.navigate(['/dashboard']);
    } else {
      // Handle login failure, e.g., show an error message
      console.error('Login failed');
    }
  }
  
  loginWithOtp(): void {
    if(this.authService.loginWithOtp(this.phone(), this.otp())) {
        this.router.navigate(['/dashboard']);
    } else {
        console.error('OTP Login failed');
    }
  }

  loginWithGoogle(): void {
    this.authService.loginWithGoogle();
    this.router.navigate(['/dashboard']);
  }
}
