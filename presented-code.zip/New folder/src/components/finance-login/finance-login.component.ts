import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AlertService } from '../../services/alert.service';

@Component({
  selector: 'app-finance-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './finance-login.component.html',
    styleUrls: ['./finance-login.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FinanceLoginComponent {
  private readonly router: Router = inject(Router);
  private authService = inject(AuthService);
  private alertService = inject(AlertService);

  loginMethod = signal<'password' | 'otp'>('password');

  email = signal('analyst@veridian.bank');
  password = signal('password');
  phone = signal('');
  otp = signal('');

  login(): void {
    if (this.authService.loginDomainUser('Financial Analyst', this.email(), this.password())) {
      this.router.navigate(['/dashboard']);
    } else {
      this.alertService.showAlert('Invalid credentials.', 'error');
    }
  }

  loginWithOtp(): void {
    if (this.authService.loginWithOtp(this.phone(), this.otp())) {
      this.router.navigate(['/dashboard']);
    } else {
      this.alertService.showAlert('Invalid OTP.', 'error');
    }
  }
}
