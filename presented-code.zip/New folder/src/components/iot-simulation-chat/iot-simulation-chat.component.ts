import { Component, signal, effect, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { RecognitionService } from '../../services/recognition.service';

interface ChatMessage {
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  report?: SimulationReport;
}

interface SimulationReport {
  summary: {
    high_level_impact: string;
    meets_targets: {
      throughput_increase_20pct: boolean;
      waste_reduction_10pct: boolean;
    };
  };
  kpi_comparison: {
    [key: string]: {
      baseline: number;
      scenario: number;
      delta_abs: number;
      delta_pct: number;
    };
  };
  station_utilization: {
    [key: string]: {
      baseline: number;
      scenario: number;
      delta_pct: number;
      bottleneck: boolean;
    };
  };
  recommendations?: {
    short_term?: string[];
    medium_term?: string[];
  };
  assumptions_and_limits?: string[];
  bottlenecks?: {
    [key: string]: {
      severity: string;
      impact: string;
      recommendations: string[];
    };
  };
}

@Component({
  selector: 'app-iot-simulation-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './iot-simulation-chat.component.html',
  styleUrls: ['./iot-simulation-chat.component.css'],
})
export class IotSimulationChatComponent {
  messages = signal<ChatMessage[]>([]);
  userInput = signal('');
  isLoading = signal(false);
  error = signal<string | null>(null);
  selectedBottleneck = signal<{ station: string; details: any } | null>(null);

  private apiUrl = 'http://127.0.0.1:8000/simulate_scenario';
  recognitionService = inject(RecognitionService);

  constructor(private http: HttpClient) {
    // Effect to update user input from speech recognition
    effect(() => {
      const transcribedText = this.recognitionService.transcribedText();
      if (transcribedText) {
        this.userInput.set(transcribedText);
      }
    });
  }

  toggleListening(): void {
    if (this.recognitionService.isListening()) {
      this.recognitionService.stop();
    } else {
      this.recognitionService.start();
    }
  }

  async sendMessage() {
    const query = this.userInput().trim();
    if (!query || this.isLoading()) return;

    // Add user message
    this.messages.update(msgs => [
      ...msgs,
      {
        type: 'user',
        content: query,
        timestamp: new Date(),
      },
    ]);

    this.userInput.set('');
    this.isLoading.set(true);
    this.error.set(null);

    try {
      const response = await this.http
        .post<{ report: SimulationReport }>(this.apiUrl, { query })
        .toPromise();

      if (response && response.report) {
        // Add assistant message with report
        this.messages.update(msgs => [
          ...msgs,
          {
            type: 'assistant',
            content: this.formatReportSummary(response.report),
            timestamp: new Date(),
            report: response.report,
          },
        ]);
      }
    } catch (err: any) {
      this.error.set(err.message || 'Failed to get simulation results');
      this.messages.update(msgs => [
        ...msgs,
        {
          type: 'assistant',
          content: '❌ Failed to analyze simulation. Please try again.',
          timestamp: new Date(),
        },
      ]);
    } finally {
      this.isLoading.set(false);
    }
  }

  private formatReportSummary(report: SimulationReport): string {
    return `📊 Simulation Analysis:\n\n${report.summary.high_level_impact}`;
  }

  formatStationName(name: string): string {
    return name.replace(/_/g, ' ');
  }

  getTargetStatus(meets: boolean): string {
    return meets ? '✅ Met' : '❌ Not Met';
  }

  getKpiDeltaClass(delta: number): string {
    return delta >= 0 ? 'positive' : 'negative';
  }

  getUtilizationClass(delta: number): string {
    if (delta > 10) return 'high-increase';
    if (delta > 0) return 'slight-increase';
    if (delta < -10) return 'high-decrease';
    if (delta < 0) return 'slight-decrease';
    return 'no-change';
  }

  clearChat() {
    this.messages.set([]);
    this.error.set(null);
  }

  getStationArray(stationUtilization: { [key: string]: any }): Array<{ key: string; value: any }> {
    // Convert object to array and sort by bottleneck status and utilization
    return Object.entries(stationUtilization)
      .map(([key, value]) => ({ key, value }))
      .sort((a, b) => {
        // Bottlenecks first
        if (a.value.bottleneck && !b.value.bottleneck) return -1;
        if (!a.value.bottleneck && b.value.bottleneck) return 1;
        // Then by utilization descending
        return b.value.scenario - a.value.scenario;
      });
  }

  openBottleneckDetails(station: string, report: SimulationReport) {
    if (report.bottlenecks && report.bottlenecks[station]) {
      this.selectedBottleneck.set({
        station: station,
        details: report.bottlenecks[station]
      });
    }
  }

  closeBottleneckPopup() {
    this.selectedBottleneck.set(null);
  }
}
