import { Component, ChangeDetectionStrategy, inject, signal, viewChild, ElementRef, effect, untracked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FileUploadComponent } from '../file-upload/file-upload.component';
import { GeminiService, ChatMessage } from '../../services/gemini.service';

@Component({
  selector: 'app-queries',
  standalone: true,
  imports: [CommonModule, FormsModule, FileUploadComponent],
  templateUrl: './queries.component.html',
  styleUrls: ['./queries.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class QueriesComponent {
  geminiService = inject(GeminiService);

  userInput = signal('');
  uploadedFiles = signal<File[]>([]);
  messages = signal<ChatMessage[]>([
    { role: 'model', parts: 'Hello! Upload a document and I can help you analyze it.' }
  ]);
  
  chatContainer = viewChild<ElementRef>('chatContainer');

  constructor() {
    effect(() => {
        if(this.messages() && this.chatContainer()) {
            untracked(() => {
                setTimeout(() => this.scrollToBottom(), 0);
            });
        }
    });
  }

  onFileUploaded(file: File): void {
    this.uploadedFiles.update(files => [...files, file]);
  }

  removeFile(fileToRemove: File): void {
    this.uploadedFiles.update(files => files.filter(file => file !== fileToRemove));
  }

  async sendMessage() {
    let userMessage = this.userInput().trim();
    if (!userMessage || this.geminiService.thinking()) return;

    // Prepend context from uploaded files
    if (this.uploadedFiles().length > 0) {
      const fileNames = this.uploadedFiles().map(f => f.name).join(', ');
      userMessage = `Based on the context from the following file(s): ${fileNames}, please answer the following question: ${userMessage}`;
    }

    this.messages.update(msgs => [...msgs, { role: 'user', parts: this.userInput().trim() }]); // Show original message in UI
    this.userInput.set('');
    
    this.messages.update(msgs => [...msgs, { role: 'model', parts: '' }]);

    const stream = this.geminiService.sendMessage(userMessage);
    for await (const chunk of stream) {
        this.messages.update(msgs => {
            const lastMessage = msgs[msgs.length - 1];
            if (lastMessage && lastMessage.role === 'model') {
              lastMessage.parts += chunk;
            }
            return [...msgs];
        });
    }
  }
  
  private scrollToBottom(): void {
    try {
      if (this.chatContainer()) {
        const element = this.chatContainer()!.nativeElement;
        element.scrollTop = element.scrollHeight;
      }
    } catch (err) {
      console.error('Could not scroll to bottom:', err);
    }
  }
}
