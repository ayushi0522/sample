import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';

interface MenuItem {
  name: string;
  icon: string;
  route: string;
}

@Component({
  selector: 'app-iot-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './iot-sidebar.component.html',
  styleUrls: ['./iot-sidebar.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class IotSidebarComponent {  isExpanded = signal(true);
  menuItems: MenuItem[] = [
    { name: 'Dashboard', icon: '📊', route: 'dashboard' },
    { name: 'Sensor Streams', icon: '📡', route: 'sensor-streams' },
    { name: 'AI Analytics', icon: '🤖', route: 'ai-analytics' },
    { name: 'Machine Status', icon: '🔧', route: 'machine-status' },
    { name: 'Alerts', icon: '⚠️', route: 'alerts' },
    // { name: 'Analytics', icon: '📈', route: 'analytics' }, // Hidden
    { name: 'Simulator', icon: '🎯', route: 'simulator' },
  ];

  toggleSidebar() {
    this.isExpanded.update(value => !value);
  }
}
