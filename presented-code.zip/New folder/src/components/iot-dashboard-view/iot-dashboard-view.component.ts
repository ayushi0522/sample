import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IotProductionService, ProductionLineSnapshot } from '../../services/iot-production.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-iot-dashboard-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './iot-dashboard-view.component.html',
  styleUrls: ['./iot-dashboard-view.component.css'],
})
export class IotDashboardViewComponent implements OnInit, OnDestroy {
  productionLineData: ProductionLineSnapshot | null = null;
  private destroy$ = new Subject<void>();

  constructor(private iotService: IotProductionService) {}

  ngOnInit(): void {
    this.iotService
      .getProductionLine()
      .pipe(takeUntil(this.destroy$))
      .subscribe((data) => {
        this.productionLineData = data;
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  getStatusColor(efficiency: number): string {
    if (efficiency >= 90) return '#10b981';
    if (efficiency >= 75) return '#f59e0b';
    return '#ef4444';
  }
}
