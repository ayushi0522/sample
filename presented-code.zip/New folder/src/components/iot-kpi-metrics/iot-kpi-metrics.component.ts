import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IotProductionService,
  ProductionLineSnapshot,
} from '../../services/iot-production.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-iot-kpi-metrics',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './iot-kpi-metrics.component.html',
  styleUrls: ['./iot-kpi-metrics.component.css'],
})
export class IotKpiMetricsComponent implements OnInit, OnDestroy {
  productionData: ProductionLineSnapshot | null = null;
  private destroy$ = new Subject<void>();

  constructor(private iotService: IotProductionService) {}

  ngOnInit(): void {
    this.iotService
      .getProductionLine()
      .pipe(takeUntil(this.destroy$))
      .subscribe((data) => {
        this.productionData = data;
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  getTopPerformers(): Array<{ name: string; efficiency: number; icon: string }> {
    if (!this.productionData) return [];
    return this.productionData.stations
      .map((s) => ({
        name: s.name,
        efficiency: s.efficiency,
        icon: s.efficiency >= 90 ? '⭐' : s.efficiency >= 75 ? '📊' : '⚠️',
      }))
      .sort((a, b) => b.efficiency - a.efficiency)
      .slice(0, 3);
  }

  getBottlenecks(): Array<{ name: string; issue: string; severity: string }> {
    if (!this.productionData) return [];
    const issues: Array<{ name: string; issue: string; severity: string }> = [];

    this.productionData.stations.forEach((station) => {
      if (station.downtime > 10) {
        issues.push({
          name: station.name,
          issue: `High downtime: ${station.downtime.toFixed(1)}m`,
          severity: 'critical',
        });
      }
      if (station.efficiency < 75) {
        issues.push({
          name: station.name,
          issue: `Low efficiency: ${station.efficiency.toFixed(0)}%`,
          severity: 'warning',
        });
      }
      if (station.queue > 20) {
        issues.push({
          name: station.name,
          issue: `Queue buildup: ${station.queue.toFixed(0)} units`,
          severity: 'warning',
        });
      }
    });

    return issues.slice(0, 5);
  }

  getTotalDefects(): number {
    if (!this.productionData) return 0;
    const totalCompleted = this.productionData.totalCompleted;
    const avgDefectRate =
      this.productionData.stations.reduce((sum, s) => sum + s.defectRate, 0) /
      this.productionData.stations.length;
    return Math.round((totalCompleted * avgDefectRate) / 100);
  }

  getAvgDowntime(): number {
    if (!this.productionData) return 0;
    return (
      this.productionData.stations.reduce((sum, s) => sum + s.downtime, 0) /
      this.productionData.stations.length
    );
  }

  getColorByValue(value: number, threshold: number): string {
    if (value >= threshold * 0.9) return '#ef4444';
    if (value >= threshold * 0.7) return '#f59e0b';
    return '#10b981';
  }
}
