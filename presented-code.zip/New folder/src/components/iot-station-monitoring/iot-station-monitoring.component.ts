import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IotProductionService,
  StationData,
} from '../../services/iot-production.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-iot-station-monitoring',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './iot-station-monitoring.component.html',
  styleUrls: ['./iot-station-monitoring.component.css'],
})
export class StationMonitoringComponent implements OnInit, OnDestroy {
  stations: StationData[] = [];
  selectedStation: StationData | null = null;
  private destroy$ = new Subject<void>();

  constructor(private iotService: IotProductionService) {}

  ngOnInit(): void {
    this.iotService
      .getProductionLine()
      .pipe(takeUntil(this.destroy$))
      .subscribe((data) => {
        this.stations = data.stations;
        if (this.selectedStation) {
          const updated = data.stations.find(
            (s) => s.id === this.selectedStation!.id
          );
          if (updated) {
            this.selectedStation = updated;
          }
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  selectStation(station: StationData): void {
    this.selectedStation = station;
  }

  getStatusIcon(status: 'normal' | 'warning' | 'critical'): string {
    switch (status) {
      case 'critical':
        return '🔴';
      case 'warning':
        return '🟡';
      case 'normal':
        return '🟢';
    }
  }

  getEfficiencyColor(efficiency: number): string {
    if (efficiency >= 90) return '#10b981';
    if (efficiency >= 75) return '#f59e0b';
    return '#ef4444';
  }

  getEfficiencyGradient(efficiency: number): string {
    if (efficiency >= 90) return 'linear-gradient(90deg, #10b981, #059669)';
    if (efficiency >= 75) return 'linear-gradient(90deg, #f59e0b, #d97706)';
    return 'linear-gradient(90deg, #ef4444, #dc2626)';
  }

  triggerDowntime(stationId: string): void {
    this.iotService.triggerDowntimeEvent(stationId);
  }
}
