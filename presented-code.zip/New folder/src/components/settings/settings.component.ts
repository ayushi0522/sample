import { Component, ChangeDetectionStrategy, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AlertService } from '../../services/alert.service';

interface Country {
  name: string;
  code: string;
  dial_code: string;
  flag: string;
}

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SettingsComponent {
  private alertService = inject(AlertService);

  // Form Signals
  fullName = signal('Jane Doe');
  email = signal('jane.doe@healthsys.pro');
  mobile = signal('555-123-4567');
  address = signal('123 Health St, Medville, USA');
  countryCode = signal('+1');
  
  isCountryDropdownOpen = signal(false);

  countries: Country[] = [
    { name: 'United States', code: 'US', dial_code: '+1', flag: '🇺🇸' },
    { name: 'United Kingdom', code: 'GB', dial_code: '+44', flag: '🇬🇧' },
    { name: 'Canada', code: 'CA', dial_code: '+1', flag: '🇨🇦' },
    { name: 'Australia', code: 'AU', dial_code: '+61', flag: '🇦🇺' },
    { name: 'Germany', code: 'DE', dial_code: '+49', flag: '🇩🇪' },
    { name: 'India', code: 'IN', dial_code: '+91', flag: '🇮🇳' },
  ];
  
  selectedCountry = computed(() => this.countries.find(c => c.dial_code === this.countryCode() && c.name.includes('States')));


  saveSettings(): void {
    // Simulate API call
    console.log('Saving settings:', {
      fullName: this.fullName(),
      email: this.email(),
      mobile: `${this.countryCode()} ${this.mobile()}`,
      address: this.address()
    });
    this.alertService.showAlert('Settings updated successfully!', 'success');
  }
  
  selectCountry(country: Country): void {
    this.countryCode.set(country.dial_code);
    this.isCountryDropdownOpen.set(false);
  }
}
