import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IotProductionService, ProductionLineSnapshot } from '../../services/iot-production.service';
import { Subscription } from 'rxjs';
import { LineChartComponent } from '../charts/line-chart.component';

interface SensorDataPoint {
  timestamp: Date;
  value: number;
  station: string;
}

@Component({
  selector: 'app-iot-sensor-streams',
  standalone: true,
  imports: [CommonModule, LineChartComponent],
  templateUrl: './iot-sensor-streams.component.html',
  styleUrls: ['./iot-sensor-streams.component.css'],
})
export class IotSensorStreamsComponent implements OnInit, OnDestroy {
  activeTab: 'temperature' | 'vibration' | 'energy' | 'combined' = 'temperature';
  
  // Data buffers for each sensor type (last 20 readings)
  temperatureData: number[] = [];
  vibrationData: number[] = [];
  energyData: number[] = [];
  combinedData: number[] = [];
  
  // Time labels for charts (HH:MM:SS format)
  timeLabels: string[] = [];
  
  // Detailed data for display
  temperatureStations: { name: string; value: number; unit: string; status: string }[] = [];
  vibrationStations: { name: string; value: number; unit: string; status: string }[] = [];
  energyStations: { name: string; value: number; unit: string; status: string }[] = [];
  
  // Stats
  avgTemperature = 0;
  maxTemperature = 0;
  avgVibration = 0;
  maxVibration = 0;
  avgEnergy = 0;
  totalEnergy = 0;
  
  private subscription: Subscription = new Subscription();
  
  constructor(private iotService: IotProductionService) {}
  
  ngOnInit(): void {
    this.subscription.add(
      this.iotService.getProductionLine().subscribe((data) => {
        this.updateSensorData(data);
      })
    );
  }
  
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
  
  selectTab(tab: 'temperature' | 'vibration' | 'energy' | 'combined'): void {
    this.activeTab = tab;
  }
    private updateSensorData(snapshot: ProductionLineSnapshot): void {
    // Generate time label for current reading (HH:MM:SS format)
    const now = new Date();
    const timeLabel = now.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit',
      hour12: false 
    });
    
    // Update time labels
    this.timeLabels.push(timeLabel);
    if (this.timeLabels.length > 20) {
      this.timeLabels.shift();
    }
    
    // Extract sensor data from all stations
    const tempSensors = snapshot.stations
      .map(s => s.sensors.find(sensor => sensor.name === 'Temperature'))
      .filter(s => s !== undefined);
    
    const vibrSensors = snapshot.stations
      .map(s => s.sensors.find(sensor => sensor.name === 'Vibration'))
      .filter(s => s !== undefined);
    
    const energySensors = snapshot.stations
      .map(s => s.sensors.filter(sensor => sensor.name === 'Power Consumption'))
      .flat();
    
    // Update temperature data
    if (tempSensors.length > 0) {
      const avgTemp = tempSensors.reduce((sum, s) => sum + (s?.value || 0), 0) / tempSensors.length;
      this.temperatureData.push(avgTemp);
      if (this.temperatureData.length > 20) {
        this.temperatureData.shift();
      }
      
      this.temperatureStations = snapshot.stations
        .map(station => {
          const sensor = station.sensors.find(s => s.name === 'Temperature');
          return sensor ? {
            name: station.name,
            value: sensor.value,
            unit: sensor.unit,
            status: sensor.status
          } : null;
        })
        .filter(s => s !== null) as any[];
      
      this.avgTemperature = avgTemp;
      this.maxTemperature = Math.max(...tempSensors.map(s => s?.value || 0));
    }
    
    // Update vibration data
    if (vibrSensors.length > 0) {
      const avgVibr = vibrSensors.reduce((sum, s) => sum + (s?.value || 0), 0) / vibrSensors.length;
      this.vibrationData.push(avgVibr);
      if (this.vibrationData.length > 20) {
        this.vibrationData.shift();
      }
      
      this.vibrationStations = snapshot.stations
        .map(station => {
          const sensor = station.sensors.find(s => s.name === 'Vibration');
          return sensor ? {
            name: station.name,
            value: sensor.value,
            unit: sensor.unit,
            status: sensor.status
          } : null;
        })
        .filter(s => s !== null) as any[];
      
      this.avgVibration = avgVibr;
      this.maxVibration = Math.max(...vibrSensors.map(s => s?.value || 0));
    }
    
    // Update energy data
    if (energySensors.length > 0) {
      const avgEnergy = energySensors.reduce((sum, s) => sum + (s?.value || 0), 0) / energySensors.length;
      this.energyData.push(avgEnergy);
      if (this.energyData.length > 20) {
        this.energyData.shift();
      }
      
      this.energyStations = snapshot.stations
        .map(station => {
          const sensor = station.sensors.find(s => s.name === 'Power Consumption');
          return sensor ? {
            name: station.name,
            value: sensor.value,
            unit: sensor.unit,
            status: sensor.status
          } : null;
        })
        .filter(s => s !== null) as any[];
      
      this.avgEnergy = avgEnergy;
      this.totalEnergy = energySensors.reduce((sum, s) => sum + (s?.value || 0), 0);
    }
    
    // Update combined data (normalized average of all sensor types)
    const normalizedTemp = this.avgTemperature / 100; // Normalize to 0-1 range
    const normalizedVibr = this.avgVibration * 10; // Scale up vibration
    const normalizedEnergy = this.avgEnergy / 20; // Normalize energy
    
    const combinedValue = (normalizedTemp + normalizedVibr + normalizedEnergy) / 3;
    this.combinedData.push(combinedValue);
    if (this.combinedData.length > 20) {
      this.combinedData.shift();
    }
  }
  
  getStatusColor(status: string): string {
    switch (status) {
      case 'critical':
        return '#ef4444';
      case 'warning':
        return '#f59e0b';
      case 'normal':
        return '#10b981';
      default:
        return '#6b7280';
    }
  }
}
