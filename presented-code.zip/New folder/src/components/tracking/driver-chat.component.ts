import { Component, ChangeDetectionStrategy, signal, output, viewChild, ElementRef, effect, untracked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface ChatMessage {
    sender: 'user' | 'driver';
    text: string;
    timestamp: string;
}

@Component({
  selector: 'app-driver-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './driver-chat.component.html',
  styleUrls: ['./driver-chat.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DriverChatComponent {
  closeChat = output<void>();

  userInput = signal('');
  messages = signal<ChatMessage[]>([
    { sender: 'driver', text: 'Hi there! I\'m on my way, about 30 minutes out. Traffic is clear.', timestamp: this.getTime(-2) },
  ]);
  
  chatContainer = viewChild<ElementRef>('chatContainer');

  constructor() {
    effect(() => {
        if(this.messages() && this.chatContainer()) {
            untracked(() => {
                setTimeout(() => this.scrollToBottom(), 0);
            });
        }
    });
  }

  sendMessage(): void {
    const messageText = this.userInput().trim();
    if (!messageText) return;

    this.messages.update(msgs => [...msgs, { sender: 'user', text: messageText, timestamp: this.getTime(0) }]);
    this.userInput.set('');

    // Simulate driver response
    setTimeout(() => {
      this.messages.update(msgs => [...msgs, { sender: 'driver', text: 'Copy that, I\'ll keep you posted if anything changes.', timestamp: this.getTime(0) }]);
    }, 1500);
  }

  private getTime(minuteOffset: number): string {
    const date = new Date();
    date.setMinutes(date.getMinutes() + minuteOffset);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  private scrollToBottom(): void {
    try {
      if (this.chatContainer()) {
        const element = this.chatContainer()!.nativeElement;
        element.scrollTop = element.scrollHeight;
      }
    } catch (err) {
      console.error('Could not scroll to bottom:', err);
    }
  }
}
