import { Injectable, signal, NgZone } from '@angular/core';

// Extend the Window interface to include SpeechRecognition properties
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

@Injectable({
  providedIn: 'root',
})
export class RecognitionService {
  private recognition: any | null = null;
  
  isListening = signal(false);
  transcribedText = signal('');
  error = signal<string | null>(null);

  constructor(private ngZone: NgZone) {
    this.initialize();
  }

  private initialize(): void {
    try {
      // FIX: Check for both standard and webkit-prefixed SpeechRecognition API.
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = false;
        this.recognition.lang = 'en-US';
        this.recognition.interimResults = false;
        this.recognition.maxAlternatives = 1;

        this.recognition.onstart = () => {
          this.ngZone.run(() => this.isListening.set(true));
        };

        this.recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          this.ngZone.run(() => this.transcribedText.set(transcript));
        };

        this.recognition.onerror = (event: any) => {
          this.ngZone.run(() => {
            this.error.set(event.error);
            this.isListening.set(false);
          });
        };

        this.recognition.onend = () => {
          this.ngZone.run(() => this.isListening.set(false));
        };
      } else {
        this.error.set('Speech recognition not supported in this browser.');
      }
    } catch (e) {
      console.error('Speech Recognition Error:', e);
      this.error.set('Could not initialize speech recognition.');
    }
  }

  start(): void {
    if (this.recognition && !this.isListening()) {
      this.transcribedText.set('');
      this.error.set(null);
      this.recognition.start();
    }
  }

  stop(): void {
    if (this.recognition && this.isListening()) {
      this.recognition.stop();
    }
  }
}
