import { Injectable, signal, PLATFORM_ID, inject, computed } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router } from '@angular/router';

export type UserRole = 
  | 'Admin' 
  | 'Manager' 
  | 'User'
  | 'Plant Supervisor'
  | 'Financial Analyst'
  | 'Lab Researcher'
  | 'Data Engineer';

export interface User {
  name: string;
  email: string;
  role: UserRole;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private platformId = inject(PLATFORM_ID);
  private router: Router = inject(Router);
  
  currentUser = signal<User | null>(null);
  
  isAuthenticated = computed(() => this.currentUser() !== null);

  constructor() {
    if (isPlatformBrowser(this.platformId)) {
      const storedUser = localStorage.getItem('currentUser');
      if (storedUser) {
        this.currentUser.set(JSON.parse(storedUser));
      }
    }
  }

  login(email: string, password: string): boolean {
    // Simulate API call and getting a user object
    // In a real app, you would validate credentials here.
    if (email.toLowerCase() === 'demo@mediconnect.pro' && password === 'password') {
        const mockUser: User = {
          name: 'Ayushi',
          email: email,
          role: 'Admin', // Hardcode role for demo purposes
        };
        this.setUser(mockUser);
        return true;
    }
    return false;
  }

  loginTravelUser(email: string, password: string): boolean {
    if (email.toLowerCase() === 'traveler@example.com' && password === 'password') {
        const mockUser: User = {
          name: 'Alex Ryder',
          email: email,
          role: 'User', // Travel user is a standard user
        };
        this.setUser(mockUser);
        return true;
    }
    return false;
  }

  loginDomainUser(role: UserRole, email: string, password: string): boolean {
    // In a real app, you'd have different validation logic. Here we just log in.
    const userMap = {
      'Plant Supervisor': { name: 'Ayushi Jain' },
      'Financial Analyst': { name: 'Eleonor Vance' },
      'Lab Researcher': { name: 'Kenji Tanaka' },
      'Data Engineer': { name: 'Maya Singh' },
      'Admin': { name: 'Admin User' },
      'Manager': { name: 'Manager User' },
      'User': { name: 'Standard User' },
    }
    
    const mockUser: User = {
      name: userMap[role].name,
      email: email,
      role: role,
    };
    this.setUser(mockUser);
    return true;
  }

  loginWithGoogle(): void {
    const mockUser: User = {
      name: 'Jane Doe',
      email: 'jane.doe@google.com',
      role: 'Manager',
    };
    this.setUser(mockUser);
  }

  loginWithOtp(phone: string, otp: string): boolean {
    // Simulate API call and getting a token for OTP login
     const mockUser: User = {
      name: 'John Smith',
      email: 'john.smith@health.pro',
      role: 'User',
    };
    this.setUser(mockUser);
    return true;
  }

  logout(): void {
    this.clearUser();
    this.router.navigate(['/login']);
  }

  private setUser(user: User): void {
    this.currentUser.set(user);
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('currentUser', JSON.stringify(user));
    }
  }

  private clearUser(): void {
    this.currentUser.set(null);
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('currentUser');
    }
  }
}
