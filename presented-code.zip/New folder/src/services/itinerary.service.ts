import { Injectable, inject, signal, computed } from '@angular/core';
import { GeminiService } from './gemini.service';
import { Type } from '@google/genai';

export interface ItineraryRequest {
  destination: string;
  startDate: string;
  endDate: string;
  interests: string;
  budget: 'budget' | 'mid-range' | 'luxury';
}

interface Status {
  message: string;
  state: 'pending' | 'done';
}

@Injectable({
  providedIn: 'root',
})
export class ItineraryService {
  private geminiService = inject(GeminiService);
  
  statusHistory = signal<Status[]>([]);
  isLoading = computed(() => this.statusHistory().length > 0 && this.statusHistory().some(s => s.state === 'pending'));

  private updateStatus(message: string) {
    // Mark previous as done
    this.statusHistory.update(history => 
        history.map(s => ({ ...s, state: 'done' }))
    );
    // Add new pending status
    this.statusHistory.update(history => [...history, { message, state: 'pending' }]);
  }

  resetStatus(): void {
    this.statusHistory.set([]);
  }

  async generateItinerary(request: ItineraryRequest): Promise<any> {
    this.statusHistory.set([{ message: 'Analyzing your request...', state: 'pending' }]);

    // 1. Simulate fetching real-time data
    await new Promise(res => setTimeout(res, 1000));
    this.updateStatus('Finding best flights...');
    const flights = this.getMockFlights(request.destination);
    
    await new Promise(res => setTimeout(res, 1500));
    this.updateStatus('Searching for hotels...');
    const hotels = this.getMockHotels(request.destination, request.budget);

    await new Promise(res => setTimeout(res, 1500));
    this.updateStatus('Discovering local events...');
    const events = this.getMockEvents(request.destination);

    await new Promise(res => setTimeout(res, 1200));
    this.updateStatus('Finding transport options...');
    const transport = this.getMockTransportationOptions(request.destination);
    
    this.updateStatus('Generating itinerary with AI...');
    await new Promise(res => setTimeout(res, 1000));

    // 2. Construct the prompt for Gemini
    const prompt = this.constructPrompt(request, flights, hotels, events, transport);
    const schema = this.getItinerarySchema();

    try {
        const itinerary = await this.geminiService.generateJsonContent(prompt, schema);
        this.updateStatus('Your trip is ready!');
        await new Promise(res => setTimeout(res, 500)); // Short delay to show final message
        this.statusHistory.update(history => history.map(s => ({ ...s, state: 'done' })));
        return itinerary;
    } catch(e) {
        this.resetStatus();
        throw e;
    }
  }

  private constructPrompt(req: ItineraryRequest, flights: any, hotels: any, events: any, transport: any): string {
    return `
      You are an expert travel agent. Create a detailed, day-by-day travel itinerary based on the following information.

      **User Request:**
      - Destination: ${req.destination}
      - Dates: ${req.startDate} to ${req.endDate}
      - Interests: ${req.interests}
      - Budget: ${req.budget}

      **Available Real-Time Data:**
      - **Flights:** ${JSON.stringify(flights)}
      - **Hotels:** ${JSON.stringify(hotels)}
      - **Local Events:** ${JSON.stringify(events)}
      - **Transportation:** ${JSON.stringify(transport)}

      **Instructions:**
      1. Create a catchy title and a brief, exciting description for the trip.
      2. The first day should include the flight arrival and hotel check-in.
      3. The last day should include hotel check-out and the departure flight.
      4. Fill the days in between with activities based on the user's interests. Incorporate the available local events if they fit the theme.
      5. Suggest specific restaurants for lunch and dinner that match the user's budget.
      6. For each activity, provide a time, a type (e.g., "Flight", "Hotel", "Food", "Museum", "Tour"), a description, and optional details.
      7. **Crucially**, where travel is needed between locations, specify the recommended mode of transport (e.g., 'Uber', 'Metro'), an estimated cost, and the travel time. Populate the 'transportation' object for these activities.
      8. Be creative and make the itinerary sound appealing and logical.
    `;
  }
  
  private getItinerarySchema() {
      const activitySchema = {
        type: Type.OBJECT,
        properties: {
            time: { type: Type.STRING, description: "The time of the activity (e.g., '9:00 AM')." },
            type: { type: Type.STRING, description: "A category for the activity (e.g., 'Flight', 'Food', 'Museum')." },
            description: { type: Type.STRING, description: "A brief description of the activity." },
            details: { type: Type.STRING, description: "Optional extra details like an address or booking info." },
            transportation: {
              type: Type.OBJECT,
              description: "Recommended transport to get to this activity's location. Omit if not applicable (e.g., breakfast at hotel).",
              properties: {
                mode: { type: Type.STRING, description: "Mode of transport (e.g., 'Uber', 'Taxi', 'Metro', 'Walk')." },
                estimatedCost: { type: Type.STRING, description: "An estimated cost for the transport (e.g., '$15-20')." },
                estimatedTime: { type: Type.STRING, description: "An estimated travel time (e.g., '20 minutes')." }
              }
            }
        }
      };

      const dailyPlanSchema = {
          type: Type.OBJECT,
          properties: {
              day: { type: Type.INTEGER, description: "The day number (e.g., 1)." },
              title: { type: Type.STRING, description: "A title for the day (e.g., 'Day 1: Arrival and Parisian Charm')." },
              activities: { type: Type.ARRAY, items: activitySchema }
          }
      };
      
      return {
        type: Type.OBJECT,
        properties: {
            tripTitle: { type: Type.STRING },
            tripDescription: { type: Type.STRING },
            dailyPlan: { type: Type.ARRAY, items: dailyPlanSchema }
        }
      };
  }

  // MOCK DATA FUNCTIONS
  private getMockFlights(destination: string): object {
    return {
      arrival: { flight: "UA456", time: "9:30 AM", airport: "CDG" },
      departure: { flight: "UA457", time: "6:00 PM", airport: "CDG" },
    };
  }

  private getMockHotels(destination: string, budget: string): object[] {
    const allHotels = [
      { name: "The Ritz Paris", tier: "luxury", price: "$1500/night" },
      { name: "Hôtel Le Meurice", tier: "luxury", price: "$1200/night" },
      { name: "Hôtel Adèle & Jules", tier: "mid-range", price: "$350/night" },
      { name: "Le Citizen Hotel", tier: "mid-range", price: "$300/night" },
      { name: "Generator Paris", tier: "budget", price: "$100/night" },
      { name: "MIJE Marais", tier: "budget", price: "$80/night" },
    ];
    return allHotels.filter(h => h.tier === budget);
  }

  private getMockEvents(destination: string): object[] {
    return [
      { name: "Jazz Night at Le Duc des Lombards", type: "Music" },
      { name: "Exhibition: 'Picasso and Antiquity'", type: "Art" },
      { name: "Montmartre Street Art Tour", type: "Tour" },
    ];
  }

  private getMockTransportationOptions(destination: string): object {
    return {
        rideSharing: ["Uber", "Bolt"],
        publicTransit: ["Metro", "Bus"],
        taxiAvailable: true
    };
  }
}