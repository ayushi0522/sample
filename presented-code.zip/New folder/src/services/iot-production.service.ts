import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, interval } from 'rxjs';
import { map } from 'rxjs/operators';

export interface Sensor {
  id: string;
  name: string;
  value: number;
  unit: string;
  threshold: number;
  status: 'normal' | 'warning' | 'critical';
}

export interface StationData {
  id: string;
  name: string;
  cycleTime: number; // in seconds
  downtime: number; // in minutes
  defectRate: number; // percentage
  sensors: Sensor[];
  completed: number; // units completed
  queue: number; // units waiting
  efficiency: number; // percentage
  operatorName: string;
  shiftStart: Date;
  shiftEnd: Date;
}

export interface ProductionLineSnapshot {
  timestamp: Date;
  stations: StationData[];
  totalCompleted: number;
  totalQueued: number;
  lineEfficiency: number;
  estimatedTimeToCompletion: number; // in minutes
}

export interface SimulationResult {
  hour: number;
  expectedCompletion: number;
  expectedQueue: number;
  expectedDowntime: number;
  bottleneckStation: string;
  recommendation: string;
}

@Injectable({
  providedIn: 'root',
})
export class IotProductionService {
  private productionLineData = new BehaviorSubject<ProductionLineSnapshot>(
    this.initializeProductionLine()
  );

  private simulationResults = new BehaviorSubject<SimulationResult[]>([]);
  private stationHistory = new BehaviorSubject<StationData[][]>([]);

  constructor() {
    this.startRealTimeSimulation();
  }

  private initializeProductionLine(): ProductionLineSnapshot {
    const stations: StationData[] = [
      {
        id: 'sheet-metal',
        name: 'Sheet Metal Processing',
        cycleTime: 45,
        downtime: 0,
        defectRate: 2.5,
        sensors: [
          {
            id: 'temp-sm-1',
            name: 'Temperature',
            value: 68,
            unit: '°C',
            threshold: 85,
            status: 'normal',
          },
          {
            id: 'vibr-sm-1',
            name: 'Vibration',
            value: 2.1,
            unit: 'mm/s',
            threshold: 5,
            status: 'normal',
          },
          {
            id: 'energy-sm-1',
            name: 'Power Consumption',
            value: 15.2,
            unit: 'kW',
            threshold: 20,
            status: 'normal',
          },
        ],
        completed: 124,
        queue: 3,
        efficiency: 96,
        operatorName: 'John Smith',
        shiftStart: new Date(new Date().setHours(6, 0, 0)),
        shiftEnd: new Date(new Date().setHours(14, 0, 0)),
      },
      {
        id: 'drum-tub',
        name: 'Drum & Tub Assembly',
        cycleTime: 55,
        downtime: 5,
        defectRate: 1.8,
        sensors: [
          {
            id: 'temp-dt-1',
            name: 'Temperature',
            value: 62,
            unit: '°C',
            threshold: 75,
            status: 'normal',
          },
          {
            id: 'press-dt-1',
            name: 'Hydraulic Pressure',
            value: 180,
            unit: 'bar',
            threshold: 250,
            status: 'normal',
          },
          {
            id: 'energy-dt-1',
            name: 'Power Consumption',
            value: 12.8,
            unit: 'kW',
            threshold: 18,
            status: 'normal',
          },
        ],
        completed: 118,
        queue: 8,
        efficiency: 92,
        operatorName: 'Maria Garcia',
        shiftStart: new Date(new Date().setHours(6, 0, 0)),
        shiftEnd: new Date(new Date().setHours(14, 0, 0)),
      },
      {
        id: 'motor-asm',
        name: 'Motor Assembly',
        cycleTime: 50,
        downtime: 0,
        defectRate: 3.2,
        sensors: [
          {
            id: 'temp-ma-1',
            name: 'Temperature',
            value: 75,
            unit: '°C',
            threshold: 90,
            status: 'normal',
          },
          {
            id: 'rpm-ma-1',
            name: 'Motor Speed',
            value: 1485,
            unit: 'RPM',
            threshold: 1800,
            status: 'normal',
          },
          {
            id: 'energy-ma-1',
            name: 'Power Consumption',
            value: 18.5,
            unit: 'kW',
            threshold: 25,
            status: 'normal',
          },
        ],
        completed: 112,
        queue: 14,
        efficiency: 88,
        operatorName: 'Ahmed Hassan',
        shiftStart: new Date(new Date().setHours(6, 0, 0)),
        shiftEnd: new Date(new Date().setHours(14, 0, 0)),
      },
      {
        id: 'wiring',
        name: 'Wiring & Connections',
        cycleTime: 40,
        downtime: 12,
        defectRate: 2.1,
        sensors: [
          {
            id: 'temp-wire-1',
            name: 'Temperature',
            value: 58,
            unit: '°C',
            threshold: 70,
            status: 'normal',
          },
          {
            id: 'continuity-wire-1',
            name: 'Signal Integrity',
            value: 98.5,
            unit: '%',
            threshold: 95,
            status: 'normal',
          },
          {
            id: 'energy-wire-1',
            name: 'Power Consumption',
            value: 2.1,
            unit: 'kW',
            threshold: 5,
            status: 'normal',
          },
        ],
        completed: 105,
        queue: 20,
        efficiency: 82,
        operatorName: 'Lisa Chen',
        shiftStart: new Date(new Date().setHours(6, 0, 0)),
        shiftEnd: new Date(new Date().setHours(14, 0, 0)),
      },
      {
        id: 'final-asm',
        name: 'Final Assembly',
        cycleTime: 60,
        downtime: 3,
        defectRate: 1.5,
        sensors: [
          {
            id: 'temp-final-1',
            name: 'Temperature',
            value: 65,
            unit: '°C',
            threshold: 80,
            status: 'normal',
          },
          {
            id: 'vibr-final-1',
            name: 'Vibration',
            value: 1.8,
            unit: 'mm/s',
            threshold: 4,
            status: 'normal',
          },
          {
            id: 'energy-final-1',
            name: 'Power Consumption',
            value: 22.3,
            unit: 'kW',
            threshold: 30,
            status: 'normal',
          },
        ],
        completed: 101,
        queue: 25,
        efficiency: 78,
        operatorName: 'Robert Wilson',
        shiftStart: new Date(new Date().setHours(6, 0, 0)),
        shiftEnd: new Date(new Date().setHours(14, 0, 0)),
      },
      {
        id: 'testing',
        name: 'Quality Testing',
        cycleTime: 70,
        downtime: 8,
        defectRate: 4.2,
        sensors: [
          {
            id: 'temp-test-1',
            name: 'Temperature',
            value: 72,
            unit: '°C',
            threshold: 85,
            status: 'normal',
          },
          {
            id: 'pressure-test-1',
            name: 'Water Pressure',
            value: 45,
            unit: 'bar',
            threshold: 60,
            status: 'normal',
          },
          {
            id: 'noise-test-1',
            name: 'Noise Level',
            value: 78,
            unit: 'dB',
            threshold: 85,
            status: 'normal',
          },
        ],
        completed: 87,
        queue: 28,
        efficiency: 72,
        operatorName: 'Emma Johnson',
        shiftStart: new Date(new Date().setHours(6, 0, 0)),
        shiftEnd: new Date(new Date().setHours(14, 0, 0)),
      },
      {
        id: 'packing',
        name: 'Packing & Shipping',
        cycleTime: 35,
        downtime: 0,
        defectRate: 0.5,
        sensors: [
          {
            id: 'temp-pack-1',
            name: 'Temperature',
            value: 55,
            unit: '°C',
            threshold: 65,
            status: 'normal',
          },
          {
            id: 'humidity-pack-1',
            name: 'Humidity',
            value: 42,
            unit: '%',
            threshold: 60,
            status: 'normal',
          },
          {
            id: 'energy-pack-1',
            name: 'Power Consumption',
            value: 8.9,
            unit: 'kW',
            threshold: 15,
            status: 'normal',
          },
        ],
        completed: 82,
        queue: 0,
        efficiency: 94,
        operatorName: 'David Lee',
        shiftStart: new Date(new Date().setHours(6, 0, 0)),
        shiftEnd: new Date(new Date().setHours(14, 0, 0)),
      },
    ];

    return {
      timestamp: new Date(),
      stations,
      totalCompleted: stations.reduce((sum, s) => sum + s.completed, 0),
      totalQueued: stations.reduce((sum, s) => sum + s.queue, 0),
      lineEfficiency: this.calculateLineEfficiency(stations),
      estimatedTimeToCompletion: this.estimateCompletion(stations),
    };
  }

  private calculateLineEfficiency(stations: StationData[]): number {
    const avgEfficiency =
      stations.reduce((sum, s) => sum + s.efficiency, 0) / stations.length;
    return Math.round(avgEfficiency);
  }

  private estimateCompletion(stations: StationData[]): number {
    // Bottleneck determines line throughput
    const bottleneck = stations.reduce((min, s) =>
      s.cycleTime + s.downtime > min.cycleTime + min.downtime ? s : min
    );
    const maxQueue = Math.max(...stations.map((s) => s.queue));
    return Math.ceil(maxQueue * (bottleneck.cycleTime + bottleneck.downtime) / 60);
  }

  private startRealTimeSimulation(): void {
    // Simulate real-time data updates every 5 seconds
    interval(5000).subscribe(() => {
      const current = this.productionLineData.value;
      const updated: ProductionLineSnapshot = {
        ...current,
        timestamp: new Date(),
        stations: current.stations.map((station) =>
          this.updateStationData(station)
        ),
      };
      updated.totalCompleted = updated.stations.reduce(
        (sum, s) => sum + s.completed,
        0
      );
      updated.totalQueued = updated.stations.reduce((sum, s) => sum + s.queue, 0);
      updated.lineEfficiency = this.calculateLineEfficiency(updated.stations);
      updated.estimatedTimeToCompletion = this.estimateCompletion(
        updated.stations
      );

      this.productionLineData.next(updated);

      // Store history for trend analysis
      const history = this.stationHistory.value;
      history.push([...updated.stations]);
      if (history.length > 100) {
        history.shift();
      }
      this.stationHistory.next(history);
    });
  }

  private updateStationData(station: StationData): StationData {
    const updated = { ...station };

    // Simulate slight variations in cycle time
    updated.cycleTime = Math.max(
      30,
      station.cycleTime + (Math.random() - 0.5) * 10
    );

    // Simulate occasional downtime events (5% chance)
    if (Math.random() < 0.05) {
      updated.downtime = station.downtime + Math.random() * 15;
    } else if (updated.downtime > 0) {
      updated.downtime = Math.max(0, updated.downtime - 2);
    }

    updated.queue = Math.max(0, Math.round(station.queue + (Math.random() - 0.4) * 3));

    // Update completed units
    if (Math.random() > 0.3) {
      // 70% chance to complete a unit
      updated.completed = station.completed + 1;
      updated.queue = Math.max(0, updated.queue - 1);
    }

    // Update efficiency
    const baseEfficiency = 100 - (station.downtime * 2 + station.defectRate);
    updated.efficiency = Math.min(
      100,
      Math.max(50, baseEfficiency + (Math.random() - 0.5) * 5)
    );

    // Update sensor readings with slight variations
    updated.sensors = station.sensors.map((sensor) => {
      const variation = (Math.random() - 0.5) * sensor.threshold * 0.1;
      const newValue = sensor.value + variation;
      let status: 'normal' | 'warning' | 'critical' = 'normal';

      if (newValue > sensor.threshold * 0.9) {
        status = 'critical';
      } else if (newValue > sensor.threshold * 0.7) {
        status = 'warning';
      }

      return {
        ...sensor,
        value: Math.round(newValue * 10) / 10,
        status,
      };
    });

    return updated;
  }

  getProductionLine(): Observable<ProductionLineSnapshot> {
    return this.productionLineData.asObservable();
  }

  getSimulation(hours: number = 8): Observable<SimulationResult[]> {
    const current = this.productionLineData.value;
    const results: SimulationResult[] = [];

    let cumulativeCompletion = 0;
    let cumulativeQueue = current.totalQueued;

    for (let i = 1; i <= hours; i++) {
      // Calculate expected completion based on current efficiency
      const avgCycleTime =
        current.stations.reduce((sum, s) => sum + s.cycleTime, 0) /
        current.stations.length;
      const avgDowntime =
        current.stations.reduce((sum, s) => sum + s.downtime, 0) /
        current.stations.length;
      const unitsPerHour = Math.floor(
        (3600 / (avgCycleTime + avgDowntime)) * (current.lineEfficiency / 100)
      );

      cumulativeCompletion += unitsPerHour;
      cumulativeQueue = Math.max(0, cumulativeQueue - unitsPerHour);

      // Identify bottleneck
      const bottleneck = current.stations.reduce((min, s) =>
        s.cycleTime + s.downtime > min.cycleTime + min.downtime ? s : min
      );

      // Generate recommendation
      let recommendation = '✓ On track';
      if (cumulativeQueue > 50) {
        recommendation = '⚠ High queue - Consider additional shifts';
      } else if (current.lineEfficiency < 80) {
        recommendation = '⚠ Low efficiency - Check ' + bottleneck.name;
      }

      results.push({
        hour: i,
        expectedCompletion: cumulativeCompletion,
        expectedQueue: cumulativeQueue,
        expectedDowntime: Math.round(avgDowntime * i),
        bottleneckStation: bottleneck.name,
        recommendation,
      });
    }

    this.simulationResults.next(results);
    return this.simulationResults.asObservable();
  }

  getStationHistory(): Observable<StationData[][]> {
    return this.stationHistory.asObservable();
  }

  // Trigger manual downtime event (for testing)
  triggerDowntimeEvent(stationId: string): void {
    const current = this.productionLineData.value;
    const updated = { ...current };
    updated.stations = updated.stations.map((s) =>
      s.id === stationId ? { ...s, downtime: s.downtime + 30 } : s
    );
    this.productionLineData.next(updated);
  }

  // Get detailed alert summary
  getAlerts(): Array<{
    stationId: string;
    stationName: string;
    message: string;
    severity: 'info' | 'warning' | 'critical';
  }> {
    const current = this.productionLineData.value;
    const alerts: Array<{
      stationId: string;
      stationName: string;
      message: string;
      severity: 'info' | 'warning' | 'critical';
    }> = [];

    current.stations.forEach((station) => {
      if (station.downtime > 10) {
        alerts.push({
          stationId: station.id,
          stationName: station.name,
          message: `Downtime: ${Math.round(station.downtime)} minutes`,
          severity: 'critical',
        });
      }

      if (station.efficiency < 75) {
        alerts.push({
          stationId: station.id,
          stationName: station.name,
          message: `Low efficiency: ${Math.round(station.efficiency)}%`,
          severity: 'warning',
        });
      }

      if (station.defectRate > 3) {
        alerts.push({
          stationId: station.id,
          stationName: station.name,
          message: `High defect rate: ${station.defectRate.toFixed(1)}%`,
          severity: 'warning',
        });
      }

      station.sensors.forEach((sensor) => {
        if (sensor.status === 'critical') {
          alerts.push({
            stationId: station.id,
            stationName: station.name,
            message: `${sensor.name} critical: ${sensor.value} ${sensor.unit}`,
            severity: 'critical',
          });
        } else if (sensor.status === 'warning') {
          alerts.push({
            stationId: station.id,
            stationName: station.name,
            message: `${sensor.name} warning: ${sensor.value} ${sensor.unit}`,
            severity: 'warning',
          });
        }
      });
    });

    return alerts;
  }
}
