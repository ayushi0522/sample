import { Injectable, signal } from '@angular/core';

export type AlertType = 'success' | 'error' | 'info';

export interface Alert {
  message: string;
  type: AlertType;
}

@Injectable({
  providedIn: 'root',
})
export class AlertService {
  alert = signal<Alert | null>(null);
  private timer: any;

  showAlert(message: string, type: AlertType, duration: number = 4000) {
    if (this.timer) {
      clearTimeout(this.timer);
    }

    this.alert.set({ message, type });

    this.timer = setTimeout(() => {
      this.clearAlert();
    }, duration);
  }

  clearAlert() {
    this.alert.set(null);
    if (this.timer) {
      clearTimeout(this.timer);
    }
  }
}