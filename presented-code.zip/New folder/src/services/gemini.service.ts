import { Injectable, signal } from '@angular/core';
import { GoogleGenAI, Chat, GenerateContentResponse, Type } from '@google/genai';

export interface ChatMessage {
  role: 'user' | 'model' | 'system';
  parts: string;
}

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private chat: Chat | null = null;
  private readonly API_KEY = "";
  thinking = signal(false);

  constructor() {
    if (!this.API_KEY) {
      console.error("API_KEY environment variable not set.");
      return;
    }
    const ai = new GoogleGenAI({apiKey: this.API_KEY});
    this.chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: 'You are a helpful and witty assistant for a dynamic data dashboard. Keep your answers concise and informative.',
      },
    });
  }

  async *sendMessage(prompt: string) {
    if (!this.chat) {
      yield 'Error: Gemini chat is not initialized. Please check your API key.';
      return;
    }

    this.thinking.set(true);
    try {
      const result = await this.chat.sendMessageStream({ message: prompt });
      let firstChunk = true;
      for await (const chunk of result) {
        if (firstChunk) {
            this.thinking.set(false);
            firstChunk = false;
        }
        yield chunk.text;
      }
    } catch (error) {
      console.error('Error sending message to Gemini:', error);
      yield 'Error: Could not get a response from the AI. Please check the console for details.';
    } finally {
        this.thinking.set(false);
    }
  }

  async generateJsonContent(prompt: string, schema: object): Promise<any> {
    if (!this.API_KEY) {
      throw new Error("API_KEY environment variable not set.");
    }
    const ai = new GoogleGenAI({apiKey: this.API_KEY});
    this.thinking.set(true);
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: schema,
        },
      });
      
      const jsonText = response.text.trim();
      return JSON.parse(jsonText);
    } catch (error) {
      console.error('Error generating JSON content from Gemini:', error);
      throw new Error('Failed to generate a valid response from the AI.');
    } finally {
      this.thinking.set(false);
    }
  }
}
