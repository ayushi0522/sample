# 🧪 Quick Test Instructions - Simulation Chat Component

## ⚡ Fast Testing Steps

### 1. **Start the Application**
Open Command Prompt (CMD) and run:
```cmd
cd c:\ayushi\sample-main\sample-main\final-project-backup\final-project-backup
npm start
```

Wait for: `✔ Compiled successfully!`

### 2. **Open Browser**
Navigate to: `http://localhost:4200`

### 3. **Login to IoT Dashboard**
- Username: `iot@example.com`
- Password: `iot123`

### 4. **Navigate to Production Simulation**
Click on **"Production Simulation"** in the sidebar

### 5. **Find Chat Assistant**
Scroll to the bottom of the page to see:
```
🤖 AI Simulation Assistant
[▼ Hide button]
```

### 6. **Test Chat Interface**
You should see:
- ✅ Chat header with robot icon
- ✅ Empty state with example queries
- ✅ Three clickable example questions
- ✅ Text input area at bottom
- ✅ Send button

### 7. **Try Example Queries**
Click one of the example buttons:
- "Can I increase the unit?"
- "What is the bottleneck?"
- "How to reduce waste?"

### 8. **What to Expect**

#### **WITHOUT API Running (Expected Behavior):**
- ✅ Your message appears in chat
- ✅ Loading indicator (typing dots) shows
- ❌ Error message appears:
  ```
  ⚠️ Failed to get simulation results
  ```
- ❌ AI responds with:
  ```
  ❌ Failed to analyze simulation. Please try again.
  ```

#### **WITH API Running (Expected Behavior):**
- ✅ Your message appears
- ✅ Loading indicator shows
- ✅ AI response appears with:
  - 📊 Summary text
  - 🎯 Target Achievement section
  - 📊 KPI Comparison cards
  - 🏭 Station Utilization bars

---

## 🐛 Common Issues & Fixes

### **Issue 1: Component Not Showing**
**Symptom:** No chat section visible on Production Simulation page

**Fix:**
1. Check if component files exist:
   ```cmd
   dir src\components\iot-simulation-chat
   ```
   Should show:
   - `iot-simulation-chat.component.ts`
   - `iot-simulation-chat.component.html`
   - `iot-simulation-chat.component.css`

2. Restart dev server (Ctrl+C, then `npm start`)

---

### **Issue 2: Empty Chat Container**
**Symptom:** Chat header shows but no content inside

**Fix:**
1. Check browser console (F12) for errors
2. Verify HTML file is not empty:
   ```cmd
   type src\components\iot-simulation-chat\iot-simulation-chat.component.html
   ```
3. Check CSS file exists:
   ```cmd
   type src\components\iot-simulation-chat\iot-simulation-chat.component.css
   ```

---

### **Issue 3: API Connection Error**
**Symptom:** Error message appears immediately after sending

**Expected:** This is normal if API is not running!

**To test with API:**
1. Start your API server on port 8000
2. Ensure CORS is enabled
3. Test endpoint with curl:
   ```cmd
   curl -X POST http://127.0.0.1:8000/ ^
        -H "Content-Type: application/json" ^
        -d "{\"query\":\"test\"}"
   ```

---

### **Issue 4: Styling Issues**
**Symptom:** Chat looks broken or unstyled

**Fix:**
1. Clear browser cache (Ctrl+Shift+Delete)
2. Hard refresh (Ctrl+F5)
3. Check if CSS file is not empty:
   ```cmd
   dir src\components\iot-simulation-chat\*.css
   ```
   Should show file size > 0 bytes

---

### **Issue 5: TypeScript Errors**
**Symptom:** Compilation errors in terminal

**Fix:**
1. Check for errors:
   ```cmd
   npm run build
   ```
2. Look at terminal output for specific errors
3. Verify all imports are correct

---

## ✅ Success Checklist

- [ ] Application starts without errors
- [ ] Production Simulation page loads
- [ ] Chat assistant section visible
- [ ] Chat header shows correctly
- [ ] Example queries are clickable
- [ ] Text input is functional
- [ ] Send button is clickable
- [ ] Messages appear in chat
- [ ] Loading indicator shows
- [ ] Error handling works (without API)
- [ ] Clear button works
- [ ] Toggle hide/show works
- [ ] Responsive on mobile (resize browser)

---

## 📸 Visual Verification

### **What You Should See:**

#### **1. Chat Header**
```
┌─────────────────────────────────────────────────┐
│ 💬  AI Simulation Assistant                [X] │
│     Ask questions about production scenarios    │
└─────────────────────────────────────────────────┘
```

#### **2. Empty State**
```
┌─────────────────────────────────────────────────┐
│                    🤖                            │
│                                                  │
│             Start a Conversation                │
│          Ask questions like:                    │
│                                                  │
│   ┌──────────────────────────────────────────┐ │
│   │ "Can I increase the unit?"               │ │
│   └──────────────────────────────────────────┘ │
│   ┌──────────────────────────────────────────┐ │
│   │ "What is the bottleneck?"                │ │
│   └──────────────────────────────────────────┘ │
│   ┌──────────────────────────────────────────┐ │
│   │ "How to reduce waste?"                   │ │
│   └──────────────────────────────────────────┘ │
└─────────────────────────────────────────────────┘
```

#### **3. User Message**
```
┌─────────────────────────────────────────────────┐
│                                  You  11:30 AM  │
│                    Can I increase the unit?     │
│                    ┌─────────────────────────┐  │
│                    │  Can I increase the     │  │
│                 👤 │  unit?                  │  │
│                    └─────────────────────────┘  │
└─────────────────────────────────────────────────┘
```

#### **4. Chat Input**
```
┌─────────────────────────────────────────────────┐
│ ┌────────────────────────────────────────────┐ │
│ │ Ask about production scenarios...          │ │
│ │                                            │ │
│ └────────────────────────────────────────────┘ │
│                                           [📤] │
└─────────────────────────────────────────────────┘
```

---

## 🎯 Quick Functionality Tests

### **Test 1: Send Message**
1. Type "test" in input
2. Press Enter
3. ✅ Message should appear
4. ✅ Input should clear
5. ✅ Loading indicator should show

### **Test 2: Example Query**
1. Click "Can I increase the unit?"
2. ✅ Query auto-fills and sends
3. ✅ User message appears
4. ✅ Loading starts

### **Test 3: Clear Chat**
1. Send a few messages
2. Click [X] button
3. ✅ All messages should clear
4. ✅ Empty state should return

### **Test 4: Toggle Collapse**
1. Click "▼ Hide" button
2. ✅ Chat should collapse (height: 0)
3. ✅ Button changes to "▲ Show"
4. Click "▲ Show"
5. ✅ Chat expands back

---

## 🔄 Complete Test Flow

```
1. npm start
   ↓
2. Open http://localhost:4200
   ↓
3. Login (iot@example.com / iot123)
   ↓
4. Click "Production Simulation"
   ↓
5. Scroll to bottom
   ↓
6. See "🤖 AI Simulation Assistant"
   ↓
7. Click example query
   ↓
8. Verify message sent
   ↓
9. See loading indicator
   ↓
10. See error (no API) OR response (with API)
   ↓
11. Click clear button
   ↓
12. Verify chat cleared
   ↓
✅ ALL TESTS PASS!
```

---

## 📞 Need Help?

### **Files to Check:**
1. `src/components/iot-simulation-chat/iot-simulation-chat.component.ts`
2. `src/components/iot-simulation-chat/iot-simulation-chat.component.html`
3. `src/components/iot-simulation-chat/iot-simulation-chat.component.css`
4. `src/components/iot-production-simulation/iot-production-simulation.component.ts`
5. `src/components/iot-production-simulation/iot-production-simulation.component.html`
6. `src/components/iot-production-simulation/iot-production-simulation.component.css`

### **Check Browser Console:**
Press F12 → Console tab → Look for errors

### **Check Terminal:**
Look for compilation errors after running `npm start`

---

## 🎉 Success Indicators

If you see all of these, the implementation is working:

✅ Chat section renders on Production Simulation page
✅ Chat header with title and buttons
✅ Empty state with 3 example queries
✅ Input field and send button
✅ Messages appear when sent
✅ Loading indicator animates
✅ Error handling works
✅ Clear button removes messages
✅ Toggle button collapses/expands
✅ Smooth animations
✅ Responsive design

**Status: READY FOR TESTING! 🚀**

---

*Quick Reference: December 5, 2025*
